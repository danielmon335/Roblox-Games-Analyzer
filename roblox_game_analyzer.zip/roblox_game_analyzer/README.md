# Roblox Game Analyzer

Herramienta **local** para investigar juegos (experiencias) de Roblox en masa y descubrir qué
características, sistemas y patrones de diseño aparecen en los juegos populares.

Flujo principal: **DESCUBRIR → RECOPILAR → GUARDAR → MOSTRAR → ANALIZAR PATRONES**.

> La aplicación solo usa endpoints **públicos** de Roblox, sin autenticación, sin cookies y
> respetando límites de velocidad. No accede a código privado de experiencias, no se salta
> permisos, CAPTCHA ni protecciones. Lo que no puede obtenerse legítimamente se marca como
> «No disponible».

---

## Qué hace

| Sección | Función |
|---|---|
| **Dashboard** | Juegos encontrados/analizados, jugadores totales y promedios, categorías, última actualización, presencia por grupo de mecánicas, trabajos recientes. |
| **Juegos** | Tabla ordenable (Nombre, Jugadores, Visitas, Favoritos, Likes, Aprobación, Categoría, Última actualización) con búsqueda, filtro por categoría, rango de jugadores, lote, paginación, enlace a Roblox y selección para el comparador. |
| **Detalle** | Imagen, creador, descripción, estadísticas (con la fuente de cada dato al pasar el ratón), gráfico histórico de snapshots, categorías, gamepasses e insignias públicas, mecánicas con evidencia, análisis generado (reglas) y análisis IA, textos manuales. |
| **Descubrir** | Descubrimiento automático por categoría, populares, tendencia, relacionados, palabra clave, lista de IDs, lista de URLs o una lista oficial concreta. Cantidad, criterio de orden y tamaño de lote configurables. |
| **Análisis masivo** | «Analizar lote»: descubre, recopila, guarda, analiza mecánicas y calcula estadísticas agregadas (Mecánica · Juegos donde aparece · Porcentaje). |
| **Mecánicas** | Frecuencia de cada mecánica (filtrable por categoría/lote); clic para ver los juegos y la evidencia textual. |
| **Comparador** | Hasta 10 juegos lado a lado: jugadores, visitas, favoritos, likes, antigüedad, gamepasses, precios, mecánicas (marca «≠» donde difieren). Sin rankings. |
| **Patrones** | % por grupo, mecánicas más frecuentes, combinaciones frecuentes (pares/tríos), combinaciones de grupos y asociaciones observadas con jugadores — siempre con aviso de que son descriptivas y no causales. |
| **Historial** | Cambios entre los dos últimos snapshots, botón para tomar nuevos snapshots de todos los juegos, re-analizar, trabajos y registro de errores de API. |
| **Exportar** | CSV (juegos, mecánicas, frecuencias, snapshots), JSON completo, Excel (.xlsx, 7 hojas) e informe HTML (Resumen, Estadísticas, Mecánicas, Patrones, Datos). |
| **Configuración** | Máx. resultados, tamaño de lote, intervalo entre solicitudes, timeouts, reintentos, caché, IA (activar, proveedor, modelo, API key → `.env`), ubicación de la base de datos. |

---

## Requisitos

- Windows 10/11 (también funciona en macOS/Linux)
- **Python 3.9 o superior** (recomendado 3.11+). Descárgalo de https://www.python.org/downloads/ y marca
  **«Add python.exe to PATH»** durante la instalación.
- Conexión a Internet (para consultar las APIs públicas de Roblox)

Dependencias (en `requirements.txt`): Flask, requests, pandas, openpyxl, python-dotenv.

---

## Instalación en Windows (paso a paso)

Abre **PowerShell** o **Símbolo del sistema** en la carpeta del proyecto (`roblox_game_analyzer`):

```bat
cd C:\ruta\a\roblox_game_analyzer
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env
```

> Si PowerShell bloquea `activate`, ejecuta una vez:
> `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned` o usa el Símbolo del sistema (cmd).
> Si `python` no se reconoce, prueba con `py` en su lugar.

**Alternativa rápida:** haz doble clic en `iniciar_windows.bat` — crea el entorno virtual,
instala dependencias la primera vez e inicia la aplicación.

## Cómo iniciar

```bat
.venv\Scripts\activate
python main.py
```

Se abrirá el navegador automáticamente en **http://127.0.0.1:8000**.
Opciones: `python main.py --port 8080` · `python main.py --no-browser`. Para salir: `Ctrl+C`.

---

## Configuración

Todo es opcional. Se puede cambiar desde la página **Configuración** (se guarda en
`data/settings.json`) o en el archivo `.env` (ver `.env.example`).

| Variable | Por defecto | Descripción |
|---|---|---|
| `PORT` / `HOST` | 8000 / 127.0.0.1 | Servidor local |
| `DB_PATH` | `data/roblox_analyzer.db` | Ubicación de la base SQLite |
| `REQUEST_INTERVAL` | 0.6 s | Pausa mínima entre solicitudes al mismo host |
| `REQUEST_TIMEOUT` | 15 s | Timeout por solicitud |
| `MAX_RETRIES` | 4 | Reintentos con backoff exponencial |
| `MAX_RESULTS` | 100 | Cantidad por defecto (máx. 1000) |
| `BATCH_SIZE` | 50 | IDs por solicitud a `/v1/games` (Roblox admite 50) |
| `CACHE_TTL_STATS` | 600 s | Caché de estadísticas |
| `CACHE_TTL_STATIC` | 86400 s | Caché de gamepasses/insignias/iconos |
| `MIN_SNAPSHOT_MINUTES` | 30 | No duplica snapshots del mismo juego dentro de este intervalo |
| `AI_ENABLED` | false | Activa el análisis IA |
| `AI_PROVIDER` | anthropic | `anthropic` u `openai` (cualquier API compatible con `/chat/completions`) |
| `AI_MODEL` | (vacío) | Nombre exacto del modelo del proveedor |
| `AI_API_KEY` | (vacío) | **Solo en `.env`**. Nunca se escribe en el código ni en la base de datos |

---

## APIs públicas utilizadas (verificadas en septiembre de 2026)

| Dato | Endpoint |
|---|---|
| Nombre, descripción, creador, fechas, jugadores, visitas, favoritos, género, max jugadores | `GET games.roblox.com/v1/games?universeIds=…` (hasta 50 IDs) |
| Likes / dislikes | `GET games.roblox.com/v1/games/votes?universeIds=…` |
| Favoritos (respaldo) | `GET games.roblox.com/v1/games/{universeId}/favorites/count` |
| Icono | `GET thumbnails.roblox.com/v1/games/icons?universeIds=…` |
| placeId (URL) → universeId | `GET apis.roblox.com/universes/v1/places/{placeId}/universe` |
| Populares / tendencia / géneros | `GET apis.roblox.com/explore-api/v1/get-sort-content?sortId=…` (listas de la página *Charts*: `most-popular`, `top-playing-now`, `top-trending`, `up-and-coming`, `top-rated`, `top-revisited`, `trending-in-rpg`, `trending-in-survival`, …) |
| Búsqueda por categoría/palabra clave | `GET apis.roblox.com/search-api/omni-search?searchQuery=…` (40 por página, paginada) |
| Relacionados / recomendados | `GET games.roblox.com/v1/games/recommendations/game/{universeId}` |
| Gamepasses públicos (precio, descripción) | `GET apis.roblox.com/game-passes/v1/universes/{universeId}/game-passes?passView=Full` |
| Insignias (logros) | `GET badges.roblox.com/v1/universes/{universeId}/badges` |
| Servidores públicos (opcional) | `GET games.roblox.com/v1/games/{placeId}/servers/Public` |

Notas:
- El antiguo `games.roblox.com/v1/games/list` fue retirado por Roblox; se sustituye por
  `explore-api` y `search-api`, que son los que usa la web oficial de forma anónima.
- `games.roblox.com/v1/games/{id}/game-passes` ya no existe (404); se usa el endpoint nuevo de `apis.roblox.com`.
- Los anuncios patrocinados (`isSponsored`) se excluyen de los resultados.

## Control de API y robustez

- Pausa mínima entre solicitudes por host, reintentos con backoff exponencial + jitter.
- HTTP 429: respeta `Retry-After`; HTTP 5xx/timeout: reintenta; otros 4xx: no reintenta.
- Si un host falla 6 veces seguidas se pausa 90 s y el proceso continúa con lo demás.
- Caché de respuestas en SQLite (`http_cache`) para evitar solicitudes repetidas.
- Juegos eliminados/privados se marcan como `not_found` y el lote continúa.
- Todos los errores se registran en la tabla `error_log` (visible en *Historial*) y en `logs/app.log`.
- Los trabajos se ejecutan en un hilo en segundo plano, uno a la vez, y se pueden cancelar.

## Base de datos (SQLite)

`games` · `game_snapshots` (histórico, nunca se sobrescribe) · `game_categories` · `game_items`
(gamepasses e insignias) · `manual_notes` · `mechanics` · `game_mechanics` · `analysis_results` ·
`jobs` · `job_games` · `http_cache` · `error_log`.

## Cómo se detectan las mecánicas

Método por reglas (sin IA), en `app/mechanics.py`: ~60 mecánicas en 7 grupos (Core loop,
Progresión, Recompensas, Retención, Social, Gameplay, Monetización). Se buscan palabras clave en
inglés y español en: nombre, descripción, gamepasses públicos, insignias públicas y textos que el
usuario pegue manualmente (changelogs, wikis). Además se usan datos estructurados de la API
(número de gamepasses, insignias, servidores privados permitidos, precio de acceso).

| Estado | Significado |
|---|---|
| **Detectada** | mención explícita fuerte o dato estructurado de la API |
| **Probable** | mención débil o indirecta |
| **No detectada** | hay texto suficiente pero sin señales |
| **No hay información suficiente** | faltan fuentes públicas para decidir |

Los porcentajes del análisis masivo se calculan **solo sobre juegos con información suficiente**
para cada mecánica. Los patrones son descriptivos: *«Existe una asociación observada en esta
muestra, pero esto no demuestra causalidad»*.

## Análisis con IA (opcional)

1. Configuración → marcar «Habilitar análisis IA».
2. Elegir proveedor, escribir el nombre del modelo y pegar la API key (se guarda en `.env`).
3. En el detalle de un juego pulsar «Analizar con IA», o marcar «Usar IA» al lanzar un lote.

La IA recibe solo la información pública recopilada + tus notas manuales, y devuelve: core loop
probable, mecánicas, progresión, recompensas, retención, social, monetización visible,
características diferenciadoras y posibles razones de engagement (marcadas como inferencia).

---

## Limitaciones conocidas

- `explore-api` y `search-api` son públicos pero **no están documentados oficialmente**: Roblox
  podría cambiarlos. Si fallan, el resto de funciones (IDs, URLs, relacionados, detalles) sigue funcionando.
- Cada lista oficial (sort) contiene ~20–100 juegos; para cantidades grandes por categoría se usa la búsqueda.
- Las categorías **Horror, Tycoon y Anime** no son géneros oficiales de Roblox: se descubren por búsqueda
  (la opción «solo género oficial» no aplica).
- La búsqueda de Roblox devuelve resultados personalizados/por relevancia; los resultados pueden variar entre ejecuciones.
- La fecha de creación/actualización es la de la experiencia (universo), no del último *changelog*.
- Los **developer products** (compras dentro del juego) no tienen endpoint público fiable: solo se infieren por texto.
- Contar servidores públicos es costoso; está desactivado por defecto y, si se activa, se leen como máximo N páginas (se muestra «≥ X»).
- No se descargan wikis automáticamente; puedes pegar esos textos manualmente en el detalle del juego.
- La detección por palabras clave puede dar falsos positivos/negativos; por eso se muestra la evidencia textual.
- Tiempo aproximado con la configuración por defecto: ~1 s por juego (100 juegos ≈ 1–2 min; 1000 ≈ 15–20 min).

---

## Estructura del proyecto

```
roblox_game_analyzer/
├── main.py                 # Punto de entrada: python main.py
├── iniciar_windows.bat     # Instala (1.ª vez) e inicia en Windows
├── requirements.txt
├── .env.example            # Plantilla de configuración (copiar a .env)
├── README.md
├── app/
│   ├── config.py           # Configuración (.env + data/settings.json)
│   ├── logging_setup.py    # Logs en consola y logs/app.log
│   ├── db.py               # Esquema SQLite y utilidades
│   ├── roblox_client.py    # Cliente HTTP: rate limit, reintentos, 429, caché
│   ├── discovery.py        # Descubrimiento (sorts, búsqueda, relacionados, IDs, URLs)
│   ├── collector.py        # Recolección de datos y snapshots
│   ├── mechanics.py        # Taxonomía y detección de mecánicas por reglas
│   ├── patterns.py         # Estadísticas, combinaciones y asociaciones
│   ├── ai_analyzer.py      # Análisis IA opcional (Anthropic / compatible OpenAI)
│   ├── jobs.py             # Trabajos en segundo plano (lotes)
│   ├── exporter.py         # CSV, JSON, Excel, informe HTML
│   └── web.py              # API Flask
├── static/                 # Frontend (HTML + CSS + JavaScript)
├── tests/
│   ├── mock_roblox.py      # Servidor simulado de las APIs (solo pruebas)
│   └── smoke_test.py       # Prueba de extremo a extremo con el simulador
├── data/                   # Base de datos y settings.json (se crean al iniciar)
├── logs/                   # app.log
└── exports/
```

## Ejemplos de uso

1. **100 juegos de terror ordenados por jugadores**: *Análisis masivo* → Método «Categoría», Horror,
   100, «Jugadores actuales» → *Analizar lote*. Al terminar verás la tabla Mecánica · Juegos · %.
2. **Tendencias de hoy**: *Descubrir* → «En tendencia», 150.
3. **Analizar juegos concretos**: *Descubrir* → «Lista de URLs», pega
   `https://www.roblox.com/games/2753915549/Blox-Fruits` (una por línea).
4. **Juegos parecidos a uno**: *Descubrir* → «Relacionados», ID `994732206`.
5. **Seguimiento en el tiempo**: vuelve otro día y pulsa *Historial → Actualizar estadísticas*;
   el detalle de cada juego mostrará la evolución.
6. **Comparar**: marca 2–10 juegos en *Juegos* y abre *Comparador*.
7. **Informe**: *Exportar* → Informe HTML o Excel.

## Pruebas (opcional)

Sin tocar Roblox, con un servidor que imita las respuestas reales:

```bat
python tests\smoke_test.py
```
