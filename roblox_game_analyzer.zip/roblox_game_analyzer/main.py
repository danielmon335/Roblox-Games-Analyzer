"""Roblox Game Analyzer — punto de entrada.

Uso:
    python main.py                 # inicia en http://127.0.0.1:8000 y abre el navegador
    python main.py --port 8080     # otro puerto
    python main.py --no-browser    # no abrir el navegador automáticamente
"""
import argparse
import logging
import sys
import threading
import webbrowser

if sys.version_info < (3, 9):
    print("Se requiere Python 3.9 o superior.")
    sys.exit(1)

from app.config import settings  # noqa: E402
from app.logging_setup import setup_logging  # noqa: E402


def main():
    parser = argparse.ArgumentParser(description="Roblox Game Analyzer")
    parser.add_argument("--host", default=settings.get("HOST"))
    parser.add_argument("--port", type=int, default=settings.get("PORT"))
    parser.add_argument("--no-browser", action="store_true")
    args = parser.parse_args()

    setup_logging()
    log = logging.getLogger("main")

    from app import db, mechanics
    from app.jobs import manager
    from app.web import create_app

    db.init_db()
    mechanics.seed_mechanics()
    manager.start()
    app = create_app()

    url = f"http://{'127.0.0.1' if args.host in ('0.0.0.0', '') else args.host}:{args.port}"
    log.info("Roblox Game Analyzer iniciado → %s  (Ctrl+C para salir)", url)
    if settings.get("OPEN_BROWSER") and not args.no_browser:
        threading.Timer(1.2, lambda: webbrowser.open(url)).start()
    try:
        app.run(host=args.host, port=args.port, debug=False, threaded=True, use_reloader=False)
    except OSError as e:
        log.error("No se pudo iniciar el servidor en el puerto %s: %s. Prueba: python main.py --port 8080", args.port, e)
        sys.exit(1)


if __name__ == "__main__":
    main()
