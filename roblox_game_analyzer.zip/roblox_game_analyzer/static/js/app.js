/* Roblox Game Analyzer — frontend (JavaScript sin frameworks) */
"use strict";

const NA = "No disponible";
const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
const view = () => $("#view");
let META = null;

// ---------------------------------------------------------------- utilidades
function esc(s) {
  return String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}
function fmt(n, dec = 0) {
  if (n === null || n === undefined || n === "" || Number.isNaN(n)) return `<span class="muted">${NA}</span>`;
  const x = Number(n);
  if (!Number.isFinite(x)) return esc(n);
  return x.toLocaleString("es-CO", { maximumFractionDigits: dec, minimumFractionDigits: 0 });
}
function fmtShort(n) {
  if (n === null || n === undefined) return NA;
  const a = Math.abs(n);
  if (a >= 1e9) return (n / 1e9).toFixed(1) + " B";
  if (a >= 1e6) return (n / 1e6).toFixed(1) + " M";
  if (a >= 1e3) return (n / 1e3).toFixed(1) + " K";
  return String(Math.round(n));
}
function fdate(s, withTime = false) {
  if (!s) return `<span class="muted">${NA}</span>`;
  const d = new Date(s);
  if (isNaN(d)) return esc(s);
  return withTime ? d.toLocaleString("es-CO", { dateStyle: "short", timeStyle: "short" }) : d.toLocaleDateString("es-CO");
}
function pct(n) { return n === null || n === undefined ? `<span class="muted">${NA}</span>` : fmt(n, 1) + "%"; }
function badge(status) {
  const label = (META && META.status_labels[status]) || status || "Sin analizar";
  return `<span class="badge st-${esc(status || "insuficiente")}">${esc(label)}</span>`;
}
function bar(p) { return `<div class="bar"><div style="width:${Math.max(0, Math.min(100, p || 0))}%"></div></div>`; }
function toast(msg, isError = false) {
  const t = $("#toast");
  t.textContent = msg;
  t.className = "toast" + (isError ? " error" : "");
  clearTimeout(t._h);
  t._h = setTimeout(() => t.classList.add("hidden"), isError ? 7000 : 3500);
}
async function api(path, opts = {}) {
  const o = { headers: {}, ...opts };
  if (o.body && typeof o.body !== "string") { o.body = JSON.stringify(o.body); o.headers["Content-Type"] = "application/json"; }
  let res;
  try { res = await fetch(path, o); } catch (e) { throw new Error("No se pudo conectar con el servidor local. ¿Está ejecutándose main.py?"); }
  let data = null;
  try { data = await res.json(); } catch (e) { /* respuesta vacía */ }
  if (!res.ok) throw new Error((data && data.error) || `HTTP ${res.status}`);
  return data;
}
function store(key, val) {
  try {
    if (val === undefined) return JSON.parse(localStorage.getItem("rga_" + key) || "null");
    localStorage.setItem("rga_" + key, JSON.stringify(val));
  } catch (e) { return null; }
}
function iconImg(url, cls = "icon") {
  return url ? `<img class="${cls}" src="${esc(url)}" alt="" loading="lazy" onerror="this.style.visibility='hidden'">` : `<span class="${cls}" style="display:inline-block"></span>`;
}
function optionList(items, selected, withEmpty = null) {
  let h = withEmpty !== null ? `<option value="">${esc(withEmpty)}</option>` : "";
  for (const it of items) {
    const [v, l] = Array.isArray(it) ? it : [it, it];
    h += `<option value="${esc(v)}" ${String(v) === String(selected ?? "") ? "selected" : ""}>${esc(l)}</option>`;
  }
  return h;
}
function qs(obj) {
  const p = new URLSearchParams();
  for (const [k, v] of Object.entries(obj)) if (v !== null && v !== undefined && v !== "") p.set(k, v);
  return p.toString();
}

// ---------------------------------------------------------------- comparador (selección)
function cmpGet() { return store("compare") || []; }
function cmpSet(ids) { store("compare", ids.slice(0, 10)); updateCmpCount(); }
function cmpToggle(id) {
  let ids = cmpGet();
  id = Number(id);
  ids = ids.includes(id) ? ids.filter(x => x !== id) : [...ids, id];
  if (ids.length > 10) { toast("Máximo 10 juegos en el comparador", true); return; }
  cmpSet(ids);
}
function updateCmpCount() {
  const n = cmpGet().length, el = $("#cmpCount");
  el.textContent = n; el.classList.toggle("hidden", !n);
}

// ---------------------------------------------------------------- trabajos
const watchers = {};
async function pollJobs() {
  try {
    const jobs = await api("/api/jobs?limit=8");
    const active = jobs.filter(j => j.status === "running" || j.status === "queued");
    const ind = $("#jobIndicator");
    if (active.length) {
      const j = active[0];
      const p = j.total ? Math.round(100 * j.progress / j.total) : 0;
      ind.innerHTML = `<b>#${j.id} ${esc(META?.job_types[j.type] || j.type)}</b><br>${esc(j.message || "")}${bar(p)}`
        + (active.length > 1 ? `<div class="small">+${active.length - 1} en cola</div>` : "");
      ind.classList.remove("hidden");
    } else ind.classList.add("hidden");
    for (const id of Object.keys(watchers)) {
      const j = await api(`/api/jobs/${id}`);
      watchers[id].onUpdate && watchers[id].onUpdate(j);
      if (!["running", "queued"].includes(j.status)) {
        const w = watchers[id]; delete watchers[id];
        w.onDone && w.onDone(j);
      }
    }
  } catch (e) { /* servidor ocupado o reiniciando */ }
}
function watchJob(id, onUpdate, onDone) { watchers[id] = { onUpdate, onDone }; pollJobs(); }
function jobProgressHtml(j) {
  const p = j.total ? Math.round(100 * j.progress / j.total) : 0;
  const warns = (j.result && j.result.warnings) || [];
  return `<div><b class="status-${esc(j.status)}">#${j.id} · ${esc(j.status)}</b> — ${esc(j.message || "")}</div>
    ${["running", "queued"].includes(j.status) ? bar(p) + `<button class="secondary small" onclick="cancelJob(${j.id})" style="margin-top:6px">Cancelar</button>` : ""}
    ${warns.length ? `<details><summary class="small">${warns.length} avisos</summary><ul class="warn-list">${warns.map(w => `<li>${esc(w)}</li>`).join("")}</ul></details>` : ""}
    ${j.result && j.result.sources ? `<div class="small muted">Fuentes: ${j.result.sources.map(esc).join(" · ")}</div>` : ""}`;
}
async function cancelJob(id) { await api(`/api/jobs/${id}/cancel`, { method: "POST" }); toast("Cancelando trabajo #" + id); }
window.cancelJob = cancelJob;

// ---------------------------------------------------------------- router
const routes = {
  dashboard: renderDashboard, games: renderGames, discover: () => renderDiscover(false), batch: () => renderDiscover(true),
  mechanics: renderMechanics, compare: renderCompare, patterns: renderPatterns, history: renderHistory,
  export: renderExport, settings: renderSettings, game: renderGameDetail,
};
async function router() {
  const hash = location.hash.replace(/^#\/?/, "") || "dashboard";
  const [name, arg] = hash.split("/");
  $$("#sidebar nav a").forEach(a => a.classList.toggle("active", a.dataset.route === name || (name === "game" && a.dataset.route === "games")));
  const fn = routes[name] || renderDashboard;
  view().innerHTML = `<p class="muted">Cargando…</p>`;
  try { await fn(arg); } catch (e) { view().innerHTML = `<div class="panel"><b>Error:</b> ${esc(e.message)}</div>`; }
  window.scrollTo(0, 0);
}

// ================================================================= DASHBOARD
async function renderDashboard() {
  const d = await api("/api/dashboard");
  const empty = !d.games_found;
  view().innerHTML = `
    <h1>Dashboard</h1>
    <p class="muted">Resumen de los juegos guardados en la base de datos local.</p>
    ${empty ? `<div class="info">Todavía no hay juegos. Ve a <a href="#/discover">Descubrir</a> o <a href="#/batch">Análisis masivo</a> para empezar (por ejemplo: categoría Horror, 50 juegos).</div>` : ""}
    <div class="kpis">
      ${kpi("Juegos encontrados", fmt(d.games_found), d.games_total_seen !== d.games_found ? `${d.games_total_seen - d.games_found} no disponibles` : "")}
      ${kpi("Juegos analizados", fmt(d.games_analyzed), "con mecánicas clasificadas")}
      ${kpi("Jugadores totales", fmt(d.total_playing), "suma del último snapshot")}
      ${kpi("Promedio de jugadores", fmt(d.avg_playing))}
      ${kpi("Promedio de likes", fmt(d.avg_likes))}
      ${kpi("Promedio de visitas", fmt(d.avg_visits))}
      ${kpi("Categorías analizadas", fmt(d.categories_count))}
      ${kpi("Última actualización", fdate(d.last_update, true), `${fmt(d.snapshots)} snapshots`)}
    </div>
    <div class="row">
      <div class="panel grow">
        <h3>Presencia por grupo de mecánicas</h3>
        ${d.groups.map(g => `<div class="row" style="align-items:center;margin:6px 0"><div style="width:120px">${esc(g.label)}</div>
          <div class="grow" style="min-width:120px">${bar(g.percent)}</div><div style="width:120px" class="small">${pct(g.percent)} (${g.count}/${g.games_with_info})</div></div>`).join("")}
        <p class="small muted">Porcentaje sobre juegos con información suficiente. Descriptivo, no causal.</p>
      </div>
      <div class="panel grow">
        <h3>Más jugadores ahora (último snapshot)</h3>
        <table>${d.top_games.map(g => `<tr class="clickable" onclick="location.hash='#/game/${g.universe_id}'">
          <td><div class="name-cell">${iconImg(g.icon_url)}<span>${esc(g.name)}</span></div></td><td class="num">${fmt(g.playing)}</td></tr>`).join("") || `<tr><td class="muted">Sin datos</td></tr>`}</table>
      </div>
    </div>
    <div class="row">
      <div class="panel grow">
        <h3>Categorías</h3>
        <div class="chips">${d.categories.slice(0, 40).map(c => `<a class="chip" href="#/games" onclick="store('games_filter',{category:'${esc(c.category).replace(/'/g, "\\'")}'})">${esc(c.category)} · ${c.n}${c.source === "discovery" ? " (descubrimiento)" : ""}</a>`).join("") || `<span class="muted">Sin categorías</span>`}</div>
      </div>
      <div class="panel grow">
        <h3>Trabajos recientes</h3>
        <table>${d.recent_jobs.map(j => `<tr><td>#${j.id}</td><td>${esc(META.job_types[j.type] || j.type)}</td><td class="status-${j.status}">${esc(j.status)}</td><td class="small">${esc(j.message || "")}</td></tr>`).join("") || `<tr><td class="muted">Sin trabajos</td></tr>`}</table>
      </div>
    </div>`;
}
function kpi(label, value, sub = "") {
  return `<div class="kpi"><div class="label">${esc(label)}</div><div class="value">${value}</div>${sub ? `<div class="sub">${sub}</div>` : ""}</div>`;
}
window.store = store;

// ================================================================= JUEGOS
const gamesState = { q: "", category: "", job_id: "", min_players: "", max_players: "", sort: "playing", dir: "desc", page: 1, status: "ok" };
async function renderGames() {
  Object.assign(gamesState, store("games_filter") || {});
  store("games_filter", null);
  const cats = await api("/api/categories");
  view().innerHTML = `
    <h1>Juegos</h1>
    <div class="panel">
      <div class="toolbar">
        <label>Buscar<input type="text" id="gq" placeholder="Nombre, creador o ID" value="${esc(gamesState.q)}"></label>
        <label>Categoría<select id="gcat">${optionList(cats.map(c => [c.category, `${c.category} (${c.n})`]), gamesState.category, "Todas")}</select></label>
        <label>Jugadores mín.<input type="number" id="gmin" style="width:110px" value="${esc(gamesState.min_players)}"></label>
        <label>Jugadores máx.<input type="number" id="gmax" style="width:110px" value="${esc(gamesState.max_players)}"></label>
        <label>Lote (job)<input type="number" id="gjob" style="width:80px" value="${esc(gamesState.job_id)}"></label>
        <label>Estado<select id="gstatus">${optionList([["ok", "Disponibles"], ["not_found", "Eliminados/privados"], ["all", "Todos"]], gamesState.status)}</select></label>
        <button id="gapply">Aplicar</button>
        <button class="secondary" id="greset">Limpiar</button>
      </div>
      <div id="gtable"></div>
    </div>`;
  const apply = () => {
    Object.assign(gamesState, { q: $("#gq").value.trim(), category: $("#gcat").value, min_players: $("#gmin").value,
      max_players: $("#gmax").value, job_id: $("#gjob").value, status: $("#gstatus").value, page: 1 });
    loadGamesTable();
  };
  $("#gapply").onclick = apply;
  $("#gq").onkeydown = e => { if (e.key === "Enter") apply(); };
  $("#greset").onclick = () => { Object.assign(gamesState, { q: "", category: "", job_id: "", min_players: "", max_players: "", page: 1, status: "ok" }); renderGames(); };
  await loadGamesTable();
}
async function loadGamesTable() {
  const data = await api("/api/games?" + qs({ ...gamesState, page_size: META.settings.UI_PAGE_SIZE || 50 }));
  const cmp = cmpGet();
  const cols = [["", ""], ["name", "Nombre"], ["playing", "Jugadores"], ["visits", "Visitas"], ["favorites", "Favoritos"],
    ["likes", "Likes"], ["like_ratio", "Aprob. %"], ["category", "Categoría"], ["updated", "Última actualización"]];
  const pages = Math.max(1, Math.ceil(data.total / data.page_size));
  $("#gtable").innerHTML = `
    <div class="small muted" style="margin-bottom:6px">${fmt(data.total)} juegos · marca la casilla para añadir al comparador</div>
    <div class="table-wrap"><table><thead><tr>${cols.map(([k, l]) => k ? `<th class="sortable ${["playing", "visits", "favorites", "likes", "like_ratio"].includes(k) ? "num" : ""} ${gamesState.sort === k ? "sorted " + gamesState.dir : ""}" data-sort="${k}">${l}</th>` : `<th title="Comparar">⇄</th>`).join("")}<th></th></tr></thead>
    <tbody>${data.rows.map(r => `<tr class="clickable" data-id="${r.universe_id}">
      <td><input type="checkbox" class="cmpchk" data-id="${r.universe_id}" ${cmp.includes(r.universe_id) ? "checked" : ""}></td>
      <td><div class="name-cell">${iconImg(r.icon_url)}<span>${esc(r.name || r.universe_id)}</span>${r.status !== "ok" ? ` <span class="badge st-insuficiente">${esc(r.status)}</span>` : ""}</div></td>
      <td class="num">${fmt(r.playing)}</td><td class="num">${fmt(r.visits)}</td><td class="num">${fmt(r.favorites)}</td>
      <td class="num">${fmt(r.up_votes)}</td><td class="num">${pct(r.like_ratio)}</td>
      <td class="small">${esc((r.categories || "").split(",").slice(0, 3).join(", ")) || `<span class="muted">${NA}</span>`}</td>
      <td>${fdate(r.updated)}</td>
      <td>${r.url ? `<a href="${esc(r.url)}" target="_blank" rel="noopener" onclick="event.stopPropagation()">Roblox ↗</a>` : ""}</td>
    </tr>`).join("") || `<tr><td colspan="10" class="muted">No hay juegos con estos filtros.</td></tr>`}</tbody></table></div>
    <div class="pager"><button class="secondary small" id="gprev" ${data.page <= 1 ? "disabled" : ""}>← Anterior</button>
      <span class="small">Página ${data.page} de ${pages}</span>
      <button class="secondary small" id="gnext" ${data.page >= pages ? "disabled" : ""}>Siguiente →</button></div>`;
  $$("#gtable th.sortable").forEach(th => th.onclick = () => {
    const k = th.dataset.sort;
    gamesState.dir = gamesState.sort === k && gamesState.dir === "desc" ? "asc" : "desc";
    gamesState.sort = k; gamesState.page = 1; loadGamesTable();
  });
  $$("#gtable tr.clickable").forEach(tr => tr.onclick = e => {
    if (e.target.classList.contains("cmpchk")) return;
    location.hash = "#/game/" + tr.dataset.id;
  });
  $$("#gtable .cmpchk").forEach(c => c.onclick = e => { e.stopPropagation(); cmpToggle(c.dataset.id); });
  $("#gprev").onclick = () => { gamesState.page--; loadGamesTable(); };
  $("#gnext").onclick = () => { gamesState.page++; loadGamesTable(); };
}

// ================================================================= DETALLE
async function renderGameDetail(uid) {
  const d = await api(`/api/games/${uid}`);
  const g = d.game, fs = g.field_sources || {};
  const last = d.snapshots[d.snapshots.length - 1] || {};
  const src = k => fs[k] ? ` title="Fuente: ${esc(fs[k])}"` : ` title="No disponible mediante fuentes públicas"`;
  const age = g.created ? Math.floor((Date.now() - new Date(g.created)) / 86400000) : null;
  const rules = (d.mechanics.rules || {}), aiM = (d.mechanics.ai || {});
  const inCmp = cmpGet().includes(g.universe_id);
  const extrasStatus = (g.extra && g.extra.extras_status) || {};
  view().innerHTML = `
    <p><a href="#/games">← Juegos</a></p>
    <div class="panel detail-head">
      ${iconImg(g.icon_url, "icon-lg")}
      <div class="grow">
        <h1>${esc(g.name || "Sin nombre")}</h1>
        <div class="muted">por <b${src("creator")}>${esc(g.creator_name || NA)}</b> (${esc(g.creator_type || "?")}${g.creator_verified ? ", verificado" : ""})
          · universeId ${g.universe_id} · placeId ${g.place_id ?? NA}</div>
        ${g.status !== "ok" ? `<div class="note">Estado: ${esc(g.status)} — ${esc(g.status_detail || "")}</div>` : ""}
        <div class="toolbar" style="margin-top:10px">
          ${g.url ? `<a href="${esc(g.url)}" target="_blank" rel="noopener"><button class="secondary">Abrir en Roblox ↗</button></a>` : ""}
          <button class="secondary" id="drefresh">Actualizar datos</button>
          <button class="secondary" id="danalyze">Re-analizar mecánicas</button>
          <button class="secondary" id="dai" ${d.ai_status.ready ? "" : `title="${esc(d.ai_status.reason || "")}"`}>Analizar con IA</button>
          <button class="secondary" id="dcmp">${inCmp ? "Quitar del comparador" : "Añadir al comparador"}</button>
        </div>
      </div>
    </div>
    <div class="kpis">
      ${kpi("Jugadores actuales", `<span${src("playing")}>${fmt(last.playing)}</span>`)}
      ${kpi("Visitas", `<span${src("visits")}>${fmt(last.visits)}</span>`)}
      ${kpi("Favoritos", `<span${src("favorites")}>${fmt(last.favorites)}</span>`)}
      ${kpi("Likes", `<span${src("up_votes")}>${fmt(last.up_votes)}</span>`)}
      ${kpi("Dislikes", `<span${src("down_votes")}>${fmt(last.down_votes)}</span>`)}
      ${kpi("Aprobación (likes/total)", `<span${src("like_ratio")}>${pct(last.like_ratio)}</span>`, last.up_votes != null && last.down_votes ? `ratio likes/dislikes ${fmt(last.up_votes / last.down_votes, 2)}` : "")}
      ${kpi("Servidores públicos", `<span${src("server_count")}>${last.server_count != null ? (last.server_count_lower_bound ? "≥ " : "") + fmt(last.server_count) : fmt(null)}</span>`, last.server_count == null ? "Actívalo en Configuración" : "")}
      ${kpi("Antigüedad", age != null ? fmt(age) + " días" : fmt(null), "desde " + fdate(g.created))}
    </div>
    <div class="row">
      <div class="panel grow">
        <h3>Evolución histórica</h3>
        <div class="tabs" id="chartTabs">${[["playing", "Jugadores"], ["visits", "Visitas"], ["favorites", "Favoritos"], ["up_votes", "Likes"], ["like_ratio", "Aprobación %"]]
          .map(([k, l], i) => `<button class="small ${i === 0 ? "active" : ""}" data-k="${k}">${l}</button>`).join("")}</div>
        <div id="chart"></div>
        <p class="small muted">${d.snapshots.length} snapshot(s). Cada recolección guarda un snapshot nuevo (mínimo ${esc(META.settings.MIN_SNAPSHOT_MINUTES ?? 30)} min entre ellos); los anteriores nunca se sobrescriben.</p>
      </div>
      <div class="panel grow">
        <h3>Descripción <span class="small muted">(fuente: ${esc(fs.description || NA)})</span></h3>
        <div class="desc">${g.description ? esc(g.description) : `<span class="muted">Descripción vacía o no disponible.</span>`}</div>
        <h3>Categorías</h3>
        <div class="chips">${d.categories.map(c => `<span class="chip" title="${c.source === "roblox_genre" ? "Género asignado por Roblox" : "Categoría usada al descubrir el juego"}">${esc(c.category)} · ${c.source === "roblox_genre" ? "género Roblox" : "descubrimiento"}</span>`).join("") || `<span class="muted">${NA}</span>`}</div>
      </div>
    </div>
    <div class="panel">
      <h3>Análisis generado</h3>
      <div class="tabs" id="anTabs"><button class="small active" data-t="rules">Reglas (sin IA)</button><button class="small" data-t="ai">IA ${d.ai ? "" : "(no ejecutado)"}</button></div>
      <div id="analysis"></div>
    </div>
    <div class="panel">
      <h3>Mecánicas detectadas</h3>
      <p class="small muted">Detectada = mención explícita o dato de la API · Probable = mención débil · No detectada = hay texto pero sin señales · No hay información suficiente = faltan fuentes. No son hechos verificados dentro del juego.</p>
      <div id="mechList"></div>
    </div>
    <div class="row">
      <div class="panel grow">
        <h3>Gamepasses públicos (${g.gamepass_count ?? NA})</h3>
        ${extrasStatus.gamepasses && !String(extrasStatus.gamepasses).startsWith("ok") ? `<div class="note small">${esc(extrasStatus.gamepasses)}</div>` : ""}
        ${itemsTable(d.items.filter(i => i.kind === "gamepass"), true)}
      </div>
      <div class="panel grow">
        <h3>Insignias públicas (${g.badge_count ?? NA})</h3>
        ${extrasStatus.badges && !String(extrasStatus.badges).startsWith("ok") ? `<div class="note small">${esc(extrasStatus.badges)}</div>` : ""}
        ${itemsTable(d.items.filter(i => i.kind === "badge"), false)}
      </div>
    </div>
    <div class="row">
      <div class="panel grow">
        <h3>Datos recopilados y fuentes</h3>
        <table>${[["Nombre", g.name, "name"], ["Creador", g.creator_name, "creator"], ["Creado", fdate(g.created), "created", true], ["Actualizado", fdate(g.updated), "updated", true],
          ["Género (Roblox)", [g.genre_l1, g.genre_l2].filter(Boolean).join(" / ") || null, "genre"], ["Máx. jugadores por servidor", g.max_players, "max_players"],
          ["Precio de acceso", g.price ? g.price + " Robux" : "Gratis (price = null)", "genre"], ["Servidores privados permitidos", g.extra?.createVipServersAllowed == null ? null : (g.extra.createVipServersAllowed ? "Sí" : "No"), "name"],
          ["Tipo de avatar", g.extra?.universeAvatarType, "name"], ["Icono", g.icon_url ? "Sí" : null, "icon"],
          ["Primera vez visto", fdate(g.first_seen, true), null, true], ["Última recolección", fdate(g.last_fetched, true), null, true]]
          .map(([l, v, k, raw]) => `<tr><td class="muted">${l}</td><td>${raw ? v : (v === null || v === undefined || v === "" ? `<span class="muted">${NA}</span>` : esc(v))}</td><td class="small muted">${k ? esc(fs[k] || "") : "local"}</td></tr>`).join("")}</table>
      </div>
      <div class="panel grow">
        <h3>Textos manuales (changelogs, wikis, notas)</h3>
        <p class="small muted">Pega aquí información pública adicional (p. ej. notas de actualización o una wiki). Se usará en el análisis de mecánicas y en la IA.</p>
        <div class="toolbar"><label>Fuente<input type="text" id="nsrc" placeholder="changelog / wiki / notas" style="width:180px"></label></div>
        <textarea id="ntext" placeholder="Texto…"></textarea>
        <div style="margin-top:6px"><button id="nadd">Guardar y re-analizar</button></div>
        ${d.notes.map(n => `<div class="panel" style="margin-top:8px"><div class="small muted">${esc(n.source)} · ${fdate(n.created_at, true)} <button class="secondary small" onclick="delNote(${n.id}, ${g.universe_id})">Eliminar</button></div><div class="desc">${esc(n.text)}</div></div>`).join("")}
      </div>
    </div>`;

  // gráfico
  const drawTab = k => { $("#chart").innerHTML = lineChart(d.snapshots, k); $$("#chartTabs button").forEach(b => b.classList.toggle("active", b.dataset.k === k)); };
  $$("#chartTabs button").forEach(b => b.onclick = () => drawTab(b.dataset.k));
  drawTab("playing");

  // análisis
  const showAnalysis = t => {
    $$("#anTabs button").forEach(b => b.classList.toggle("active", b.dataset.t === t));
    const src = t === "ai" ? d.ai : d.summary;
    if (!src) {
      $("#analysis").innerHTML = t === "ai" ? `<p class="muted">${d.ai_status.ready ? "Pulsa «Analizar con IA»." : esc(d.ai_status.reason)}</p>` : `<p class="muted">Sin análisis. Pulsa «Re-analizar mecánicas».</p>`;
      return;
    }
    const c = src.content || {};
    $("#analysis").innerHTML = `<dl class="summary">${META.ai_sections.map(([k, l]) => `<dt>${esc(l)}</dt><dd>${esc(Array.isArray(c[k]) ? c[k].join("; ") : (typeof c[k] === "object" && c[k] ? JSON.stringify(c[k]) : (c[k] ?? "No hay información suficiente")))}</dd>`).join("")}</dl>
      <p class="small muted">${esc(c._metodo || "")} Modelo: ${esc(src.model || "")} · ${fdate(src.created_at, true)}</p>
      <div class="note small">${esc(META.disclaimer)}</div>`;
  };
  $$("#anTabs button").forEach(b => b.onclick = () => showAnalysis(b.dataset.t));
  showAnalysis("rules");

  // mecánicas
  const groups = {};
  for (const m of META.taxonomy) (groups[m.group] = groups[m.group] || []).push(m);
  $("#mechList").innerHTML = Object.entries(groups).map(([gk, ms]) => `<div class="mech-group"><h3>${esc(META.groups[gk])}</h3>
    ${ms.map(m => {
      const r = rules[m.key], a = aiM[m.key];
      const ev = (r?.evidence || []).slice(0, 3).map(e => `<div>[${esc(e.source)}] <q>${esc(e.match)}</q> — ${esc(e.snippet)}</div>`).join("");
      return `<div class="mech-row"><div>${esc(m.label)}</div><div>${r ? badge(r.status) : badge(null)} ${a ? `<span class="small muted">IA:</span> ${badge(a)}` : ""}</div><div class="evidence">${ev}</div></div>`;
    }).join("")}</div>`).join("");

  // acciones
  $("#drefresh").onclick = async () => {
    const r = await api(`/api/games/${uid}/refresh`, { method: "POST" });
    toast("Actualización en curso (trabajo #" + r.job_id + ")");
    watchJob(r.job_id, null, () => { toast("Datos actualizados"); if (location.hash === "#/game/" + uid) renderGameDetail(uid); });
  };
  $("#danalyze").onclick = async () => { await api(`/api/games/${uid}/analyze`, { method: "POST" }); toast("Mecánicas re-analizadas"); renderGameDetail(uid); };
  $("#dai").onclick = async () => {
    if (!d.ai_status.ready) { toast(d.ai_status.reason, true); return; }
    $("#dai").disabled = true; $("#dai").textContent = "Analizando…";
    try { await api(`/api/games/${uid}/ai`, { method: "POST" }); toast("Análisis IA completado"); renderGameDetail(uid); }
    catch (e) { toast(e.message, true); $("#dai").disabled = false; $("#dai").textContent = "Analizar con IA"; }
  };
  $("#dcmp").onclick = () => { cmpToggle(g.universe_id); renderGameDetail(uid); };
  $("#nadd").onclick = async () => {
    const text = $("#ntext").value.trim();
    if (!text) { toast("Escribe algún texto", true); return; }
    await api(`/api/games/${uid}/notes`, { method: "POST", body: { source: $("#nsrc").value.trim() || "notas", text } });
    toast("Texto guardado y mecánicas re-analizadas"); renderGameDetail(uid);
  };
}
async function delNote(id, uid) { await api(`/api/notes/${id}`, { method: "DELETE" }); renderGameDetail(uid); }
window.delNote = delNote;

function itemsTable(items, isPass) {
  if (!items.length) return `<p class="muted small">Ninguno público o no disponible.</p>`;
  return `<div class="table-wrap" style="max-height:300px;overflow:auto"><table><tr><th>Nombre</th><th>Descripción</th>${isPass ? `<th class="num">Precio (R$)</th>` : `<th class="num">Otorgada</th>`}</tr>
    ${items.map(i => `<tr><td>${esc(i.name)}</td><td class="small">${esc((i.description || "").slice(0, 160))}</td><td class="num">${isPass ? fmt(i.price) : fmt(i.extra?.awardedCount)}</td></tr>`).join("")}</table></div>`;
}

function lineChart(snaps, key) {
  const pts = snaps.filter(s => s[key] !== null && s[key] !== undefined).map(s => ({ t: new Date(s.captured_at).getTime(), v: Number(s[key]) }));
  if (pts.length < 2) return `<p class="muted small">Se necesitan al menos 2 snapshots para mostrar la evolución. Vuelve a recolectar datos más tarde (botón «Actualizar datos» o Historial → Actualizar estadísticas).${pts.length === 1 ? ` Valor actual: ${fmt(pts[0].v, 2)}` : ""}</p>`;
  const W = 640, H = 220, L = 58, R = 12, T = 12, B = 30;
  const t0 = pts[0].t, t1 = pts[pts.length - 1].t || t0 + 1;
  let vmin = Math.min(...pts.map(p => p.v)), vmax = Math.max(...pts.map(p => p.v));
  if (vmin === vmax) { vmin -= 1; vmax += 1; }
  const x = t => L + (W - L - R) * (t1 === t0 ? 0.5 : (t - t0) / (t1 - t0));
  const y = v => T + (H - T - B) * (1 - (v - vmin) / (vmax - vmin));
  const tlabel = t => (t1 - t0 < 2 * 86400000) ? new Date(t).toLocaleString("es-CO", { dateStyle: "short", timeStyle: "short" }) : new Date(t).toLocaleDateString("es-CO");
  const path = pts.map((p, i) => `${i ? "L" : "M"}${x(p.t).toFixed(1)},${y(p.v).toFixed(1)}`).join(" ");
  const ticks = [vmin, (vmin + vmax) / 2, vmax];
  return `<svg class="chart" viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" role="img" aria-label="Evolución de ${esc(key)}">
    ${ticks.map(v => `<line x1="${L}" x2="${W - R}" y1="${y(v)}" y2="${y(v)}" stroke="currentColor" stroke-opacity=".1"/><text x="${L - 6}" y="${y(v) + 4}" text-anchor="end">${fmtShort(v)}</text>`).join("")}
    <path d="${path}" fill="none" stroke="var(--accent)" stroke-width="2"/>
    ${pts.map(p => `<circle cx="${x(p.t)}" cy="${y(p.v)}" r="3" fill="var(--accent)"><title>${new Date(p.t).toLocaleString("es-CO")}: ${p.v.toLocaleString("es-CO")}</title></circle>`).join("")}
    <text x="${L}" y="${H - 8}">${tlabel(t0)}</text>
    <text x="${W - R}" y="${H - 8}" text-anchor="end">${tlabel(t1)}</text></svg>`;
}

// ================================================================= DESCUBRIR / ANÁLISIS MASIVO
async function renderDiscover(isBatch) {
  const last = store(isBatch ? "batch_form" : "discover_form") || {};
  const modes = Object.entries(META.modes);
  view().innerHTML = `
    <h1>${isBatch ? "Análisis masivo" : "Descubrir juegos"}</h1>
    <p class="muted">${isBatch
      ? "Ejecuta todo el proceso: descubrir → recopilar datos → guardar → analizar mecánicas → estadísticas agregadas del lote."
      : "Descubre juegos automáticamente desde fuentes públicas de Roblox y guarda sus datos."}</p>
    <div class="panel">
      <div class="form-grid">
        <label>Método de descubrimiento<select id="dmode">${optionList(isBatch ? modes : modes, last.mode || "category")}</select></label>
        <label data-for="category">Categoría / género<select id="dcat">${optionList(META.categories, last.category || "Horror")}</select></label>
        <label data-for="keyword">Palabra clave<input type="text" id="dkw" value="${esc(last.keyword || "")}" placeholder="p. ej. zombie"></label>
        <label data-for="sort">Lista oficial (sortId)<select id="dsortid">${optionList(META.known_sorts, last.sort_id || "top-trending")}</select></label>
        <label>Cantidad máxima de juegos<input type="number" id="dlimit" min="1" max="${META.settings.HARD_MAX_RESULTS}" value="${last.limit || META.settings.MAX_RESULTS}" list="limits"></label>
        <datalist id="limits"><option value="10"><option value="50"><option value="100"><option value="500"><option value="1000"></datalist>
        <label>Criterio de ordenamiento<select id="dsort">${optionList(Object.entries(META.sort_criteria), last.sort_by || "playing")}</select></label>
        <label>Juegos por lote (solicitud)<input type="number" id="dbatch" min="1" max="50" value="${last.batch_size || META.settings.BATCH_SIZE}"></label>
        <label data-for="ids" data-for2="related">ID interpretado como<select id="didtype">${optionList([["auto", "Automático"], ["universe", "universeId"], ["place", "placeId"]], last.id_type || "auto")}</select></label>
      </div>
      <label data-for="ids" data-for2="related" style="margin-top:10px">IDs (separados por coma, espacio o línea)<textarea id="dids" placeholder="994732206, 1686885941">${esc(last.ids_text || "")}</textarea></label>
      <label data-for="urls" data-for2="related" style="margin-top:10px">URLs de Roblox (una por línea)<textarea id="durls" placeholder="https://www.roblox.com/games/2753915549/Blox-Fruits">${esc(last.urls_text || "")}</textarea></label>
      <div class="toolbar" style="margin-top:10px">
        ${isBatch ? "" : `<label class="inline"><input type="checkbox" id="danalyze" ${last.analyze !== false ? "checked" : ""}> Analizar mecánicas al terminar</label>`}
        <label class="inline" data-for="category"><input type="checkbox" id="dstrict" ${last.strict_genre ? "checked" : ""}> Solo juegos cuyo género oficial de Roblox coincida</label>
        <label class="inline"><input type="checkbox" id="duseai" ${last.use_ai ? "checked" : ""} ${META.ai.ready ? "" : "disabled"}> Usar IA ${META.ai.ready ? "" : "(no configurada)"}</label>
      </div>
      <div id="modeHelp" class="small muted"></div>
      <div style="margin-top:10px"><button id="drun">${isBatch ? "Analizar lote" : "Descubrir y recopilar"}</button></div>
    </div>
    <div id="jobBox" class="panel hidden"></div>
    <div id="results"></div>`;
  const help = {
    category: "Combina listas oficiales de tendencia del género (explore-api) con la búsqueda pública (search-api). Las categorías sin género oficial (Horror, Tycoon, Anime) usan solo la búsqueda.",
    popular: "Listas oficiales: Most Popular, Top Playing Now, Top Revisited, Top Rated (≈100 juegos cada una).",
    trending: "Listas oficiales: Top Trending y Up-and-Coming. Si se piden más juegos de los disponibles se completa con Top Playing Now.",
    related: "Parte de uno o más juegos semilla y recorre sus recomendaciones públicas (2 niveles).",
    keyword: "Búsqueda pública de Roblox por cualquier término.",
    ids: "Lista de universeId o placeId (modo Automático prueba ambos).",
    urls: "URLs del tipo roblox.com/games/<placeId>/… Se convierten a universeId con la API pública.",
    sort: "Una lista concreta de la página Charts de Roblox.",
  };
  const upd = () => {
    const m = $("#dmode").value;
    $$("[data-for]").forEach(el => el.classList.toggle("hidden", el.dataset.for !== m && el.dataset.for2 !== m));
    $("#modeHelp").textContent = help[m] || "";
  };
  $("#dmode").onchange = upd; upd();
  $("#drun").onclick = async () => {
    const params = {
      mode: $("#dmode").value, category: $("#dcat").value, keyword: $("#dkw").value.trim(),
      limit: Number($("#dlimit").value) || 50, sort_by: $("#dsort").value, batch_size: Number($("#dbatch").value) || 50,
      id_type: $("#didtype").value, ids_text: $("#dids").value, urls_text: $("#durls").value,
      strict_genre: $("#dstrict").checked, use_ai: $("#duseai").checked, sort_ids: [$("#dsortid").value], sort_id: $("#dsortid").value,
      analyze: isBatch ? true : $("#danalyze").checked,
    };
    if (params.mode !== "category") params.category = params.mode === "keyword" ? null : params.category;
    if (params.mode !== "category" && params.mode !== "keyword") params.category = null;
    store(isBatch ? "batch_form" : "discover_form", params);
    try {
      const r = await api("/api/jobs", { method: "POST", body: { type: isBatch ? "batch" : "discover", params } });
      $("#drun").disabled = true;
      const box = $("#jobBox"); box.classList.remove("hidden");
      box.innerHTML = `Trabajo #${r.job_id} en cola…`;
      $("#results").innerHTML = "";
      watchJob(r.job_id, j => { box.innerHTML = jobProgressHtml(j); }, async j => {
        box.innerHTML = jobProgressHtml(j);
        $("#drun").disabled = false;
        if (j.status === "done") { toast(j.message); await showJobResults(j, isBatch || params.analyze); }
      });
    } catch (e) { toast(e.message, true); }
  };
}

async function showJobResults(j, withStats) {
  const games = await api("/api/games?" + qs({ job_id: j.id, page_size: 500, sort: "playing" }));
  let html = "";
  if (withStats) {
    const p = await api("/api/patterns?job_id=" + j.id);
    html += `<div class="panel"><h2 style="margin-top:0">Resultado del lote #${j.id}</h2>
      <div class="kpis">${kpi("Descubiertos", fmt(j.result.found))}${kpi("Guardados", fmt(j.result.saved))}${kpi("Analizados", fmt(j.result.analyzed))}
        ${kpi("Jugadores totales", fmt(p.overview.total_playing))}${kpi("Promedio jugadores", fmt(p.overview.avg_playing))}${kpi("Aprobación media", pct(p.overview.avg_like_ratio))}</div>
      ${mechTable(p.mechanics.filter(m => !m.derived))}
      <div class="note small">${esc(p.disclaimer)}</div>
      <div class="toolbar"><a href="#/patterns" onclick="store('patterns_filter',{job_id:${j.id}})"><button class="secondary">Ver patrones del lote</button></a>
        <a href="/api/export/html?view=1&job_id=${j.id}" target="_blank"><button class="secondary">Informe HTML</button></a>
        <a href="/api/export/xlsx?job_id=${j.id}"><button class="secondary">Excel</button></a>
        <a href="/api/export/csv?job_id=${j.id}"><button class="secondary">CSV</button></a></div></div>`;
  }
  html += `<div class="panel"><h3>Juegos del lote (${games.total})</h3><div class="table-wrap"><table>
    <tr><th>#</th><th>Nombre</th><th class="num">Jugadores</th><th class="num">Visitas</th><th class="num">Favoritos</th><th class="num">Likes</th><th>Género</th></tr>
    ${games.rows.map((r, i) => `<tr class="clickable" onclick="location.hash='#/game/${r.universe_id}'"><td>${i + 1}</td><td><div class="name-cell">${iconImg(r.icon_url)}<span>${esc(r.name)}</span></div></td>
      <td class="num">${fmt(r.playing)}</td><td class="num">${fmt(r.visits)}</td><td class="num">${fmt(r.favorites)}</td><td class="num">${fmt(r.up_votes)}</td><td>${esc(r.genre_l1 || NA)}</td></tr>`).join("")}</table></div></div>`;
  $("#results").innerHTML = html;
}

function mechTable(mechs, clickable = false) {
  const sorted = [...mechs].sort((a, b) => (b.percent ?? -1) - (a.percent ?? -1));
  return `<div class="table-wrap"><table><tr><th>Grupo</th><th>Mecánica</th><th class="num">Juegos donde aparece</th><th class="num">Juegos con info</th><th class="num">Porcentaje</th><th style="width:22%"></th><th class="num">Probable</th></tr>
    ${sorted.map(m => `<tr ${clickable ? `class="clickable" onclick="showMechGames('${m.key}')"` : ""}><td class="small muted">${esc(m.group_label)}</td><td>${esc(m.label)}</td>
      <td class="num">${fmt(m.count)}</td><td class="num">${fmt(m.games_with_info)}</td><td class="num">${pct(m.percent)}</td><td>${bar(m.percent)}</td><td class="num">${fmt(m.probable)}</td></tr>`).join("")}</table></div>
    <p class="small muted">Porcentaje = juegos con la mecánica «Detectada» ÷ juegos con información suficiente para esa mecánica.</p>`;
}

// ================================================================= MECÁNICAS
async function renderMechanics() {
  const f = store("mech_filter") || {};
  const cats = await api("/api/categories");
  view().innerHTML = `<h1>Mecánicas</h1>
    <p class="muted">Frecuencia de cada mecánica en los juegos analizados. Haz clic en una fila para ver los juegos y la evidencia.</p>
    <div class="panel"><div class="toolbar">
      <label>Categoría<select id="mcat">${optionList(cats.map(c => [c.category, `${c.category} (${c.n})`]), f.category, "Todas")}</select></label>
      <label>Lote (job)<input type="number" id="mjob" style="width:90px" value="${esc(f.job_id || "")}"></label>
      <label class="inline"><input type="checkbox" id="mprob" ${f.include_probable ? "checked" : ""}> Contar «Probable» como presente</label>
      <button id="mapply">Aplicar</button></div>
      <div id="mtable"></div></div>
    <div id="mgames"></div>`;
  const load = async () => {
    const q = { category: $("#mcat").value, job_id: $("#mjob").value, include_probable: $("#mprob").checked ? 1 : "" };
    store("mech_filter", q);
    const d = await api("/api/mechanics?" + qs(q));
    $("#mtable").innerHTML = `<p class="small">${fmt(d.n_analyzed)} juegos analizados de ${fmt(d.n_games)}.</p>` + mechTable(d.mechanics.filter(m => !m.derived), true);
  };
  $("#mapply").onclick = load;
  await load();
}
async function showMechGames(key) {
  const d = await api(`/api/mechanics/${key}/games`);
  $("#mgames").innerHTML = `<div class="panel"><h3>${esc(d.mechanic)} — juegos (Detectada / Probable)</h3><div class="table-wrap"><table>
    <tr><th>Juego</th><th>Estado</th><th class="num">Jugadores</th><th>Evidencia</th></tr>
    ${d.rows.map(r => `<tr class="clickable" onclick="location.hash='#/game/${r.universe_id}'"><td><div class="name-cell">${iconImg(r.icon_url)}<span>${esc(r.name)}</span></div></td>
      <td>${badge(r.status)}</td><td class="num">${fmt(r.playing)}</td><td class="evidence">${r.evidence.map(e => `[${esc(e.source)}] <q>${esc(e.match)}</q> ${esc(e.snippet)}`).join("<br>")}</td></tr>`).join("") || `<tr><td class="muted">Ningún juego.</td></tr>`}</table></div></div>`;
  $("#mgames").scrollIntoView({ behavior: "smooth" });
}
window.showMechGames = showMechGames;

// ================================================================= COMPARADOR
async function renderCompare() {
  const ids = cmpGet();
  view().innerHTML = `<h1>Comparador</h1>
    <p class="muted">Muestra datos y diferencias entre juegos. No genera rankings de «mejor juego».</p>
    <div class="panel"><div class="toolbar">
      <label>Añadir juego (buscar)<input type="text" id="csearch" placeholder="Nombre o ID" style="width:260px"></label>
      <button class="secondary" id="cclear">Vaciar comparador</button></div>
      <div id="cresults"></div></div>
    <div id="ctable"></div>`;
  $("#cclear").onclick = () => { cmpSet([]); renderCompare(); };
  let h;
  $("#csearch").oninput = e => {
    clearTimeout(h);
    h = setTimeout(async () => {
      const q = e.target.value.trim();
      if (!q) { $("#cresults").innerHTML = ""; return; }
      const r = await api("/api/games?" + qs({ q, page_size: 8 }));
      $("#cresults").innerHTML = r.rows.map(g => `<div class="row" style="align-items:center;margin:4px 0">${iconImg(g.icon_url)} ${esc(g.name)} <button class="small" onclick="cmpToggle(${g.universe_id});renderCompare()">${cmpGet().includes(g.universe_id) ? "Quitar" : "Añadir"}</button></div>`).join("") || `<span class="muted small">Sin resultados</span>`;
    }, 250);
  };
  if (ids.length < 2) {
    $("#ctable").innerHTML = `<div class="info">Selecciona al menos 2 juegos (casillas en «Juegos», botón en el detalle o buscador de arriba). Seleccionados: ${ids.length}.</div>`;
    if (!ids.length) return;
  }
  const games = await api("/api/compare?ids=" + ids.join(","));
  if (!games.length) return;
  const now = Date.now();
  const rowsDef = [
    ["Jugadores actuales", g => fmt(g.playing), g => g.playing], ["Visitas", g => fmt(g.visits), g => g.visits], ["Favoritos", g => fmt(g.favorites), g => g.favorites],
    ["Likes", g => fmt(g.up_votes), g => g.up_votes], ["Dislikes", g => fmt(g.down_votes)], ["Aprobación %", g => pct(g.like_ratio), g => g.like_ratio],
    ["Antigüedad (días)", g => g.created ? fmt(Math.floor((now - new Date(g.created)) / 86400000)) : fmt(null)],
    ["Creado", g => fdate(g.created)], ["Actualizado", g => fdate(g.updated)], ["Creador", g => esc(g.creator_name || NA)],
    ["Género Roblox", g => esc([g.genre_l1, g.genre_l2].filter(Boolean).join(" / ") || NA)], ["Categorías", g => esc(g.categories.join(", ") || NA)],
    ["Máx. jugadores/servidor", g => fmt(g.max_players)], ["Gamepasses públicos", g => fmt(g.gamepass_count)],
    ["Precios gamepasses (R$)", g => g.gamepass_prices && g.gamepass_prices.n ? `${fmt(g.gamepass_prices.mn)} – ${fmt(g.gamepass_prices.mx)}` : fmt(null)],
    ["Insignias públicas", g => fmt(g.badge_count)], ["Servidores privados", g => g.extra?.createVipServersAllowed == null ? fmt(null) : (g.extra.createVipServersAllowed ? "Sí" : "No")],
    ["Acceso de pago", g => g.price ? g.price + " R$" : "Gratis"], ["Snapshot", g => fdate(g.captured_at, true)],
  ];
  let html = `<div class="table-wrap"><table class="cmp"><tr><th>Dato</th>${games.map(g => `<th><div class="name-cell">${iconImg(g.icon_url)}<a href="#/game/${g.universe_id}">${esc(g.name)}</a></div></th>`).join("")}</tr>`;
  for (const [label, f, num] of rowsDef) {
    let extra = "";
    if (num) {
      const vals = games.map(num).filter(v => v !== null && v !== undefined);
      if (vals.length > 1) { const mx = Math.max(...vals), mn = Math.min(...vals); extra = mn > 0 ? ` <span class="small muted">(dif. ×${(mx / mn).toFixed(1)})</span>` : ""; }
    }
    html += `<tr><td>${label}${extra}</td>${games.map(g => `<td>${f(g)}</td>`).join("")}</tr>`;
  }
  let lastGroup = "";
  for (const m of META.taxonomy.filter(m => !m.derived)) {
    if (m.group !== lastGroup) { html += `<tr><td colspan="${games.length + 1}"><b>${esc(META.groups[m.group])}</b></td></tr>`; lastGroup = m.group; }
    const sts = games.map(g => g.mechanics[m.key]);
    const differs = new Set(sts.map(s => s || "")).size > 1;
    html += `<tr><td>${esc(m.label)}${differs ? ` <span class="small" title="Difiere entre juegos">≠</span>` : ""}</td>${sts.map(s => `<td>${badge(s)}</td>`).join("")}</tr>`;
  }
  html += `</table></div><p class="small muted">≠ marca mecánicas cuyo estado difiere entre los juegos seleccionados.</p>`;
  $("#ctable").innerHTML = html;
}
window.cmpToggle = cmpToggle; window.renderCompare = renderCompare;

// ================================================================= PATRONES
async function renderPatterns() {
  const f = store("patterns_filter") || {};
  store("patterns_filter", null);
  const cats = await api("/api/categories");
  const jobs = (await api("/api/jobs?limit=50")).filter(j => j.status === "done" && j.n_games);
  view().innerHTML = `<h1>Patrones encontrados</h1>
    <div class="panel"><div class="toolbar">
      <label>Lote<select id="pjob">${optionList(jobs.map(j => [j.id, `#${j.id} ${META.job_types[j.type]} ${j.params.category || j.params.keyword || j.params.mode || ""} (${j.n_games})`]), f.job_id, "Todos los juegos")}</select></label>
      <label>Categoría<select id="pcat">${optionList(cats.map(c => [c.category, `${c.category} (${c.n})`]), f.category, "Todas")}</select></label>
      <label class="inline"><input type="checkbox" id="pprob"> Contar «Probable» como presente</label>
      <button id="papply">Aplicar</button></div></div>
    <div id="pbody"></div>`;
  const load = async () => {
    const q = { job_id: $("#pjob").value, category: $("#pjob").value ? "" : $("#pcat").value, include_probable: $("#pprob").checked ? 1 : "" };
    const p = await api("/api/patterns?" + qs(q));
    if (!p.n_analyzed) { $("#pbody").innerHTML = `<div class="info">No hay juegos analizados con este filtro.</div>`; return; }
    $("#pbody").innerHTML = `
      <div class="note"><b>Importante:</b> ${esc(p.disclaimer)}</div>
      <div class="panel"><h3>Después de analizar ${fmt(p.n_analyzed)} juegos:</h3>
        <ul>${p.groups.map(g => `<li><b>${pct(g.percent)}</b> presentan al menos una mecánica de <b>${esc(g.label)}</b> (${g.count} de ${g.games_with_info} con información)</li>`).join("")}</ul>
        <h3>Mecánicas más frecuentes</h3><ul>${p.highlights.map(h => `<li>${esc(h)}</li>`).join("")}</ul></div>
      <div class="row">
        <div class="panel grow"><h3>Combinaciones frecuentes de mecánicas</h3>
          <table><tr><th>Combinación</th><th class="num">Juegos</th><th class="num">%</th></tr>
          ${p.combinations.map(c => `<tr><td>${c.labels.map(esc).join(" + ")}</td><td class="num">${c.count}</td><td class="num">${pct(c.percent)}</td></tr>`).join("") || `<tr><td class="muted">Sin combinaciones con soporte suficiente.</td></tr>`}</table></div>
        <div class="panel grow"><h3>Combinaciones de grupos</h3>
          <table><tr><th>Combinación</th><th class="num">Juegos</th><th class="num">%</th></tr>
          ${p.group_combinations.map(c => `<tr><td>${c.labels.map(esc).join(" + ")}</td><td class="num">${c.count}</td><td class="num">${pct(c.percent)}</td></tr>`).join("") || `<tr><td class="muted">—</td></tr>`}</table>
          <p class="small muted">Base: juegos con información suficiente (${p.combinations[0]?.base ?? p.group_combinations[0]?.base ?? 0}).</p></div>
      </div>
      <div class="panel"><h3>Asociaciones observadas con jugadores actuales</h3>
        <p class="small muted">Mediana de jugadores en juegos CON la mecánica frente a juegos SIN ella (mín. 3 en cada grupo). Existe una asociación observada en esta muestra, pero esto no demuestra causalidad: los juegos grandes suelen tener descripciones más largas, más gamepasses, etc.</p>
        <div class="table-wrap"><table><tr><th>Mecánica</th><th>Grupo</th><th class="num">Mediana con</th><th class="num">Mediana sin</th><th class="num">n con / sin</th><th class="num">Ratio</th></tr>
        ${p.associations.map(a => `<tr><td>${esc(a.label)}</td><td class="small muted">${esc(a.group_label)}</td><td class="num">${fmt(a.median_with)}</td><td class="num">${fmt(a.median_without)}</td><td class="num">${a.n_with} / ${a.n_without}</td><td class="num">${a.ratio ?? NA}</td></tr>`).join("") || `<tr><td class="muted">Muestra insuficiente.</td></tr>`}</table></div></div>
      <div class="panel"><h3>Tabla completa</h3>${mechTable(p.mechanics.filter(m => !m.derived))}</div>`;
  };
  $("#papply").onclick = load;
  await load();
}

// ================================================================= HISTORIAL
async function renderHistory() {
  const [h, jobs, errs] = await Promise.all([api("/api/history"), api("/api/jobs?limit=50"), api("/api/errors?limit=40")]);
  view().innerHTML = `<h1>Historial</h1>
    <div class="panel"><div class="toolbar">
      <button id="hrefresh">Actualizar estadísticas de todos los juegos (nuevo snapshot)</button>
      <button class="secondary" id="hrefreshx">…incluyendo gamepasses/insignias</button>
      <button class="secondary" id="hreanalyze">Re-analizar mecánicas de todos</button>
      <button class="secondary" id="hcache">Vaciar caché HTTP</button></div>
      <p class="small muted">Snapshots: ${fmt(h.totals.n)} de ${fmt(h.totals.g)} juegos · primero ${fdate(h.totals.first, true)} · último ${fdate(h.totals.last, true)}</p>
      <div id="hjob"></div></div>
    <div class="panel"><h3>Cambios entre los dos últimos snapshots</h3>
      ${h.changes.length ? `<div class="table-wrap"><table><tr><th>Juego</th><th>Anterior</th><th>Último</th><th class="num">Jugadores antes</th><th class="num">Jugadores ahora</th><th class="num">Cambio</th><th class="num">Visitas +</th></tr>
      ${h.changes.map(c => `<tr class="clickable" onclick="location.hash='#/game/${c.universe_id}'"><td>${esc(c.name)}</td><td class="small">${fdate(c.prev_at, true)}</td><td class="small">${fdate(c.last_at, true)}</td>
        <td class="num">${fmt(c.prev_playing)}</td><td class="num">${fmt(c.last_playing)}</td>
        <td class="num" style="color:${(c.delta_playing || 0) >= 0 ? "var(--ok)" : "var(--bad)"}">${c.delta_playing > 0 ? "+" : ""}${fmt(c.delta_playing)} ${c.delta_playing_pct != null ? `(${c.delta_playing_pct > 0 ? "+" : ""}${fmt(c.delta_playing_pct, 1)}%)` : ""}</td>
        <td class="num">${fmt(c.delta_visits)}</td></tr>`).join("")}</table></div>` : `<p class="muted">Aún no hay juegos con 2 o más snapshots. Pulsa «Actualizar estadísticas» otro día (o tras ${esc(META.settings.MIN_SNAPSHOT_MINUTES ?? 30)} minutos).</p>`}
    </div>
    <div class="row">
      <div class="panel grow"><h3>Trabajos</h3><div class="table-wrap"><table><tr><th>#</th><th>Tipo</th><th>Parámetros</th><th>Estado</th><th>Juegos</th><th>Inicio</th><th></th></tr>
        ${jobs.map(j => `<tr><td>${j.id}</td><td>${esc(META.job_types[j.type] || j.type)}</td><td class="small">${esc([j.params.mode, j.params.category, j.params.keyword, j.params.limit && ("n=" + j.params.limit), j.params.sort_by].filter(Boolean).join(" · "))}</td>
          <td class="status-${j.status}" title="${esc(j.message || "")}">${esc(j.status)}</td><td>${j.n_games || ""}</td><td class="small">${fdate(j.created_at, true)}</td>
          <td>${["running", "queued"].includes(j.status) ? `<button class="secondary small" onclick="cancelJob(${j.id})">Cancelar</button>` : (j.n_games ? `<a href="#/games" onclick="store('games_filter',{job_id:${j.id}})">ver</a>` : "")}</td></tr>`).join("") || `<tr><td class="muted">Sin trabajos</td></tr>`}</table></div></div>
      <div class="panel grow"><h3>Registro de errores (API)</h3><div class="table-wrap" style="max-height:420px;overflow:auto"><table><tr><th>Fecha</th><th>Contexto</th><th>Mensaje</th></tr>
        ${errs.map(e => `<tr><td class="small">${fdate(e.ts, true)}</td><td class="small">${esc(e.context)}</td><td class="small" title="${esc(e.url || "")}">${esc(e.message)}</td></tr>`).join("") || `<tr><td class="muted">Sin errores</td></tr>`}</table></div>
        <p class="small muted">Registro completo en logs/app.log</p></div>
    </div>`;
  const run = async (type, params, label) => {
    const r = await api("/api/jobs", { method: "POST", body: { type, params } });
    toast(label + " (trabajo #" + r.job_id + ")");
    watchJob(r.job_id, j => { $("#hjob") && ($("#hjob").innerHTML = jobProgressHtml(j)); }, () => { if (location.hash.startsWith("#/history")) renderHistory(); });
  };
  $("#hrefresh").onclick = () => run("refresh", {}, "Actualizando estadísticas");
  $("#hrefreshx").onclick = () => run("refresh", { extras: true }, "Actualizando datos completos");
  $("#hreanalyze").onclick = () => run("reanalyze", {}, "Re-analizando");
  $("#hcache").onclick = async () => { await api("/api/cache/clear", { method: "POST" }); toast("Caché vaciada"); };
}

// ================================================================= EXPORTAR
async function renderExport() {
  const cats = await api("/api/categories");
  const jobs = (await api("/api/jobs?limit=50")).filter(j => j.status === "done" && j.n_games);
  view().innerHTML = `<h1>Exportar</h1>
    <div class="panel"><div class="toolbar">
      <label>Alcance<select id="ejob">${optionList(jobs.map(j => [j.id, `Lote #${j.id} ${j.params.category || j.params.keyword || j.params.mode || ""} (${j.n_games})`]), "", "Todos los juegos")}</select></label>
      <label>Categoría<select id="ecat">${optionList(cats.map(c => [c.category, c.category]), "", "Todas")}</select></label>
      <label class="inline"><input type="checkbox" id="eprob"> Contar «Probable» en patrones</label></div>
      <h3>Archivos</h3>
      <div class="toolbar">
        <button data-f="csv" data-w="games">CSV — Juegos</button>
        <button data-f="csv" data-w="mechanics" class="secondary">CSV — Mecánicas por juego</button>
        <button data-f="csv" data-w="patterns" class="secondary">CSV — Frecuencia de mecánicas</button>
        <button data-f="csv" data-w="snapshots" class="secondary">CSV — Snapshots</button>
        <button data-f="json" class="secondary">JSON completo</button>
        <button data-f="xlsx" class="secondary">Excel (.xlsx)</button>
        <button data-f="html" class="secondary">Informe HTML</button>
        <button data-f="html" data-view="1" class="secondary">Ver informe en el navegador</button>
      </div>
      <p class="small muted">El informe HTML incluye: Resumen, Estadísticas, Mecánicas, Patrones y Datos de los juegos. Los CSV incluyen BOM UTF-8 para abrirse correctamente en Excel.</p></div>`;
  $$("[data-f]").forEach(b => b.onclick = () => {
    const q = qs({ job_id: $("#ejob").value, category: $("#ejob").value ? "" : $("#ecat").value, include_probable: $("#eprob").checked ? 1 : "", what: b.dataset.w, view: b.dataset.view });
    const url = `/api/export/${b.dataset.f}?${q}`;
    if (b.dataset.view) window.open(url, "_blank"); else location.href = url;
  });
}

// ================================================================= CONFIGURACIÓN
async function renderSettings() {
  const { settings: s, ai } = await api("/api/settings");
  const num = (k, label, step = 1, help = "") => `<label>${label}<input type="number" step="${step}" data-k="${k}" value="${esc(s[k])}">${help ? `<span class="small">${help}</span>` : ""}</label>`;
  const chk = (k, label) => `<label class="inline"><input type="checkbox" data-k="${k}" ${s[k] ? "checked" : ""}> ${label}</label>`;
  view().innerHTML = `<h1>Configuración</h1>
    <div class="panel"><h3>Descubrimiento y API de Roblox</h3><div class="form-grid">
      ${num("MAX_RESULTS", "Cantidad máxima de resultados (por defecto)", 1, `máx. ${s.HARD_MAX_RESULTS}`)}
      ${num("BATCH_SIZE", "Tamaño del lote (IDs por solicitud, 1–50)")}
      ${num("REQUEST_INTERVAL", "Intervalo entre solicitudes (seg, mín. 0.2)", 0.1)}
      ${num("REQUEST_TIMEOUT", "Timeout (seg)")}
      ${num("MAX_RETRIES", "Reintentos máximos")}
      ${num("CACHE_TTL_STATS", "Caché de estadísticas (seg)")}
      ${num("CACHE_TTL_STATIC", "Caché de gamepasses/insignias (seg)")}
      ${num("MIN_SNAPSHOT_MINUTES", "Minutos mínimos entre snapshots")}
      ${num("OVERSAMPLE_FACTOR", "Factor de candidatos extra al ordenar", 0.1)}
      ${num("MAX_SERVER_PAGES", "Páginas de servidores a contar (100 c/u)")}
      ${num("UI_PAGE_SIZE", "Filas por página en tablas")}
    </div>
    <div class="toolbar" style="margin-top:10px">${chk("FETCH_GAMEPASSES", "Recopilar gamepasses")} ${chk("FETCH_BADGES", "Recopilar insignias")} ${chk("FETCH_SERVERS", "Contar servidores públicos (más lento)")}</div></div>
    <div class="panel"><h3>Análisis con IA (opcional)</h3>
      <div class="info small">Estado: ${ai.ready ? "<b>listo</b>" : esc(ai.reason)}. La API key se guarda en el archivo <code>.env</code>, nunca en el código ni en la base de datos.</div>
      <div class="toolbar">${chk("AI_ENABLED", "Habilitar análisis IA")}</div>
      <div class="form-grid">
        <label>Proveedor<select data-k="AI_PROVIDER">${optionList([["anthropic", "Anthropic (Claude)"], ["openai", "OpenAI o compatible"]], s.AI_PROVIDER)}</select></label>
        <label>Modelo<input type="text" data-k="AI_MODEL" value="${esc(s.AI_MODEL)}" placeholder="nombre exacto del modelo"></label>
        <label>URL base (solo compatibles OpenAI)<input type="text" data-k="AI_BASE_URL" value="${esc(s.AI_BASE_URL)}" placeholder="https://api.openai.com/v1"></label>
        ${num("AI_MAX_TOKENS", "Máx. tokens de respuesta")}
        <label>API key ${s.AI_API_KEY_SET ? `(configurada ${esc(s.AI_API_KEY_HINT)})` : "(no configurada)"}<input type="password" id="apikey" placeholder="${s.AI_API_KEY_SET ? "dejar vacío para mantener" : "pega tu clave"}" autocomplete="off"></label>
      </div>
      ${s.AI_API_KEY_SET ? `<label class="inline" style="margin-top:8px"><input type="checkbox" id="apiclear"> Borrar la API key guardada</label>` : ""}</div>
    <div class="panel"><h3>Base de datos</h3>
      <label>Ubicación (relativa a la carpeta del proyecto o absoluta)<input type="text" data-k="DB_PATH" value="${esc(s.DB_PATH)}"></label>
      <p class="small muted">Ruta actual: ${esc(s.DB_PATH_RESOLVED)}. Al cambiarla se crea/usa esa base de datos (los datos de la anterior no se mueven).</p></div>
    <button id="ssave">Guardar configuración</button>`;
  $("#ssave").onclick = async () => {
    const data = {};
    $$("[data-k]").forEach(el => { data[el.dataset.k] = el.type === "checkbox" ? el.checked : el.value; });
    const key = $("#apikey").value.trim();
    if (key) data.AI_API_KEY = key;
    if ($("#apiclear") && $("#apiclear").checked) data.AI_API_KEY_CLEAR = true;
    try {
      const r = await api("/api/settings", { method: "POST", body: data });
      META = await api("/api/meta");
      toast(r.note || "Guardado");
      renderSettings();
    } catch (e) { toast(e.message, true); }
  };
}

// ================================================================= inicio
(async function init() {
  try { META = await api("/api/meta"); }
  catch (e) { view().innerHTML = `<div class="panel">${esc(e.message)}</div>`; return; }
  updateCmpCount();
  window.addEventListener("hashchange", router);
  router();
  setInterval(pollJobs, 2000);
  pollJobs();
})();
