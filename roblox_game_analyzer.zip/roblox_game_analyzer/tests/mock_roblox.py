"""Servidor SIMULADO de las APIs públicas de Roblox — SOLO PARA PRUEBAS.

Reproduce el formato real de las respuestas (verificado en sept. 2026) con datos
ficticios deterministas. También simula errores: HTTP 429 ocasionales, un 500,
juegos eliminados (IDs que no devuelve /v1/games) y descripciones vacías.

Uso:
    python tests/mock_roblox.py            # escucha en http://127.0.0.1:9100
    set ROBLOX_MOCK_BASE=http://127.0.0.1:9100  (Windows)  y luego  python main.py
"""
import random
import sys
import threading

from flask import Flask, jsonify, request

app = Flask(__name__)
R = random.Random(42)
ADJ = ["Scary", "Mega", "Epic", "Dark", "Haunted", "Super", "Tiny", "Blox", "Pet", "Anime", "Zombie", "Speed", "Ninja", "Pirate"]
NOUN = ["Simulator", "Tycoon", "Obby", "Hospital", "Mansion", "Battlegrounds", "Survival", "Island", "Legends", "Escape", "Racing", "Defense"]
SNIPPETS = [
    "Collect rare pets and hatch eggs to complete your index!", "Defeat bosses and level up your skills.",
    "Explore 5 worlds and unlock new zones.", "Survive the night and escape the monster!",
    "Trade with friends and team up in co-op missions.", "Claim daily rewards and keep your login streak.",
    "New Halloween event! Limited-time items.", "Buy the VIP gamepass for 2x coins.",
    "Build your base and craft weapons.", "Complete quests to earn gems and chests.",
    "Race your cars and compete on the leaderboard.", "Solve puzzles to open the doors, stay hidden.",
    "Redeem codes for free rewards!", "Rebirth to get permanent upgrades.", "PvP arena with ranked matchmaking.",
]
GENRES = [("Horror", "Survival", "Horror"), ("Simulation", "Simulation", "Incremental Simulator"), ("RPG", "RPG", "Action RPG"),
          ("Obby", "Obby & Platformer", "Classic Obby"), ("Shooter", "Shooter", "Deathmatch Shooter"),
          ("Adventure", "Adventure", "Exploration"), ("Survival", "Survival", "1 vs All")]

GAMES = {}
for i in range(1, 1601):
    uid = 1000 + i
    g = R.choice(GENRES)
    desc = " ".join(R.sample(SNIPPETS, R.randint(0, 5)))
    GAMES[uid] = {
        "id": uid, "rootPlaceId": 50000 + i, "name": f"{R.choice(ADJ)} {R.choice(NOUN)} {i}",
        "description": desc, "sourceName": None, "sourceDescription": None,
        "creator": {"id": 700 + i % 90, "name": f"Studio {i % 90}", "type": "Group" if i % 3 else "User",
                    "isRNVAccount": False, "hasVerifiedBadge": i % 7 == 0},
        "price": 25 if i % 97 == 0 else None, "allowedGearGenres": [g[0]], "allowedGearCategories": [],
        "isGenreEnforced": True, "copyingAllowed": False, "playing": int(R.paretovariate(1.2) * 50),
        "visits": int(R.paretovariate(1.1) * 100000), "maxPlayers": R.choice([6, 12, 20, 30]),
        "created": f"20{R.randint(18, 26)}-0{R.randint(1, 9)}-1{R.randint(0, 9)}T10:00:00.000Z",
        "updated": f"2026-0{R.randint(1, 9)}-2{R.randint(0, 3)}T10:00:00.000Z",
        "studioAccessToApisAllowed": False, "createVipServersAllowed": i % 4 == 0,
        "universeAvatarType": "MorphToR15", "genre": g[0], "genre_l1": g[1], "genre_l2": g[2],
        "isAllGenre": False, "isFavoritedByUser": False, "favoritedCount": int(R.paretovariate(1.2) * 2000),
        "canonicalUrlPath": f"/games/{50000 + i}/Game-{i}",
    }
DELETED = {1000 + i for i in range(5, 1601, 37)}  # simulan juegos eliminados/privados
PLACE_TO_UNI = {g["rootPlaceId"]: uid for uid, g in GAMES.items()}
_lock = threading.Lock()
_counter = {"n": 0}


def maybe_429():
    with _lock:
        _counter["n"] += 1
        n = _counter["n"]
    if n % 53 == 0:
        return jsonify({"errors": [{"code": 0, "message": "Too many requests"}]}), 429, {"Retry-After": "1"}
    if n % 211 == 0:
        return jsonify({"errors": [{"code": 0, "message": "Internal"}]}), 500
    return None


def explore_item(g):
    return {"universeId": g["id"], "rootPlaceId": g["rootPlaceId"], "name": g["name"], "playerCount": g["playing"],
            "totalUpVotes": g["playing"] * 30, "totalDownVotes": g["playing"] * 4, "isSponsored": False,
            "nativeAdData": "", "contentType": "Game", "contentId": g["id"], "minimumAge": 0}


@app.get("/games/v1/games")
def games():
    if (e := maybe_429()):
        return e
    ids = [int(x) for x in request.args.get("universeIds", "").split(",") if x]
    if len(ids) > 50:
        return jsonify({"errors": [{"code": 9, "message": "Too many ids"}]}), 400
    # Las estadísticas varían ligeramente en cada consulta (para probar snapshots/historial)
    out = []
    for i in ids:
        if i in GAMES and i not in DELETED:
            g = dict(GAMES[i])
            g["playing"] = max(0, int(g["playing"] * random.uniform(0.8, 1.25)))
            g["visits"] = g["visits"] + random.randint(0, 5000)
            out.append(g)
    return jsonify({"data": out})


@app.get("/games/v1/games/votes")
def votes():
    if (e := maybe_429()):
        return e
    ids = [int(x) for x in request.args.get("universeIds", "").split(",") if x]
    return jsonify({"data": [{"id": i, "upVotes": GAMES[i]["playing"] * 30 + 5, "downVotes": GAMES[i]["playing"] * 4 + 1}
                             for i in ids if i in GAMES and i not in DELETED]})


@app.get("/games/v1/games/<int:uid>/favorites/count")
def fav(uid):
    return jsonify({"favoritesCount": GAMES.get(uid, {}).get("favoritedCount", 0)})


@app.get("/games/v1/games/recommendations/game/<int:uid>")
def rec(uid):
    rr = random.Random(uid)
    picks = rr.sample(sorted(GAMES), int(request.args.get("maxRows", 6)))
    return jsonify({"games": [{**explore_item(GAMES[p]), "placeId": GAMES[p]["rootPlaceId"], "creatorName": "x"} for p in picks]})


@app.get("/games/v1/games/<int:pid>/servers/Public")
def servers(pid):
    uid = PLACE_TO_UNI.get(pid)
    n = GAMES[uid]["playing"] // 10 if uid else 0
    cursor = request.args.get("cursor")
    start = int(cursor) if cursor else 0
    data = [{"id": f"s{k}", "maxPlayers": 12, "playing": 10} for k in range(start, min(n, start + 100))]
    return jsonify({"data": data, "nextPageCursor": str(start + 100) if start + 100 < n else None})


@app.get("/thumbnails/v1/games/icons")
def icons():
    ids = [int(x) for x in request.args.get("universeIds", "").split(",") if x]
    return jsonify({"data": [{"targetId": i, "state": "Completed",
                              "imageUrl": "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='150' height='150'>"
                                          f"<rect width='150' height='150' fill='%23{(i * 2654435761) % 0xFFFFFF:06x}'/></svg>",
                              "version": "x"} for i in ids]})


@app.get("/apis/universes/v1/places/<int:pid>/universe")
def p2u(pid):
    return jsonify({"universeId": PLACE_TO_UNI.get(pid)})


SORTS = {"top-trending": 93, "up-and-coming": 22, "top-playing-now": 96, "most-popular": 98, "top-rated": 100,
         "top-revisited": 94, "trending-in-survival": 27, "trending-in-simulation": 57, "trending-in-rpg": 29,
         "trending-in-obby-and-platformer": 24, "trending-in-shooter": 29, "trending-in-adventure": 28}


@app.get("/apis/explore-api/v1/get-sort-content")
def sort_content():
    if (e := maybe_429()):
        return e
    sid = request.args.get("sortId")
    if sid not in SORTS:
        return jsonify({"errors": [{"message": "not found"}]}), 404
    rr = random.Random(sid)
    picks = rr.sample(sorted(GAMES), SORTS[sid])
    return jsonify({"sortId": sid, "games": [explore_item(GAMES[p]) for p in picks]})


@app.get("/apis/explore-api/v1/get-sorts")
def get_sorts():
    return jsonify({"sorts": [{"sortId": s, "contentType": "Games", "games": []} for s in SORTS]})


@app.get("/apis/search-api/omni-search")
def search():
    if (e := maybe_429()):
        return e
    q = (request.args.get("searchQuery") or "").lower()
    tok = request.args.get("pageToken")
    start = int(tok) if tok else 0
    matches = [g for uid, g in sorted(GAMES.items()) if any(w in (g["name"] + " " + g["description"] + " " + g["genre_l1"]).lower()
                                                           for w in q.split())]
    page = matches[start:start + 40]
    return jsonify({"searchResults": [{"contentGroupType": "Game", "contents": [explore_item(g)], "topicId": "Invalid"} for g in page],
                    "nextPageToken": str(start + 40) if start + 40 < len(matches) else ""})


@app.get("/apis/game-passes/v1/universes/<int:uid>/game-passes")
def passes(uid):
    if uid % 11 == 0:
        return jsonify({"errors": [{"message": "boom"}]}), 500
    rr = random.Random(uid)
    names = ["VIP", "2x Coins", "Extra Storage", "Speed Coil", "Rainbow Trail", "Auto Farm", "x3 Luck", "500 Gems"]
    k = rr.randint(0, 6)
    return jsonify({"gamePasses": [{"id": uid * 10 + j, "name": n, "displayName": n, "displayDescription": f"Get {n.lower()} forever!",
                                    "price": rr.choice([49, 99, 199, 399]), "isForSale": True} for j, n in enumerate(rr.sample(names, k))],
                    "nextPageToken": None})


@app.get("/badges/v1/universes/<int:uid>/badges")
def badges(uid):
    rr = random.Random(uid * 3)
    k = rr.randint(0, 4)
    names = ["Welcome", "Beat the Boss", "Reached Level 100", "Found the Secret", "Escaped!", "Collected all pets"]
    return jsonify({"previousPageCursor": None, "nextPageCursor": None,
                    "data": [{"id": uid * 100 + j, "name": n, "description": f"You {n.lower()}", "enabled": True,
                              "statistics": {"awardedCount": rr.randint(10, 10000), "pastDayAwardedCount": 3, "winRatePercentage": 0.1}}
                             for j, n in enumerate(rr.sample(names, k))]})


@app.post("/openai/chat/completions")
def fake_ai():
    """Imita una API compatible con OpenAI para probar el flujo de IA."""
    import json as _json
    body = request.get_json(force=True)
    assert body["messages"][0]["role"] == "system"
    content = {k: "No hay información suficiente" for k in (
        "1_core_loop", "2_mecanicas_detectadas", "3_progresion", "4_recompensas", "5_retencion", "6_social",
        "7_monetizacion_visible", "8_diferenciadoras", "9_posibles_razones_engagement")}
    content["1_core_loop"] = "Probable: recolectar → mejorar (inferencia)."
    content["mechanics"] = {"core_collect": "probable", "mon_gamepasses": "detectada", "clave_falsa": "detectada"}
    return jsonify({"choices": [{"message": {"content": "```json\n" + _json.dumps(content) + "\n```"}}]})


if __name__ == "__main__":
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 9100
    app.run(port=port, threaded=True)
