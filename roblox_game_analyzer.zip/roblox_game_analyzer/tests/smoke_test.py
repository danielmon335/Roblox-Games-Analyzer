"""Prueba de extremo a extremo SIN contactar Roblox.

Levanta el servidor simulado (tests/mock_roblox.py), una base de datos temporal y
ejecuta el flujo completo: descubrir → recopilar → guardar → analizar → patrones →
exportar, además de 429/reintentos, snapshots, comparador y notas.

    python tests/smoke_test.py
"""
import os
import sys
import tempfile
import threading
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "tests"))

from werkzeug.serving import make_server  # noqa: E402

import mock_roblox  # noqa: E402

mock_srv = make_server("127.0.0.1", 0, mock_roblox.app, threaded=True)
threading.Thread(target=mock_srv.serve_forever, daemon=True).start()
tmp = tempfile.mkdtemp(prefix="rga_test_")
os.environ.update({
    "ROBLOX_MOCK_BASE": f"http://127.0.0.1:{mock_srv.server_port}",
    "DB_PATH": os.path.join(tmp, "test.db"), "REQUEST_INTERVAL": "0.01", "BACKOFF_BASE": "0.05",
    "MIN_SNAPSHOT_MINUTES": "0", "OPEN_BROWSER": "false", "RGA_SETTINGS_PATH": os.path.join(tmp, "settings.json"),
})

from app import db, mechanics  # noqa: E402
from app.config import settings  # noqa: E402
from app.jobs import manager  # noqa: E402
from app.logging_setup import setup_logging  # noqa: E402
from app.roblox_client import RobloxClient  # noqa: E402
from app.web import create_app  # noqa: E402

setup_logging()
settings.reload()
db.init_db()
mechanics.seed_mechanics()
manager.start()
client = create_app().test_client()
results = []


def check(name, cond, detail=""):
    results.append((name, bool(cond)))
    print(("  OK   " if cond else "  FAIL ") + name + (f"  ({detail})" if detail and not cond else ""))


def run_job(jtype, params, timeout=180):
    r = client.post("/api/jobs", json={"type": jtype, "params": params})
    jid = r.get_json()["job_id"]
    t0 = time.time()
    while time.time() - t0 < timeout:
        j = client.get(f"/api/jobs/{jid}").get_json()
        if j["status"] not in ("queued", "running"):
            return j
        time.sleep(0.3)
    return client.get(f"/api/jobs/{jid}").get_json()


print("1. Análisis masivo (Horror, 30, ordenado por jugadores)")
j = run_job("batch", {"mode": "category", "category": "Horror", "limit": 30, "sort_by": "playing"})
check("trabajo completado", j["status"] == "done", j.get("message"))
check("30 juegos guardados", j["result"].get("saved") == 30, j["result"])
check("30 juegos analizados", j["result"].get("analyzed") == 30)
rows = client.get(f"/api/games?job_id={j['id']}&page_size=100&sort=playing").get_json()["rows"]
check("ordenados por jugadores", all((rows[i]["playing"] or 0) >= (rows[i + 1]["playing"] or 0) for i in range(len(rows) - 1)))
check("sin duplicados", len({r["universe_id"] for r in rows}) == len(rows))

print("2. Otros modos de descubrimiento")
for params, expect in [({"mode": "popular", "limit": 15}, 15), ({"mode": "trending", "limit": 20}, 20),
                       ({"mode": "related", "ids_text": "1001", "limit": 10}, 10),
                       ({"mode": "ids", "ids_text": "1001 1002 50003 abc", "limit": 10}, 3),
                       ({"mode": "urls", "urls_text": "https://www.roblox.com/games/50004/x\nhttps://www.roblox.com/es/games/50006", "limit": 10}, 2),
                       ({"mode": "keyword", "keyword": "tycoon", "limit": 12}, 12)]:
    jj = run_job("discover", {**params, "analyze": True})
    check(f"modo {params['mode']}", jj["status"] == "done" and jj["result"].get("saved") == expect, jj["result"].get("summary"))

print("3. Endpoints de la API")
for url in ["/api/meta", "/api/dashboard", "/api/games?q=Scary&sort=category&dir=asc", "/api/games?min_players=10&max_players=500",
            "/api/categories", "/api/patterns", f"/api/patterns?job_id={j['id']}&include_probable=1", "/api/mechanics",
            "/api/mechanics/core_combat/games", "/api/history", "/api/settings", "/api/errors", "/api/jobs",
            f"/api/games/{rows[0]['universe_id']}", f"/api/compare?ids={rows[0]['universe_id']},{rows[1]['universe_id']}"]:
    r = client.get(url)
    check(f"GET {url}", r.status_code == 200, r.status_code)
check("404 juego inexistente", client.get("/api/games/1").status_code == 404)
p = client.get(f"/api/patterns?job_id={j['id']}").get_json()
check("patrones con porcentajes", any(m["percent"] for m in p["mechanics"]))
check("aviso de no causalidad", "causalidad" in p["disclaimer"])

print("4. Exportación")
for url, needle in [("/api/export/csv", b"universeId"), ("/api/export/csv?what=mechanics", b"core_loop"),
                    ("/api/export/csv?what=patterns", b"mecanica"), ("/api/export/csv?what=snapshots", b"captured_at"),
                    (f"/api/export/json?job_id={j['id']}", b'"juegos"'), ("/api/export/xlsx", b"PK"),
                    ("/api/export/html?category=Horror", b"<h2>Patrones")]:
    r = client.get(url)
    check(f"export {url}", r.status_code == 200 and needle in r.data[:200000], r.status_code)

print("5. Snapshots históricos")
uid = rows[0]["universe_id"]
before = len(client.get(f"/api/games/{uid}").get_json()["snapshots"])
rj = run_job("refresh", {"universe_ids": [uid, rows[1]["universe_id"]]})
after = len(client.get(f"/api/games/{uid}").get_json()["snapshots"])
check("refresh crea snapshot nuevo sin sobrescribir", rj["status"] == "done" and after == before + 1, f"{before}->{after}")
check("historial muestra cambios", len(client.get("/api/history").get_json()["changes"]) >= 1)

print("6. Notas manuales y re-análisis")
r = client.post(f"/api/games/{uid}/notes", json={"source": "changelog", "text": "New update: daily quests, login streak and a battle pass!"})
check("nota guardada", r.status_code == 200)
m = client.get(f"/api/games/{uid}").get_json()["mechanics"]["rules"]
check("mecánica detectada desde la nota", m["ret_streaks"]["status"] == "detectada" and m["ret_season_pass"]["status"] == "detectada")

print("7. Rate limit (HTTP 429) y reintentos")
c = RobloxClient()
oks = sum(1 for _ in range(70) if c.games_details([1001], fresh=True).ok)
check("todas las solicitudes terminan bien pese a 429", oks == 70, oks)
check("429 detectado y reintentado", c.stats["rate_limited"] >= 1, c.stats)
bad = c.gamepasses(1012)  # el simulador devuelve 500 para ids múltiplos de 11... 1012 = 11*92
check("error 500 persistente devuelve fallo controlado", not bad.ok and bad.error)

print("8. IA deshabilitada por defecto")
r = client.post(f"/api/games/{uid}/ai")
check("IA no configurada responde 400 con motivo", r.status_code == 400 and "deshabilitado" in r.get_json()["error"])

print("9. Validación de parámetros")
check("categoría vacía rechazada", client.post("/api/jobs", json={"type": "discover", "params": {"mode": "category"}}).status_code == 400)

print("10. Flujo de IA con proveedor compatible simulado")
r = client.post("/api/settings", json={"AI_ENABLED": True, "AI_PROVIDER": "openai", "AI_MODEL": "modelo-prueba",
                                       "AI_BASE_URL": os.environ["ROBLOX_MOCK_BASE"] + "/openai"})
os.environ["AI_API_KEY"] = "clave-de-prueba"   # en uso real se guarda en .env
settings.reload()
r = client.post(f"/api/games/{uid}/ai")
check("análisis IA completado", r.status_code == 200, r.get_json())
d = client.get(f"/api/games/{uid}").get_json()
check("resultado IA guardado", d["ai"] and "1_core_loop" in d["ai"]["content"])
check("claves de IA inválidas descartadas", set(d["mechanics"].get("ai", {})) == {"core_collect", "mon_gamepasses"})
client.post("/api/settings", json={"AI_ENABLED": False})

ok = sum(1 for _, c in results if c)
print(f"\nResultado: {ok}/{len(results)} comprobaciones correctas")
mock_srv.shutdown()
sys.exit(0 if ok == len(results) else 1)
