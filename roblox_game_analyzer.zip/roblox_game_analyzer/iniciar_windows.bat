@echo off
REM Inicia Roblox Game Analyzer en Windows (crea el entorno virtual la primera vez)
cd /d "%~dp0"
if not exist .venv (
  echo Creando entorno virtual...
  py -3 -m venv .venv 2>nul || python -m venv .venv
  call .venv\Scripts\activate.bat
  python -m pip install --upgrade pip
  pip install -r requirements.txt
) else (
  call .venv\Scripts\activate.bat
)
if not exist .env copy .env.example .env >nul
python main.py
pause
