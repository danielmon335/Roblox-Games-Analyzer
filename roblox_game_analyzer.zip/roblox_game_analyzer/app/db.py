"""Capa SQLite: esquema, conexión y utilidades."""
from __future__ import annotations

import json
import logging
import sqlite3
import threading
from contextlib import contextmanager
from datetime import datetime, timezone

from .config import settings

log = logging.getLogger(__name__)
_init_lock = threading.Lock()

SCHEMA = """
CREATE TABLE IF NOT EXISTS games (
    universe_id      INTEGER PRIMARY KEY,
    place_id         INTEGER,
    name             TEXT,
    description      TEXT,
    creator_id       INTEGER,
    creator_name     TEXT,
    creator_type     TEXT,
    creator_verified INTEGER,
    created          TEXT,
    updated          TEXT,
    genre            TEXT,
    genre_l1         TEXT,
    genre_l2         TEXT,
    max_players      INTEGER,
    price            INTEGER,
    url              TEXT,
    icon_url         TEXT,
    gamepass_count   INTEGER,
    badge_count      INTEGER,
    status           TEXT DEFAULT 'ok',     -- ok | not_found | error
    status_detail    TEXT,
    field_sources    TEXT,                  -- JSON {campo: endpoint}
    extra            TEXT,                  -- JSON con otros datos públicos
    first_seen       TEXT,
    last_fetched     TEXT
);

CREATE TABLE IF NOT EXISTS game_snapshots (
    id                 INTEGER PRIMARY KEY AUTOINCREMENT,
    universe_id        INTEGER NOT NULL,
    captured_at        TEXT NOT NULL,
    playing            INTEGER,
    visits             INTEGER,
    favorites          INTEGER,
    up_votes           INTEGER,
    down_votes         INTEGER,
    like_ratio         REAL,
    server_count       INTEGER,
    server_count_lower_bound INTEGER DEFAULT 0,
    source             TEXT,
    job_id             INTEGER,
    FOREIGN KEY (universe_id) REFERENCES games(universe_id)
);
CREATE INDEX IF NOT EXISTS idx_snap_game ON game_snapshots(universe_id, captured_at);

CREATE TABLE IF NOT EXISTS game_categories (
    universe_id INTEGER NOT NULL,
    category    TEXT NOT NULL,
    source      TEXT NOT NULL,     -- roblox_genre | discovery | user
    added_at    TEXT,
    PRIMARY KEY (universe_id, category, source)
);
CREATE INDEX IF NOT EXISTS idx_cat ON game_categories(category);

CREATE TABLE IF NOT EXISTS game_items (
    universe_id INTEGER NOT NULL,
    kind        TEXT NOT NULL,     -- gamepass | badge
    item_id     INTEGER NOT NULL,
    name        TEXT,
    description TEXT,
    price       INTEGER,
    extra       TEXT,
    fetched_at  TEXT,
    PRIMARY KEY (universe_id, kind, item_id)
);

CREATE TABLE IF NOT EXISTS manual_notes (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    universe_id INTEGER NOT NULL,
    source      TEXT,              -- p.ej. 'changelog', 'wiki', 'notas'
    text        TEXT NOT NULL,
    created_at  TEXT
);

CREATE TABLE IF NOT EXISTS mechanics (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    key         TEXT UNIQUE NOT NULL,
    group_name  TEXT NOT NULL,
    label       TEXT NOT NULL,
    keywords    TEXT
);

CREATE TABLE IF NOT EXISTS game_mechanics (
    universe_id INTEGER NOT NULL,
    mechanic_key TEXT NOT NULL,
    status      TEXT NOT NULL,     -- detectada | probable | no_detectada | insuficiente
    score       REAL,
    evidence    TEXT,              -- JSON lista de {source, match, snippet}
    method      TEXT NOT NULL,     -- rules | ai
    analyzed_at TEXT,
    PRIMARY KEY (universe_id, mechanic_key, method)
);
CREATE INDEX IF NOT EXISTS idx_gm_key ON game_mechanics(mechanic_key, status);

CREATE TABLE IF NOT EXISTS analysis_results (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    universe_id INTEGER,
    job_id      INTEGER,
    kind        TEXT NOT NULL,     -- rules_summary | ai | batch_stats
    content     TEXT,              -- JSON
    model       TEXT,
    created_at  TEXT
);
CREATE INDEX IF NOT EXISTS idx_ar_game ON analysis_results(universe_id, kind);

CREATE TABLE IF NOT EXISTS jobs (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    type        TEXT NOT NULL,
    params      TEXT,
    status      TEXT NOT NULL,     -- queued | running | done | error | cancelled
    progress    INTEGER DEFAULT 0,
    total       INTEGER DEFAULT 0,
    message     TEXT,
    result      TEXT,
    created_at  TEXT,
    started_at  TEXT,
    finished_at TEXT
);

CREATE TABLE IF NOT EXISTS job_games (
    job_id      INTEGER NOT NULL,
    universe_id INTEGER NOT NULL,
    rank        INTEGER,
    discovered_via TEXT,
    PRIMARY KEY (job_id, universe_id)
);

CREATE TABLE IF NOT EXISTS http_cache (
    url         TEXT PRIMARY KEY,
    status      INTEGER,
    body        TEXT,
    fetched_at  REAL
);

CREATE TABLE IF NOT EXISTS error_log (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    ts          TEXT,
    context     TEXT,
    url         TEXT,
    status      INTEGER,
    message     TEXT
);
"""


def now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def connect() -> sqlite3.Connection:
    path = settings.db_path
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(path), timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = OFF")
    conn.execute("PRAGMA busy_timeout = 30000")
    return conn


@contextmanager
def get_conn():
    conn = connect()
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db():
    with _init_lock:
        with get_conn() as conn:
            conn.execute("PRAGMA journal_mode = WAL")
            conn.executescript(SCHEMA)
        # Jobs que quedaron "running" por un cierre inesperado
        with get_conn() as conn:
            conn.execute(
                "UPDATE jobs SET status='error', message='Interrumpido (la aplicación se cerró)', finished_at=? "
                "WHERE status IN ('running','queued')", (now_iso(),))
    log.info("Base de datos lista en %s", settings.db_path)


def rows(sql: str, params=()) -> list[dict]:
    with get_conn() as conn:
        return [dict(r) for r in conn.execute(sql, params).fetchall()]


def one(sql: str, params=()) -> dict | None:
    with get_conn() as conn:
        r = conn.execute(sql, params).fetchone()
        return dict(r) if r else None


def execute(sql: str, params=()) -> int:
    with get_conn() as conn:
        cur = conn.execute(sql, params)
        return cur.lastrowid


def log_error(context: str, message: str, url: str = None, status: int = None):
    try:
        with get_conn() as conn:
            conn.execute(
                "INSERT INTO error_log (ts, context, url, status, message) VALUES (?,?,?,?,?)",
                (now_iso(), context, url, status, str(message)[:2000]))
    except sqlite3.Error as e:  # nunca romper por fallar el log
        log.warning("No se pudo registrar error en DB: %s", e)


def jdump(obj) -> str:
    return json.dumps(obj, ensure_ascii=False, default=str)


def jload(s, default=None):
    if not s:
        return default
    try:
        return json.loads(s)
    except (TypeError, ValueError):
        return default
