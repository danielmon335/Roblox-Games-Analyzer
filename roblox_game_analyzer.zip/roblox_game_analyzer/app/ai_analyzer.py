"""Análisis opcional mediante un modelo de IA.

Desactivado por defecto. Se activa en Configuración (AI_ENABLED) y requiere AI_API_KEY en .env.
Proveedores soportados:
  - anthropic : API de Mensajes de Anthropic (https://api.anthropic.com/v1/messages)
  - openai    : cualquier API compatible con /chat/completions (OpenAI, Azure, servidores locales...)

La IA solo recibe información pública ya recopilada + notas manuales del usuario.
Se le exige distinguir hechos de inferencias y no afirmar causalidad.
"""
from __future__ import annotations

import json
import logging
import re

import requests

from . import db
from .config import settings
from .mechanics import TAXONOMY, gather_texts

log = logging.getLogger(__name__)

SYSTEM_PROMPT = """Eres un analista de diseño de videojuegos. Analizas experiencias de Roblox usando
ÚNICAMENTE la información pública que se te proporciona. Reglas obligatorias:
- No inventes datos. Si algo no aparece en la información, di "No hay información suficiente".
- Distingue claramente entre lo que está explícito en las fuentes ("Detectada") y lo que infieres ("Probable").
- Nunca afirmes que una mecánica causa el éxito del juego. Usa formulaciones como
  "Esta mecánica aparece en las fuentes públicas" o "Posible factor de engagement (inferencia, no demostrado)".
- Responde SOLO con un objeto JSON válido, en español, sin texto adicional."""

SECTIONS = [
    ("1_core_loop", "Core loop probable"),
    ("2_mecanicas_detectadas", "Mecánicas detectadas"),
    ("3_progresion", "Sistemas de progresión"),
    ("4_recompensas", "Sistemas de recompensa"),
    ("5_retencion", "Elementos de retención"),
    ("6_social", "Elementos sociales"),
    ("7_monetizacion_visible", "Monetización visible"),
    ("8_diferenciadoras", "Características diferenciadoras"),
    ("9_posibles_razones_engagement", "Posibles razones de engagement (inferencia)"),
]


class AIError(Exception):
    pass


def ai_status() -> dict:
    enabled = bool(settings.get("AI_ENABLED"))
    has_key = bool(settings.get("AI_API_KEY"))
    model = settings.get("AI_MODEL") or ""
    ready = enabled and has_key and bool(model)
    reason = None
    if not enabled:
        reason = "El análisis IA está deshabilitado en Configuración."
    elif not has_key:
        reason = "Falta AI_API_KEY en el archivo .env (o introdúcela en Configuración)."
    elif not model:
        reason = "Indica el nombre del modelo (AI_MODEL) en Configuración."
    return {"enabled": enabled, "has_key": has_key, "model": model, "provider": settings.get("AI_PROVIDER"),
            "ready": ready, "reason": reason}


def build_prompt(universe_id: int) -> str:
    g, texts = gather_texts(universe_id)
    if not g:
        raise AIError("Juego no encontrado en la base de datos")
    snap = db.one("SELECT * FROM game_snapshots WHERE universe_id=? ORDER BY captured_at DESC LIMIT 1", (universe_id,)) or {}
    keys = {m["key"]: f"{m['group']} / {m['label']}" for m in TAXONOMY if not m.get("derived")}
    body = [f"JUEGO: {g.get('name')} (universeId {universe_id})",
            f"Creador: {g.get('creator_name')} | Género Roblox: {g.get('genre_l1')} / {g.get('genre_l2')}",
            f"Creado: {g.get('created')} | Actualizado: {g.get('updated')} | Max jugadores/servidor: {g.get('max_players')}",
            f"Jugadores actuales: {snap.get('playing')} | Visitas: {snap.get('visits')} | Favoritos: {snap.get('favorites')} | "
            f"Likes: {snap.get('up_votes')} | Dislikes: {snap.get('down_votes')}",
            f"Gamepasses públicos: {g.get('gamepass_count')} | Insignias públicas: {g.get('badge_count')}",
            "", "FUENTES DE TEXTO PÚBLICAS:"]
    budget = 14000
    for t in texts:
        chunk = f"[{t['source']}] {t['text']}"
        if len(chunk) > budget:
            chunk = chunk[:budget] + "…"
        body.append(chunk)
        budget -= len(chunk)
        if budget <= 0:
            body.append("[texto truncado]")
            break
    schema = {k: "texto" for k, _ in SECTIONS}
    schema["mechanics"] = {"<clave>": "detectada | probable | no_detectada | insuficiente"}
    body += ["", "CLAVES DE MECÁNICAS (usa exactamente estas claves en 'mechanics'):",
             json.dumps(keys, ensure_ascii=False), "",
             "Devuelve un JSON con esta forma:", json.dumps(schema, ensure_ascii=False)]
    return "\n".join(body)


def _call_anthropic(prompt: str) -> str:
    r = requests.post("https://api.anthropic.com/v1/messages", timeout=90, headers={
        "x-api-key": settings.get("AI_API_KEY"), "anthropic-version": "2023-06-01", "content-type": "application/json"},
        json={"model": settings.get("AI_MODEL"), "max_tokens": int(settings.get("AI_MAX_TOKENS", 1800)),
              "system": SYSTEM_PROMPT, "messages": [{"role": "user", "content": prompt}]})
    if r.status_code != 200:
        raise AIError(f"Anthropic HTTP {r.status_code}: {r.text[:300]}")
    data = r.json()
    return "".join(b.get("text", "") for b in data.get("content", []) if b.get("type") == "text")


def _call_openai(prompt: str) -> str:
    base = (settings.get("AI_BASE_URL") or "https://api.openai.com/v1").rstrip("/")
    r = requests.post(base + "/chat/completions", timeout=90, headers={
        "Authorization": f"Bearer {settings.get('AI_API_KEY')}", "Content-Type": "application/json"},
        json={"model": settings.get("AI_MODEL"), "max_tokens": int(settings.get("AI_MAX_TOKENS", 1800)),
              "messages": [{"role": "system", "content": SYSTEM_PROMPT}, {"role": "user", "content": prompt}]})
    if r.status_code != 200:
        raise AIError(f"API HTTP {r.status_code}: {r.text[:300]}")
    return r.json()["choices"][0]["message"]["content"]


def _parse_json(text: str) -> dict:
    text = text.strip()
    m = re.search(r"\{.*\}", text, re.S)
    if not m:
        raise AIError("La respuesta de la IA no contiene JSON")
    try:
        return json.loads(m.group(0))
    except json.JSONDecodeError as e:
        raise AIError(f"JSON inválido en la respuesta de la IA: {e}") from e


def analyze_with_ai(universe_id: int) -> dict:
    st = ai_status()
    if not st["ready"]:
        raise AIError(st["reason"])
    prompt = build_prompt(universe_id)
    provider = (settings.get("AI_PROVIDER") or "anthropic").lower()
    try:
        raw = _call_openai(prompt) if provider == "openai" else _call_anthropic(prompt)
    except requests.RequestException as e:
        raise AIError(f"Error de conexión con la IA: {e}") from e
    result = _parse_json(raw)
    valid_keys = {m["key"] for m in TAXONOMY if not m.get("derived")}
    valid_status = {"detectada", "probable", "no_detectada", "insuficiente"}
    mech = {k: v for k, v in (result.get("mechanics") or {}).items() if k in valid_keys and v in valid_status}
    now = db.now_iso()
    with db.get_conn() as conn:
        conn.execute("DELETE FROM game_mechanics WHERE universe_id=? AND method='ai'", (universe_id,))
        for k, v in mech.items():
            conn.execute("INSERT INTO game_mechanics VALUES (?,?,?,?,?,?,?)",
                         (universe_id, k, v, None, db.jdump([{"source": "IA", "match": "", "snippet": "Clasificación del modelo de IA"}]),
                          "ai", now))
        conn.execute("INSERT INTO analysis_results (universe_id, kind, content, model, created_at) VALUES (?,?,?,?,?)",
                     (universe_id, "ai", db.jdump(result), f"{provider}:{settings.get('AI_MODEL')}", now))
    log.info("Análisis IA completado para %s", universe_id)
    return result
