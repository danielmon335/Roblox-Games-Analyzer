"""Roblox Game Analyzer — paquete principal."""
__version__ = "1.0.0"
