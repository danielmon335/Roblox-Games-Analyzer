"""Recolección de datos públicos de cada juego y guardado en SQLite."""
from __future__ import annotations

import logging
from datetime import datetime, timedelta, timezone

from . import db
from .config import settings
from .roblox_client import RobloxClient

log = logging.getLogger(__name__)

SRC_GAMES = "games.roblox.com/v1/games"
SRC_VOTES = "games.roblox.com/v1/games/votes"
SRC_ICONS = "thumbnails.roblox.com/v1/games/icons"
SRC_PASSES = "apis.roblox.com/game-passes/v1/universes/{id}/game-passes"
SRC_BADGES = "badges.roblox.com/v1/universes/{id}/badges"
SRC_SERVERS = "games.roblox.com/v1/games/{placeId}/servers/Public"
SRC_FAV = "games.roblox.com/v1/games/{id}/favorites/count"


def _int(v):
    try:
        return int(v)
    except (TypeError, ValueError):
        return None


def like_ratio(up, down):
    if up is None or down is None or (up + down) == 0:
        return None
    return round(100.0 * up / (up + down), 2)


def fetch_basic(client: RobloxClient, universe_ids: list[int], progress=None, batch_size: int | None = None,
                fresh: bool = False) -> tuple[dict, list[int], list[str]]:
    """Detalles + votos en lotes. Devuelve (records, not_found_ids, warnings)."""
    batch = max(1, min(50, int(batch_size or settings.get("BATCH_SIZE", 50))))
    records: dict[int, dict] = {}
    not_found: list[int] = []
    warnings: list[str] = []
    ids = list(dict.fromkeys(int(i) for i in universe_ids))
    for i in range(0, len(ids), batch):
        if client.cancel_event.is_set():
            break
        chunk = ids[i:i + batch]
        r = client.games_details(chunk, fresh=fresh)
        if not r.ok:
            warnings.append(f"Lote {i // batch + 1}: detalles no disponibles ({r.error}). Se continúa.")
            for uid in chunk:
                records[uid] = {"universe_id": uid, "status": "error", "status_detail": r.error,
                                "field_sources": {}}
            continue
        got = {}
        for g in r.data.get("data") or []:
            uid = _int(g.get("id"))
            if not uid:
                continue
            creator = g.get("creator") or {}
            place_id = _int(g.get("rootPlaceId"))
            path = g.get("canonicalUrlPath")
            url = (f"https://www.roblox.com{path}" if path else
                   (f"https://www.roblox.com/games/{place_id}" if place_id else None))
            rec = {
                "universe_id": uid,
                "place_id": place_id,
                "name": g.get("name"),
                "description": g.get("description") or "",
                "creator_id": _int(creator.get("id")),
                "creator_name": creator.get("name"),
                "creator_type": creator.get("type"),
                "creator_verified": 1 if creator.get("hasVerifiedBadge") else 0,
                "created": g.get("created"),
                "updated": g.get("updated"),
                "genre": g.get("genre"),
                "genre_l1": g.get("genre_l1"),
                "genre_l2": g.get("genre_l2"),
                "max_players": _int(g.get("maxPlayers")),
                "price": _int(g.get("price")),
                "url": url,
                "playing": _int(g.get("playing")),
                "visits": _int(g.get("visits")),
                "favorites": _int(g.get("favoritedCount")),
                "status": "ok",
                "status_detail": None,
                "extra": {k: g.get(k) for k in (
                    "universeAvatarType", "createVipServersAllowed", "copyingAllowed",
                    "isAllGenre", "allowedGearGenres", "studioAccessToApisAllowed",
                    "isGenreEnforced", "sourceName") if k in g},
                "field_sources": {f: SRC_GAMES for f in (
                    "name", "description", "creator", "created", "updated", "genre", "max_players",
                    "playing", "visits", "favorites", "place_id")},
            }
            got[uid] = rec
        for uid in chunk:
            if uid in got:
                records[uid] = got[uid]
            else:
                not_found.append(uid)
        # Votos
        valid = [u for u in chunk if u in got]
        if valid:
            v = client.games_votes(valid, fresh=fresh)
            if v.ok:
                for row in v.data.get("data") or []:
                    uid = _int(row.get("id"))
                    if uid in records:
                        up, down = _int(row.get("upVotes")), _int(row.get("downVotes"))
                        records[uid].update(up_votes=up, down_votes=down, like_ratio=like_ratio(up, down))
                        records[uid]["field_sources"].update(up_votes=SRC_VOTES, down_votes=SRC_VOTES,
                                                             like_ratio=SRC_VOTES + " (calculado)")
            else:
                warnings.append(f"Votos no disponibles para un lote ({v.error}).")
        if progress:
            progress(min(i + batch, len(ids)), len(ids), "Recopilando estadísticas")
    return records, not_found, warnings


def fetch_icons(client: RobloxClient, records: dict):
    ids = [u for u, r in records.items() if r.get("status") == "ok"]
    for i in range(0, len(ids), 50):
        r = client.game_icons(ids[i:i + 50])
        if not r.ok:
            continue
        for row in r.data.get("data") or []:
            uid = _int(row.get("targetId"))
            if uid in records and row.get("state") == "Completed" and row.get("imageUrl"):
                records[uid]["icon_url"] = row["imageUrl"]
                records[uid]["field_sources"]["icon"] = SRC_ICONS


def fetch_extras(client: RobloxClient, rec: dict):
    """Gamepasses, insignias y (opcional) servidores. Cada fallo se registra y se continúa."""
    uid = rec["universe_id"]
    rec.setdefault("items", [])
    notes = rec.setdefault("extras_status", {})

    if rec.get("favorites") is None:
        r = client.favorites_count(uid)
        if r.ok:
            rec["favorites"] = _int(r.data.get("favoritesCount"))
            rec["field_sources"]["favorites"] = SRC_FAV

    if settings.get("FETCH_GAMEPASSES", True):
        token, pages, passes, ok = None, 0, [], True
        while pages < 3:
            r = client.gamepasses(uid, token)
            pages += 1
            if not r.ok:
                ok = False
                notes["gamepasses"] = f"No disponible ({r.error})"
                break
            for p in r.data.get("gamePasses") or []:
                passes.append({
                    "kind": "gamepass", "item_id": _int(p.get("id")),
                    "name": p.get("displayName") or p.get("name"),
                    "description": p.get("displayDescription") or p.get("description") or "",
                    "price": _int(p.get("price")),
                    "extra": {"isForSale": p.get("isForSale"), "created": p.get("created")}})
            token = r.data.get("nextPageToken")
            if not token:
                break
        if ok:
            rec["gamepass_count"] = len(passes)
            rec["field_sources"]["gamepasses"] = SRC_PASSES
            notes["gamepasses"] = "ok" + (" (máx. 300 leídos)" if token else "")
        rec["items"] += passes

    if settings.get("FETCH_BADGES", True):
        cursor, pages, badges, ok = None, 0, [], True
        while pages < 3:
            r = client.badges(uid, cursor)
            pages += 1
            if not r.ok:
                ok = False
                notes["badges"] = f"No disponible ({r.error})"
                break
            for b in r.data.get("data") or []:
                st = b.get("statistics") or {}
                badges.append({
                    "kind": "badge", "item_id": _int(b.get("id")),
                    "name": b.get("name") or b.get("displayName"),
                    "description": b.get("description") or b.get("displayDescription") or "",
                    "price": None,
                    "extra": {"enabled": b.get("enabled"), "awardedCount": st.get("awardedCount"),
                              "winRatePercentage": st.get("winRatePercentage"), "created": b.get("created")}})
            cursor = r.data.get("nextPageCursor")
            if not cursor:
                break
        if ok:
            rec["badge_count"] = len(badges)
            rec["field_sources"]["badges"] = SRC_BADGES
            notes["badges"] = "ok" + (" (máx. 300 leídas)" if cursor else "")
        rec["items"] += badges

    if settings.get("FETCH_SERVERS", False) and rec.get("place_id"):
        cursor, pages, count, ok = None, 0, 0, True
        max_pages = max(1, int(settings.get("MAX_SERVER_PAGES", 2)))
        while pages < max_pages:
            r = client.public_servers(rec["place_id"], cursor)
            pages += 1
            if not r.ok:
                ok = pages > 1
                break
            count += len(r.data.get("data") or [])
            cursor = r.data.get("nextPageCursor")
            if not cursor:
                break
        if ok:
            rec["server_count"] = count
            rec["server_count_lower_bound"] = 1 if cursor else 0
            rec["field_sources"]["server_count"] = SRC_SERVERS + (" (mínimo, paginación limitada)" if cursor else "")
    return rec


def save_game(rec: dict, job_id: int | None = None, discovery_category: str | None = None,
              discovered_via: str | None = None) -> bool:
    """Inserta/actualiza el juego y agrega un snapshot histórico (sin sobrescribir)."""
    uid = rec["universe_id"]
    now = db.now_iso()
    with db.get_conn() as conn:
        existing = conn.execute("SELECT universe_id, first_seen FROM games WHERE universe_id=?", (uid,)).fetchone()
        if rec.get("status") != "ok":
            if existing:
                conn.execute("UPDATE games SET status=?, status_detail=?, last_fetched=? WHERE universe_id=?",
                             (rec.get("status"), rec.get("status_detail"), now, uid))
            return False
        cols = ["place_id", "name", "description", "creator_id", "creator_name", "creator_type",
                "creator_verified", "created", "updated", "genre", "genre_l1", "genre_l2", "max_players",
                "price", "url"]
        vals = [rec.get(c) for c in cols]
        opt_cols = [c for c in ("icon_url", "gamepass_count", "badge_count") if rec.get(c) is not None]
        opt_vals = [rec[c] for c in opt_cols]
        extra = db.jdump({**rec.get("extra", {}), "extras_status": rec.get("extras_status", {})})
        fs = db.jdump(rec.get("field_sources", {}))
        if existing:
            sets = ", ".join(f"{c}=?" for c in cols + opt_cols)
            conn.execute(f"UPDATE games SET {sets}, status='ok', status_detail=NULL, field_sources=?, extra=?, "
                         f"last_fetched=? WHERE universe_id=?", vals + opt_vals + [fs, extra, now, uid])
        else:
            all_cols = ["universe_id"] + cols + opt_cols + ["status", "field_sources", "extra", "first_seen", "last_fetched"]
            conn.execute(f"INSERT INTO games ({','.join(all_cols)}) VALUES ({','.join('?' * len(all_cols))})",
                         [uid] + vals + opt_vals + ["ok", fs, extra, now, now])

        # Snapshot histórico: nunca se sobrescribe; se evita duplicar dentro del intervalo mínimo
        min_minutes = int(settings.get("MIN_SNAPSHOT_MINUTES", 30))
        last = conn.execute("SELECT captured_at FROM game_snapshots WHERE universe_id=? ORDER BY captured_at DESC LIMIT 1",
                            (uid,)).fetchone()
        take = True
        if last and min_minutes > 0:
            try:
                last_dt = datetime.fromisoformat(last["captured_at"])
                take = datetime.now(timezone.utc) - last_dt >= timedelta(minutes=min_minutes)
            except ValueError:
                take = True
        if take:
            conn.execute(
                "INSERT INTO game_snapshots (universe_id, captured_at, playing, visits, favorites, up_votes, down_votes, "
                "like_ratio, server_count, server_count_lower_bound, source, job_id) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                (uid, now, rec.get("playing"), rec.get("visits"), rec.get("favorites"), rec.get("up_votes"),
                 rec.get("down_votes"), rec.get("like_ratio"), rec.get("server_count"),
                 rec.get("server_count_lower_bound", 0), "games+votes API", job_id))

        # Categorías
        for gcol in ("genre_l1", "genre_l2"):
            if rec.get(gcol) and rec[gcol] not in ("All", ""):
                conn.execute("INSERT OR IGNORE INTO game_categories VALUES (?,?,?,?)",
                             (uid, rec[gcol], "roblox_genre", now))
        if discovery_category:
            conn.execute("INSERT OR IGNORE INTO game_categories VALUES (?,?,?,?)",
                         (uid, discovery_category, "discovery", now))

        # Gamepasses / insignias (se reemplazan por la versión actual)
        items = rec.get("items") or []
        kinds = {i["kind"] for i in items}
        for k in kinds:
            conn.execute("DELETE FROM game_items WHERE universe_id=? AND kind=?", (uid, k))
        for it in items:
            if it.get("item_id") is None:
                continue
            conn.execute("INSERT OR REPLACE INTO game_items VALUES (?,?,?,?,?,?,?,?)",
                         (uid, it["kind"], it["item_id"], it.get("name"), it.get("description"),
                          it.get("price"), db.jdump(it.get("extra") or {}), now))
        if job_id:
            conn.execute("INSERT OR IGNORE INTO job_games (job_id, universe_id, rank, discovered_via) VALUES (?,?,?,?)",
                         (job_id, uid, rec.get("_rank"), discovered_via))
    return True


def mark_not_found(universe_ids: list[int]):
    now = db.now_iso()
    with db.get_conn() as conn:
        for uid in universe_ids:
            conn.execute("UPDATE games SET status='not_found', status_detail=?, last_fetched=? WHERE universe_id=?",
                         ("No devuelto por la API (eliminado, privado o ID inválido)", now, uid))
