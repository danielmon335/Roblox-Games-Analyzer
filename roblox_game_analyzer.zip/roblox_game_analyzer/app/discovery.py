"""Descubrimiento automático de juegos mediante fuentes públicas.

Fuentes (verificadas en septiembre de 2026):
  * apis.roblox.com/explore-api/v1/get-sorts (+ get-sort-content)
      Listas oficiales de la página "Charts"/"Descubrir": top-playing-now, most-popular,
      top-trending, up-and-coming, top-rated, top-revisited, trending-in-<género>...
  * apis.roblox.com/search-api/omni-search  — búsqueda por palabra clave, paginada (40 por página)
  * games.roblox.com/v1/games/recommendations/game/{universeId} — juegos recomendados/relacionados
  * apis.roblox.com/universes/v1/places/{placeId}/universe — convertir placeId (URL) → universeId

Nota: el antiguo endpoint games.roblox.com/v1/games/list fue retirado por Roblox;
por eso se usan explore-api y search-api, que son los que utiliza la web oficial
de forma anónima. No son una API "documentada" oficialmente y podrían cambiar.
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field

from .roblox_client import RobloxClient

log = logging.getLogger(__name__)

# Categoría → cómo descubrirla.
#   sorts: listas oficiales de explore-api relacionadas
#   search: palabras clave para la búsqueda pública
#   genres: valores de genre_l1 de Roblox que se consideran "coincidencia estricta"
CATEGORIES: dict[str, dict] = {
    "Horror":      {"sorts": [], "search": ["horror", "scary"], "genres": []},
    "Survival":    {"sorts": ["trending-in-survival"], "search": ["survival"], "genres": ["Survival"]},
    "Simulator":   {"sorts": ["trending-in-simulation"], "search": ["simulator"], "genres": ["Simulation"]},
    "Adventure":   {"sorts": ["trending-in-adventure"], "search": ["adventure"], "genres": ["Adventure"]},
    "Fighting":    {"sorts": ["trending-in-action"], "search": ["fighting", "battlegrounds"], "genres": ["Action"]},
    "FPS":         {"sorts": ["trending-in-shooter"], "search": ["fps", "shooter"], "genres": ["Shooter"]},
    "RPG":         {"sorts": ["trending-in-rpg"], "search": ["rpg"], "genres": ["RPG"]},
    "Tycoon":      {"sorts": [], "search": ["tycoon"], "genres": ["Simulation"]},
    "Obby":        {"sorts": ["trending-in-obby-and-platformer"], "search": ["obby"], "genres": ["Obby & Platformer"]},
    "Roleplay":    {"sorts": ["trending-in-roleplay-and-avatar-sim"], "search": ["roleplay", "rp"], "genres": ["Roleplay & Avatar Sim"]},
    "Puzzle":      {"sorts": ["trending-in-puzzle"], "search": ["puzzle", "escape room"], "genres": ["Puzzle"]},
    "Strategy":    {"sorts": ["trending-in-strategy"], "search": ["tower defense", "strategy"], "genres": ["Strategy"]},
    "Sports & Racing": {"sorts": ["trending-in-sports-and-racing"], "search": ["racing", "soccer"], "genres": ["Sports & Racing"]},
    "Party & Casual":  {"sorts": ["trending-in-party-and-casual"], "search": ["party games", "minigames"], "genres": ["Party & Casual"]},
    "Action":      {"sorts": ["trending-in-action"], "search": ["action"], "genres": ["Action"]},
    "Anime":       {"sorts": [], "search": ["anime"], "genres": []},
}

POPULAR_SORTS = ["most-popular", "top-playing-now", "top-revisited", "top-rated"]
TRENDING_SORTS = ["top-trending", "up-and-coming"]
KNOWN_SORTS = POPULAR_SORTS + TRENDING_SORTS + ["fun-with-friends", "top-earning", "top-paid-access"]

SORT_CRITERIA = {
    "relevance": "Relevancia (orden de la fuente)",
    "playing": "Jugadores actuales",
    "visits": "Visitas",
    "favorites": "Favoritos",
    "likes": "Likes",
    "like_ratio": "Relación likes/dislikes",
    "updated": "Actualizado recientemente",
    "created": "Más recientes (creación)",
}


@dataclass
class Candidate:
    universe_id: int
    place_id: int | None = None
    name: str | None = None
    playing: int | None = None
    up_votes: int | None = None
    down_votes: int | None = None
    via: str = ""


@dataclass
class DiscoveryResult:
    candidates: list[Candidate] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    sources_used: list[str] = field(default_factory=list)


class _Collector:
    def __init__(self, limit: int):
        self.limit = limit
        self.seen: set[int] = set()
        self.items: list[Candidate] = []

    @property
    def full(self):
        return len(self.items) >= self.limit

    def add(self, c: Candidate) -> bool:
        if not c.universe_id or c.universe_id in self.seen or self.full:
            return False
        self.seen.add(c.universe_id)
        self.items.append(c)
        return True


def _to_int(v):
    try:
        return int(v)
    except (TypeError, ValueError):
        return None


def _cand_from_explore(g: dict, via: str) -> Candidate | None:
    if g.get("isSponsored"):
        return None  # anuncios pagados: no son resultados orgánicos
    uid = _to_int(g.get("universeId"))
    if not uid:
        return None
    return Candidate(uid, _to_int(g.get("rootPlaceId") or g.get("placeId")), g.get("name"),
                     _to_int(g.get("playerCount")), _to_int(g.get("totalUpVotes")),
                     _to_int(g.get("totalDownVotes")), via)


def _from_sort(client: RobloxClient, sort_id: str, col: _Collector, res: DiscoveryResult, max_pages=5):
    token, pages = None, 0
    while not col.full and pages < max_pages:
        r = client.sort_content(sort_id, token)
        pages += 1
        if not r.ok:
            res.warnings.append(f"Lista '{sort_id}' no disponible ({r.error})")
            return
        games = r.data.get("games") or []
        for g in games:
            c = _cand_from_explore(g, f"sort:{sort_id}")
            if c:
                col.add(c)
        res.sources_used.append(f"explore-api sort '{sort_id}' ({len(games)} resultados)")
        token = r.data.get("nextPageToken")
        if not token or not games:
            break


def _from_search(client: RobloxClient, query: str, col: _Collector, res: DiscoveryResult, max_pages=30):
    token, pages, total = None, 0, 0
    while not col.full and pages < max_pages:
        r = client.search(query, token)
        pages += 1
        if not r.ok:
            res.warnings.append(f"Búsqueda '{query}' falló en la página {pages} ({r.error})")
            break
        groups = r.data.get("searchResults") or []
        added = 0
        for grp in groups:
            if grp.get("contentGroupType") not in (None, "Game"):
                continue
            for g in grp.get("contents") or []:
                if g.get("contentType") not in (None, "Game"):
                    continue
                c = _cand_from_explore(g, f"search:{query}")
                if c and col.add(c):
                    added += 1
        total += added
        token = r.data.get("nextPageToken")
        if not token or not groups:
            break
    res.sources_used.append(f"search-api '{query}' ({total} nuevos, {pages} páginas)")


def _from_related(client: RobloxClient, seeds: list[int], col: _Collector, res: DiscoveryResult, depth=2):
    frontier = list(dict.fromkeys(seeds))
    visited = set()
    for level in range(depth):
        nxt = []
        for uid in frontier:
            if col.full:
                break
            if uid in visited:
                continue
            visited.add(uid)
            r = client.recommendations(uid, 40)
            if not r.ok:
                res.warnings.append(f"Recomendaciones de {uid} no disponibles ({r.error})")
                continue
            for g in r.data.get("games") or []:
                c = _cand_from_explore(g, f"related:{uid}")
                if c and col.add(c):
                    nxt.append(c.universe_id)
        res.sources_used.append(f"recommendations nivel {level + 1} ({len(nxt)} nuevos)")
        frontier = nxt
        if not frontier or col.full:
            break


URL_RE = re.compile(r"roblox\.com/(?:[a-z]{2}(?:-[a-z]{2})?/)?games/(\d+)", re.I)
UNIVERSE_RE = re.compile(r"universeId=(\d+)", re.I)


def parse_urls(text: str) -> tuple[list[int], list[int], list[str]]:
    """Devuelve (place_ids, universe_ids, líneas no reconocidas)."""
    place_ids, universe_ids, bad = [], [], []
    for line in re.split(r"[\s,;]+", text or ""):
        line = line.strip()
        if not line:
            continue
        m = URL_RE.search(line)
        if m:
            place_ids.append(int(m.group(1)))
            continue
        m = UNIVERSE_RE.search(line)
        if m:
            universe_ids.append(int(m.group(1)))
            continue
        bad.append(line)
    return place_ids, universe_ids, bad


def parse_ids(text: str) -> tuple[list[int], list[str]]:
    ids, bad = [], []
    for tok in re.split(r"[\s,;]+", text or ""):
        tok = tok.strip()
        if not tok:
            continue
        if tok.isdigit():
            ids.append(int(tok))
        else:
            bad.append(tok)
    return ids, bad


def resolve_places(client: RobloxClient, place_ids: list[int], res: DiscoveryResult) -> list[Candidate]:
    out = []
    for pid in dict.fromkeys(place_ids):
        r = client.place_to_universe(pid)
        uid = _to_int(r.data.get("universeId")) if r.ok else None
        if uid:
            out.append(Candidate(uid, pid, via=f"url:place {pid}"))
        else:
            res.warnings.append(f"placeId {pid}: no se pudo resolver el universeId ({r.error or 'sin universo'})")
    return out


def resolve_ids_auto(client: RobloxClient, ids: list[int], id_type: str, res: DiscoveryResult) -> list[Candidate]:
    """id_type: universe | place | auto (prueba universe y luego place)."""
    ids = list(dict.fromkeys(ids))
    if id_type == "place":
        return resolve_places(client, ids, res)
    found: dict[int, Candidate] = {}
    missing = []
    for i in range(0, len(ids), 50):
        chunk = ids[i:i + 50]
        r = client.games_details(chunk)
        got = {int(g["id"]) for g in (r.data or {}).get("data", []) if g.get("id")} if r.ok else set()
        if not r.ok:
            res.warnings.append(f"No se pudieron verificar IDs ({r.error})")
            got = set(chunk) if id_type == "universe" else set()
        for uid in chunk:
            if uid in got:
                found[uid] = Candidate(uid, via="ids:universe")
            else:
                missing.append(uid)
    if id_type == "auto" and missing:
        for c in resolve_places(client, missing, DiscoveryResult()):
            found.setdefault(c.universe_id, c)
        unresolved = [m for m in missing if not any(c.place_id == m for c in found.values())]
        if unresolved:
            res.warnings.append(f"IDs no encontrados (ni universeId ni placeId): {unresolved[:20]}")
    elif missing:
        res.warnings.append(f"universeIds no encontrados o eliminados: {missing[:20]}")
    return list(found.values())


def discover(client: RobloxClient, mode: str, limit: int, category: str | None = None,
             keyword: str | None = None, ids_text: str | None = None, id_type: str = "auto",
             urls_text: str | None = None, seed_ids: list[int] | None = None,
             sort_ids: list[str] | None = None) -> DiscoveryResult:
    """Punto de entrada. mode: popular | trending | category | keyword | related | ids | urls | sort"""
    res = DiscoveryResult()
    col = _Collector(limit)

    if mode == "popular":
        for s in POPULAR_SORTS:
            _from_sort(client, s, col, res)
            if col.full:
                break
    elif mode == "trending":
        for s in TRENDING_SORTS:
            _from_sort(client, s, col, res)
            if col.full:
                break
        if not col.full:
            res.warnings.append("Las listas de tendencia públicas contienen ~100 juegos; se completa con 'Top Playing Now'.")
            _from_sort(client, "top-playing-now", col, res)
    elif mode == "sort":
        for s in sort_ids or []:
            _from_sort(client, s, col, res)
    elif mode in ("category", "keyword"):
        spec = CATEGORIES.get(category or "", None)
        if mode == "keyword" or spec is None:
            terms = [keyword or category or ""]
            sorts = []
        else:
            terms = spec["search"]
            sorts = spec["sorts"]
        for s in sorts:
            _from_sort(client, s, col, res)
        for t in terms:
            if col.full:
                break
            if t:
                _from_search(client, t, col, res)
    elif mode == "related":
        seeds = list(seed_ids or [])
        if ids_text:
            ids, bad = parse_ids(ids_text)
            seeds += [c.universe_id for c in resolve_ids_auto(client, ids, id_type, res)]
        if urls_text:
            p, u, bad = parse_urls(urls_text)
            seeds += u + [c.universe_id for c in resolve_places(client, p, res)]
        if not seeds:
            res.warnings.append("Indica al menos un juego semilla (ID o URL) para buscar relacionados.")
        _from_related(client, seeds, col, res)
    elif mode == "ids":
        ids, bad = parse_ids(ids_text or "")
        if bad:
            res.warnings.append(f"Entradas ignoradas (no numéricas): {bad[:10]}")
        for c in resolve_ids_auto(client, ids, id_type, res):
            col.add(c)
        res.sources_used.append("IDs introducidos por el usuario")
    elif mode == "urls":
        place_ids, universe_ids, bad = parse_urls(urls_text or "")
        if bad:
            res.warnings.append(f"URLs no reconocidas: {bad[:10]}")
        for uid in universe_ids:
            col.add(Candidate(uid, via="url:universe"))
        for c in resolve_places(client, place_ids, res):
            col.add(c)
        res.sources_used.append("URLs introducidas por el usuario")
    else:
        res.warnings.append(f"Modo de descubrimiento desconocido: {mode}")

    res.candidates = col.items
    if not res.candidates:
        res.warnings.append("No se encontraron juegos con esta fuente.")
    log.info("Descubrimiento %s/%s → %d candidatos", mode, category or keyword or "", len(res.candidates))
    return res
