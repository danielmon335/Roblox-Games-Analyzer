"""Cliente HTTP para APIs PÚBLICAS de Roblox.

- Solo endpoints públicos, sin autenticación ni cookies.
- Pausa mínima entre solicitudes por host (REQUEST_INTERVAL).
- Reintentos con backoff exponencial, respeto de HTTP 429 / Retry-After.
- Timeout configurable.
- Caché en SQLite (http_cache) para evitar solicitudes repetidas.
- "Circuit breaker" simple: si un host falla muchas veces seguidas se pausa
  temporalmente y el resto del proceso continúa.
"""
from __future__ import annotations

import logging
import os
import random
import threading
import time
import uuid
from urllib.parse import urlencode, urlparse

import requests

from . import db
from .config import settings

log = logging.getLogger(__name__)

HOSTS = {
    "games": "https://games.roblox.com",
    "apis": "https://apis.roblox.com",
    "thumbnails": "https://thumbnails.roblox.com",
    "badges": "https://badges.roblox.com",
}
# SOLO PARA PRUEBAS: redirige todas las llamadas a un servidor simulado.
MOCK_BASE = os.getenv("ROBLOX_MOCK_BASE", "").rstrip("/")

USER_AGENT = "RobloxGameAnalyzer/1.0 (herramienta local de investigacion; APIs publicas)"


def url_for(host: str, path: str) -> str:
    if MOCK_BASE:
        return f"{MOCK_BASE}/{host}{path}"
    return HOSTS[host] + path


class ApiResult:
    __slots__ = ("data", "status", "error", "from_cache", "url")

    def __init__(self, data=None, status=None, error=None, from_cache=False, url=None):
        self.data, self.status, self.error, self.from_cache, self.url = data, status, error, from_cache, url

    @property
    def ok(self):
        return self.error is None and self.data is not None

    def __repr__(self):
        return f"<ApiResult {self.status} ok={self.ok} cache={self.from_cache} err={self.error}>"


class RobloxClient:
    def __init__(self, cancel_event: threading.Event | None = None):
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": USER_AGENT,
            "Accept": "application/json",
            "Accept-Language": "en-US,en;q=0.8",
        })
        self.session_id = str(uuid.uuid4())
        self.cancel_event = cancel_event or threading.Event()
        self._host_lock = threading.Lock()
        self._last_request: dict[str, float] = {}
        self._fail_streak: dict[str, int] = {}
        self._paused_until: dict[str, float] = {}
        self.stats = {"requests": 0, "cache_hits": 0, "errors": 0, "rate_limited": 0}

    # ------------------------------------------------------------------ util
    def _sleep(self, seconds: float):
        """Espera interrumpible (si se cancela el trabajo)."""
        end = time.time() + max(0.0, seconds)
        while time.time() < end:
            if self.cancel_event.is_set():
                return
            time.sleep(min(0.2, end - time.time()))

    def _throttle(self, host: str):
        interval = float(settings.get("REQUEST_INTERVAL", 0.6))
        with self._host_lock:
            last = self._last_request.get(host, 0.0)
            wait = last + interval - time.time()
            self._last_request[host] = max(time.time(), last + interval)
        if wait > 0:
            self._sleep(wait)

    @staticmethod
    def _cache_get(url: str, ttl: int):
        if ttl <= 0:
            return None
        try:
            r = db.one("SELECT status, body, fetched_at FROM http_cache WHERE url=?", (url,))
        except Exception:  # noqa: BLE001
            return None
        if r and (time.time() - (r["fetched_at"] or 0)) < ttl:
            return r
        return None

    @staticmethod
    def _cache_put(url: str, status: int, body: str):
        try:
            db.execute("INSERT OR REPLACE INTO http_cache (url, status, body, fetched_at) VALUES (?,?,?,?)",
                       (url, status, body, time.time()))
        except Exception as e:  # noqa: BLE001
            log.debug("cache put falló: %s", e)

    # --------------------------------------------------------------- request
    def get_json(self, host: str, path: str, params: dict | None = None, ttl: int | None = None,
                 context: str = "") -> ApiResult:
        params = {k: v for k, v in (params or {}).items() if v is not None and v != ""}
        url = url_for(host, path)
        if params:
            url = url + ("&" if "?" in url else "?") + urlencode(sorted(params.items()))
        if ttl is None:
            ttl = int(settings.get("CACHE_TTL_STATS", 600))

        cached = self._cache_get(url, ttl)
        if cached is not None:
            self.stats["cache_hits"] += 1
            data = db.jload(cached["body"])
            if data is not None:
                return ApiResult(data, cached["status"], None, True, url)

        hostname = urlparse(url).netloc
        if self._paused_until.get(hostname, 0) > time.time():
            return ApiResult(None, None, f"Host {hostname} pausado temporalmente por errores repetidos", False, url)

        max_retries = int(settings.get("MAX_RETRIES", 4))
        backoff = float(settings.get("BACKOFF_BASE", 1.5))
        timeout = float(settings.get("REQUEST_TIMEOUT", 15))
        last_err, last_status = None, None

        for attempt in range(max_retries + 1):
            if self.cancel_event.is_set():
                return ApiResult(None, None, "cancelado", False, url)
            self._throttle(hostname)
            try:
                self.stats["requests"] += 1
                resp = self.session.get(url, timeout=timeout)
                last_status = resp.status_code
                if resp.status_code == 200:
                    try:
                        data = resp.json()
                    except ValueError:
                        last_err = "Respuesta no es JSON válido"
                        break
                    self._fail_streak[hostname] = 0
                    self._cache_put(url, 200, resp.text)
                    return ApiResult(data, 200, None, False, url)
                if resp.status_code == 429:
                    self.stats["rate_limited"] += 1
                    ra = resp.headers.get("Retry-After")
                    try:
                        wait = float(ra) if ra else backoff * (2 ** attempt)
                    except ValueError:
                        wait = backoff * (2 ** attempt)
                    wait = min(wait, 60) + random.uniform(0, 0.5)
                    log.warning("HTTP 429 en %s — esperando %.1fs (intento %d)", hostname, wait, attempt + 1)
                    last_err = "HTTP 429 (rate limit)"
                    self._sleep(wait)
                    continue
                if resp.status_code >= 500:
                    last_err = f"HTTP {resp.status_code}"
                    self._sleep(backoff * (2 ** attempt) + random.uniform(0, 0.5))
                    continue
                # 4xx distinto de 429: no tiene sentido reintentar
                last_err = f"HTTP {resp.status_code}: {resp.text[:200]}"
                break
            except requests.Timeout:
                last_err = "Timeout"
            except requests.RequestException as e:
                last_err = f"Error de conexión: {type(e).__name__}: {str(e)[:200]}"
            self._sleep(backoff * (2 ** attempt) + random.uniform(0, 0.5))

        self.stats["errors"] += 1
        # 404/400 no cuentan como fallo del host
        if not (last_status and 400 <= last_status < 500 and last_status != 429):
            streak = self._fail_streak.get(hostname, 0) + 1
            self._fail_streak[hostname] = streak
            if streak >= 6:
                self._paused_until[hostname] = time.time() + 90
                self._fail_streak[hostname] = 0
                log.error("Host %s pausado 90s tras %d fallos seguidos", hostname, streak)
        db.log_error(context or "http", last_err or "error desconocido", url, last_status)
        log.warning("Fallo %s → %s", url, last_err)
        return ApiResult(None, last_status, last_err, False, url)

    # ============================================================ endpoints
    # --- Detalles de juegos (hasta 50 IDs por llamada)
    def games_details(self, universe_ids: list[int], fresh: bool = False) -> ApiResult:
        return self.get_json("games", "/v1/games", {"universeIds": ",".join(map(str, universe_ids))},
                             ttl=0 if fresh else None, context="games_details")

    def games_votes(self, universe_ids: list[int], fresh: bool = False) -> ApiResult:
        return self.get_json("games", "/v1/games/votes", {"universeIds": ",".join(map(str, universe_ids))},
                             ttl=0 if fresh else None, context="games_votes")

    def favorites_count(self, universe_id: int) -> ApiResult:
        return self.get_json("games", f"/v1/games/{universe_id}/favorites/count", context="favorites")

    def game_icons(self, universe_ids: list[int]) -> ApiResult:
        return self.get_json("thumbnails", "/v1/games/icons", {
            "universeIds": ",".join(map(str, universe_ids)), "size": "150x150", "format": "Png",
            "isCircular": "false", "returnPolicy": "PlaceHolder"},
            ttl=int(settings.get("CACHE_TTL_STATIC", 86400)), context="icons")

    def place_to_universe(self, place_id: int) -> ApiResult:
        return self.get_json("apis", f"/universes/v1/places/{place_id}/universe",
                             ttl=30 * 86400, context="place_to_universe")

    def recommendations(self, universe_id: int, max_rows: int = 30) -> ApiResult:
        return self.get_json("games", f"/v1/games/recommendations/game/{universe_id}",
                             {"maxRows": max_rows}, context="recommendations")

    def public_servers(self, place_id: int, cursor: str | None = None) -> ApiResult:
        return self.get_json("games", f"/v1/games/{place_id}/servers/Public",
                             {"limit": 100, "cursor": cursor}, context="servers")

    # --- Descubrimiento (explore / search). Endpoints públicos usados por la web oficial.
    def get_sorts(self, page_id: str = "Charts", page_token: str | None = None) -> ApiResult:
        return self.get_json("apis", "/explore-api/v1/get-sorts", {
            "sessionId": self.session_id, "sortsPageId": page_id, "sortsPageToken": page_token},
            context="explore_sorts")

    def sort_content(self, sort_id: str, page_token: str | None = None) -> ApiResult:
        return self.get_json("apis", "/explore-api/v1/get-sort-content", {
            "sessionId": self.session_id, "sortId": sort_id, "pageToken": page_token},
            context="explore_sort_content")

    def search(self, query: str, page_token: str | None = None) -> ApiResult:
        return self.get_json("apis", "/search-api/omni-search", {
            "searchQuery": query, "sessionId": self.session_id, "pageType": "all", "pageToken": page_token},
            context="search")

    # --- Datos adicionales públicos
    def gamepasses(self, universe_id: int, page_token: str | None = None) -> ApiResult:
        return self.get_json("apis", f"/game-passes/v1/universes/{universe_id}/game-passes", {
            "passView": "Full", "pageSize": 100, "pageToken": page_token},
            ttl=int(settings.get("CACHE_TTL_STATIC", 86400)), context="gamepasses")

    def badges(self, universe_id: int, cursor: str | None = None) -> ApiResult:
        return self.get_json("badges", f"/v1/universes/{universe_id}/badges", {
            "limit": 100, "sortOrder": "Asc", "cursor": cursor},
            ttl=int(settings.get("CACHE_TTL_STATIC", 86400)), context="badges")
