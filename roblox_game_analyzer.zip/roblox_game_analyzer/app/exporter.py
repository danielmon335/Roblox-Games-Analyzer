"""Exportación: CSV, JSON, Excel (.xlsx) e informe HTML."""
from __future__ import annotations

import html
import io
import json
from datetime import datetime

import pandas as pd

from . import db, patterns
from .mechanics import STATUS_LABELS, TAXONOMY

NA = "No disponible"


def games_frame(uids: list[int]) -> pd.DataFrame:
    if not uids:
        return pd.DataFrame()
    stats = patterns.latest_stats(uids)
    rows = []
    for i in range(0, len(uids), 900):
        chunk = uids[i:i + 900]
        rows += db.rows(f"SELECT * FROM games WHERE universe_id IN ({','.join('?' * len(chunk))})", chunk)
    cats = {}
    for r in db.rows("SELECT universe_id, category, source FROM game_categories"):
        cats.setdefault(r["universe_id"], []).append(r["category"])
    out = []
    for g in rows:
        s = stats.get(g["universe_id"], {})
        out.append({
            "universeId": g["universe_id"], "placeId": g["place_id"], "nombre": g["name"],
            "creador": g["creator_name"], "tipo_creador": g["creator_type"],
            "jugadores": s.get("playing"), "visitas": s.get("visits"), "favoritos": s.get("favorites"),
            "likes": s.get("up_votes"), "dislikes": s.get("down_votes"), "aprobacion_pct": s.get("like_ratio"),
            "servidores": s.get("server_count"),
            "genero_l1": g["genre_l1"], "genero_l2": g["genre_l2"],
            "categorias": ", ".join(sorted(set(cats.get(g["universe_id"], [])))),
            "creado": g["created"], "actualizado": g["updated"], "max_jugadores": g["max_players"],
            "gamepasses": g["gamepass_count"], "insignias": g["badge_count"],
            "url": g["url"], "icono": g["icon_url"], "descripcion": g["description"],
            "snapshot": s.get("captured_at"), "estado": g["status"],
        })
    df = pd.DataFrame(out)
    if not df.empty:
        df = df.sort_values("jugadores", ascending=False, na_position="last")
    return df


def mechanics_frame(uids: list[int]) -> pd.DataFrame:
    if not uids:
        return pd.DataFrame()
    names = {r["universe_id"]: r["name"] for r in db.rows("SELECT universe_id, name FROM games")}
    data: dict[int, dict] = {}
    for i in range(0, len(uids), 900):
        chunk = uids[i:i + 900]
        for r in db.rows(f"SELECT universe_id, mechanic_key, status FROM game_mechanics WHERE method='rules' AND "
                         f"universe_id IN ({','.join('?' * len(chunk))})", chunk):
            data.setdefault(r["universe_id"], {})[r["mechanic_key"]] = STATUS_LABELS.get(r["status"], r["status"])
    rows = []
    for uid in uids:
        row = {"universeId": uid, "nombre": names.get(uid)}
        for m in TAXONOMY:
            row[f"{m['group']}:{m['label']}"] = data.get(uid, {}).get(m["key"], "Sin analizar")
        rows.append(row)
    return pd.DataFrame(rows)


def snapshots_frame(uids: list[int]) -> pd.DataFrame:
    rows = []
    for i in range(0, len(uids), 900):
        chunk = uids[i:i + 900]
        rows += db.rows(f"SELECT s.universe_id, g.name, s.captured_at, s.playing, s.visits, s.favorites, s.up_votes, "
                        f"s.down_votes, s.like_ratio, s.server_count FROM game_snapshots s JOIN games g "
                        f"ON g.universe_id=s.universe_id WHERE s.universe_id IN ({','.join('?' * len(chunk))}) "
                        f"ORDER BY s.universe_id, s.captured_at", chunk)
    return pd.DataFrame(rows)


def patterns_frames(pat: dict) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    mech = pd.DataFrame([{
        "grupo": m["group_label"], "mecanica": m["label"], "juegos_donde_aparece": m["count"],
        "juegos_con_info": m["games_with_info"], "porcentaje": m["percent"],
        "detectada": m["detected"], "probable": m["probable"], "sin_info": m["insufficient"]}
        for m in pat.get("mechanics", [])])
    combos = pd.DataFrame([{"combinacion": " + ".join(c["labels"]), "juegos": c["count"], "porcentaje": c["percent"],
                            "base": c["base"]} for c in pat.get("combinations", [])])
    assoc = pd.DataFrame([{"mecanica": a["label"], "n_con": a["n_with"], "n_sin": a["n_without"],
                           "mediana_jugadores_con": a["median_with"], "mediana_jugadores_sin": a["median_without"],
                           "ratio": a["ratio"]} for a in pat.get("associations", [])])
    return mech, combos, assoc


def export(fmt: str, job_id=None, category=None, include_probable=False, what="games") -> tuple[bytes, str, str]:
    uids = patterns.select_games(job_id, category)
    stamp = datetime.now().strftime("%Y%m%d_%H%M")
    tag = f"_job{job_id}" if job_id else (f"_{category}" if category else "")
    tag = "".join(ch if ch.isalnum() or ch in "_-" else "_" for ch in tag)
    if fmt == "csv":
        if what == "mechanics":
            df = mechanics_frame(uids)
        elif what == "snapshots":
            df = snapshots_frame(uids)
        elif what == "patterns":
            df = patterns_frames(patterns.full_patterns(job_id, category, include_probable=include_probable))[0]
        else:
            df = games_frame(uids)
        data = df.to_csv(index=False).encode("utf-8-sig")  # BOM para que Excel lea acentos
        return data, "text/csv; charset=utf-8", f"roblox_{what}{tag}_{stamp}.csv"
    pat = patterns.full_patterns(job_id, category, include_probable=include_probable)
    if fmt == "json":
        gdf = games_frame(uids)
        payload = {
            "generado": datetime.now().isoformat(timespec="seconds"),
            "filtro": {"job_id": job_id, "categoria": category},
            "juegos": json.loads(gdf.to_json(orient="records", force_ascii=False)) if not gdf.empty else [],
            "mecanicas_por_juego": _mechanics_detail(uids),
            "patrones": pat,
            "aviso": patterns.DISCLAIMER,
        }
        return json.dumps(payload, ensure_ascii=False, indent=2, default=str).encode("utf-8"), \
            "application/json", f"roblox_export{tag}_{stamp}.json"
    if fmt == "xlsx":
        buf = io.BytesIO()
        mech, combos, assoc = patterns_frames(pat)
        with pd.ExcelWriter(buf, engine="openpyxl") as xw:
            pd.DataFrame([{"clave": k, "valor": v} for k, v in (pat.get("overview") or {}).items()] +
                         [{"clave": "aviso", "valor": patterns.DISCLAIMER}]).to_excel(xw, sheet_name="Resumen", index=False)
            _safe(games_frame(uids)).to_excel(xw, sheet_name="Juegos", index=False)
            _safe(mechanics_frame(uids)).to_excel(xw, sheet_name="Mecanicas_por_juego", index=False)
            _safe(mech).to_excel(xw, sheet_name="Frecuencia_mecanicas", index=False)
            _safe(combos).to_excel(xw, sheet_name="Combinaciones", index=False)
            _safe(assoc).to_excel(xw, sheet_name="Asociaciones", index=False)
            _safe(snapshots_frame(uids)).to_excel(xw, sheet_name="Snapshots", index=False)
        return buf.getvalue(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", \
            f"roblox_export{tag}_{stamp}.xlsx"
    if fmt == "html":
        return html_report(uids, pat, job_id, category).encode("utf-8"), "text/html; charset=utf-8", \
            f"roblox_informe{tag}_{stamp}.html"
    raise ValueError(f"Formato no soportado: {fmt}")


def _safe(df: pd.DataFrame) -> pd.DataFrame:
    """Excel no admite ciertos caracteres de control y limita celdas a 32767 chars."""
    if df.empty:
        return pd.DataFrame({"info": ["Sin datos"]})
    df = df.copy()
    for c in df.columns:
        if df[c].dtype == object:
            df[c] = df[c].map(lambda v: (''.join(ch for ch in v if ch >= ' ' or ch in '\n\t')[:32000]) if isinstance(v, str) else v)
    return df


def _mechanics_detail(uids):
    out = {}
    for i in range(0, len(uids), 900):
        chunk = uids[i:i + 900]
        for r in db.rows(f"SELECT universe_id, mechanic_key, status, evidence FROM game_mechanics WHERE method='rules' "
                         f"AND universe_id IN ({','.join('?' * len(chunk))})", chunk):
            out.setdefault(str(r["universe_id"]), {})[r["mechanic_key"]] = {
                "estado": STATUS_LABELS.get(r["status"]), "evidencia": db.jload(r["evidence"], [])}
    return out


def _fmt(v):
    if v is None or (isinstance(v, float) and pd.isna(v)):
        return NA
    if isinstance(v, (int,)) or (isinstance(v, float) and v.is_integer()):
        return f"{int(v):,}".replace(",", ".")
    if isinstance(v, float):
        return f"{v:,.1f}".replace(",", "X").replace(".", ",").replace("X", ".")
    return html.escape(str(v))


def html_report(uids, pat, job_id, category) -> str:
    gdf = games_frame(uids)
    ov = pat.get("overview", {})
    esc = html.escape
    title = "Informe Roblox Game Analyzer" + (f" — lote #{job_id}" if job_id else "") + (f" — {category}" if category else "")
    parts = [f"""<!doctype html><html lang="es"><head><meta charset="utf-8"><title>{esc(title)}</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>body{{font-family:Segoe UI,system-ui,sans-serif;margin:24px;color:#1b1f24;background:#fff}}
h1{{font-size:22px}}h2{{font-size:17px;margin-top:28px;border-bottom:1px solid #ddd;padding-bottom:4px}}
table{{border-collapse:collapse;width:100%;font-size:13px;margin:8px 0}}th,td{{border:1px solid #e1e4e8;padding:4px 6px;text-align:left;vertical-align:top}}
th{{background:#f3f4f6}}.note{{background:#fff8e1;border:1px solid #f0d58c;padding:8px 10px;border-radius:6px;font-size:13px}}
.kpis{{display:flex;flex-wrap:wrap;gap:10px}}.kpi{{border:1px solid #e1e4e8;border-radius:6px;padding:8px 12px;min-width:140px}}
.kpi b{{display:block;font-size:18px}}.bar{{background:#4f6bed;height:10px;border-radius:3px}}td.num{{text-align:right}}</style></head><body>
<h1>{esc(title)}</h1><p>Generado: {datetime.now().strftime('%d/%m/%Y %H:%M')} · Fuentes: APIs públicas de Roblox</p>
<h2>Resumen</h2><div class="kpis">"""]
    for label, key in [("Juegos", "n_games"), ("Jugadores totales", "total_playing"), ("Promedio jugadores", "avg_playing"),
                       ("Promedio visitas", "avg_visits"), ("Promedio favoritos", "avg_favorites"),
                       ("Promedio likes", "avg_up_votes"), ("Aprobación media %", "avg_like_ratio")]:
        parts.append(f'<div class="kpi">{label}<b>{_fmt(ov.get(key))}</b></div>')
    parts.append("</div>")
    if pat.get("highlights"):
        parts.append("<ul>" + "".join(f"<li>{esc(h)}</li>" for h in pat["highlights"]) + "</ul>")
    parts.append(f'<p class="note">{esc(patterns.DISCLAIMER)}</p>')

    parts.append("<h2>Estadísticas por grupo de mecánicas</h2><table><tr><th>Grupo</th><th>Juegos donde aparece</th><th>Juegos con información</th><th>%</th></tr>")
    for g in pat.get("groups", []):
        parts.append(f"<tr><td>{esc(g['label'])}</td><td class=num>{g['count']}</td><td class=num>{g['games_with_info']}</td><td class=num>{_fmt(g['percent'])}</td></tr>")
    parts.append("</table>")

    parts.append("<h2>Mecánicas</h2><table><tr><th>Grupo</th><th>Mecánica</th><th>Juegos donde aparece</th><th>Base (con info)</th><th>Porcentaje</th><th></th></tr>")
    for m in sorted(pat.get("mechanics", []), key=lambda m: (m["group_label"], -(m["percent"] or 0))):
        pct = m["percent"] or 0
        parts.append(f"<tr><td>{esc(m['group_label'])}</td><td>{esc(m['label'])}</td><td class=num>{m['count']}</td>"
                     f"<td class=num>{m['games_with_info']}</td><td class=num>{_fmt(m['percent'])}</td>"
                     f"<td style='width:160px'><div class=bar style='width:{pct:.0f}%'></div></td></tr>")
    parts.append("</table><p class=note>Los porcentajes se calculan solo sobre juegos con información suficiente para cada mecánica.</p>")

    parts.append("<h2>Patrones: combinaciones frecuentes</h2><table><tr><th>Combinación</th><th>Juegos</th><th>%</th></tr>")
    for c in pat.get("combinations", []):
        parts.append(f"<tr><td>{esc(' + '.join(c['labels']))}</td><td class=num>{c['count']}</td><td class=num>{_fmt(c['percent'])}</td></tr>")
    parts.append("</table>")
    if pat.get("associations"):
        parts.append("<h2>Asociaciones observadas (jugadores actuales, mediana)</h2><p class=note>Asociación observada en esta muestra; no demuestra causalidad.</p>"
                     "<table><tr><th>Mecánica</th><th>Mediana con</th><th>Mediana sin</th><th>n con / sin</th></tr>")
        for a in pat["associations"][:25]:
            parts.append(f"<tr><td>{esc(a['label'])}</td><td class=num>{_fmt(a['median_with'])}</td><td class=num>{_fmt(a['median_without'])}</td><td class=num>{a['n_with']} / {a['n_without']}</td></tr>")
        parts.append("</table>")

    parts.append("<h2>Datos de los juegos</h2><table><tr><th>Nombre</th><th>Creador</th><th>Jugadores</th><th>Visitas</th><th>Favoritos</th><th>Likes</th><th>Aprob. %</th><th>Género</th><th>Actualizado</th></tr>")
    for _, r in gdf.iterrows() if not gdf.empty else []:
        name = f"<a href='{esc(r['url'])}'>{esc(str(r['nombre']))}</a>" if r.get("url") else esc(str(r["nombre"]))
        parts.append(f"<tr><td>{name}</td><td>{_fmt(r['creador'])}</td><td class=num>{_fmt(r['jugadores'])}</td><td class=num>{_fmt(r['visitas'])}</td>"
                     f"<td class=num>{_fmt(r['favoritos'])}</td><td class=num>{_fmt(r['likes'])}</td><td class=num>{_fmt(r['aprobacion_pct'])}</td>"
                     f"<td>{_fmt(r['genero_l1'])}</td><td>{_fmt(str(r['actualizado'])[:10] if r['actualizado'] else None)}</td></tr>")
    parts.append("</table><p style='color:#666;font-size:12px'>Datos obtenidos de endpoints públicos de Roblox (games, votes, thumbnails, "
                 "game-passes, badges, explore-api, search-api). Los datos no disponibles se muestran como «No disponible».</p></body></html>")
    return "".join(parts)
