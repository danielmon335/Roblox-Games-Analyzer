"""Estadísticas agregadas y detección de patrones (descriptivos, NO causales)."""
from __future__ import annotations

import statistics
from collections import Counter
from itertools import combinations

from . import db
from .mechanics import GROUP_LABELS, STATUS_LABELS, TAX_BY_KEY, TAXONOMY

DISCLAIMER = ("Estos patrones son DESCRIPTIVOS: indican con qué frecuencia aparecen ciertas mecánicas "
              "en la muestra analizada según fuentes públicas. No demuestran que ninguna mecánica sea la "
              "causa del éxito de un juego. Existe una asociación observada en esta muestra, pero esto no "
              "demuestra causalidad.")

LATEST_SNAPSHOT_SQL = """
SELECT s.* FROM game_snapshots s
JOIN (SELECT universe_id, MAX(captured_at) mx FROM game_snapshots GROUP BY universe_id) t
  ON s.universe_id = t.universe_id AND s.captured_at = t.mx
"""


def select_games(job_id: int | None = None, category: str | None = None, ids: list[int] | None = None) -> list[int]:
    if ids:
        return [int(i) for i in ids]
    if job_id:
        return [r["universe_id"] for r in db.rows(
            "SELECT jg.universe_id FROM job_games jg JOIN games g ON g.universe_id=jg.universe_id "
            "WHERE jg.job_id=? AND g.status='ok'", (job_id,))]
    if category:
        return [r["universe_id"] for r in db.rows(
            "SELECT DISTINCT c.universe_id FROM game_categories c JOIN games g ON g.universe_id=c.universe_id "
            "WHERE c.category=? AND g.status='ok'", (category,))]
    return [r["universe_id"] for r in db.rows("SELECT universe_id FROM games WHERE status='ok'")]


def _in_clause(ids):
    return ",".join("?" * len(ids))


def mechanic_stats(universe_ids: list[int], include_probable: bool = False, method: str = "rules") -> dict:
    if not universe_ids:
        return {"n_games": 0, "n_analyzed": 0, "mechanics": [], "groups": [], "disclaimer": DISCLAIMER}
    rows = []
    for i in range(0, len(universe_ids), 900):
        chunk = universe_ids[i:i + 900]
        rows += db.rows(f"SELECT universe_id, mechanic_key, status FROM game_mechanics WHERE method=? "
                        f"AND universe_id IN ({_in_clause(chunk)})", [method] + chunk)
    by_game: dict[int, dict[str, str]] = {}
    for r in rows:
        by_game.setdefault(r["universe_id"], {})[r["mechanic_key"]] = r["status"]

    positive = {"detectada", "probable"} if include_probable else {"detectada"}
    mech = []
    for m in TAXONOMY:
        k = m["key"]
        statuses = [g.get(k) for g in by_game.values() if g.get(k)]
        n_suff = sum(1 for s in statuses if s != "insuficiente")
        det = sum(1 for s in statuses if s == "detectada")
        prob = sum(1 for s in statuses if s == "probable")
        pos = sum(1 for s in statuses if s in positive)
        mech.append({
            "key": k, "label": m["label"], "group": m["group"], "group_label": GROUP_LABELS[m["group"]],
            "derived": bool(m.get("derived")),
            "games_with_info": n_suff, "detected": det, "probable": prob,
            "count": pos, "percent": round(100 * pos / n_suff, 1) if n_suff else None,
            "insufficient": sum(1 for s in statuses if s == "insuficiente"),
        })

    groups = []
    for gk, glabel in GROUP_LABELS.items():
        keys = [m["key"] for m in TAXONOMY if m["group"] == gk and not m.get("derived")]
        n_suff, pos = 0, 0
        for g in by_game.values():
            st = [g.get(k) for k in keys if g.get(k)]
            if st and any(s != "insuficiente" for s in st):
                n_suff += 1
                if any(s in positive for s in st):
                    pos += 1
        groups.append({"key": gk, "label": glabel, "games_with_info": n_suff, "count": pos,
                       "percent": round(100 * pos / n_suff, 1) if n_suff else None})

    return {"n_games": len(universe_ids), "n_analyzed": len(by_game), "include_probable": include_probable,
            "mechanics": mech, "groups": groups, "by_game": by_game, "disclaimer": DISCLAIMER}


def combinations_stats(by_game: dict, include_probable=False, top_mechanics=25, min_support=2, limit=25,
                       level="mechanic") -> list[dict]:
    positive = {"detectada", "probable"} if include_probable else {"detectada"}
    derived = {m["key"] for m in TAXONOMY if m.get("derived")}
    sets = []
    for g in by_game.values():
        if level == "group":
            s = {TAX_BY_KEY[k]["group"] for k, st in g.items() if st in positive and k not in derived and k in TAX_BY_KEY}
        else:
            s = {k for k, st in g.items() if st in positive and k not in derived and k in TAX_BY_KEY}
        has_info = any(st != "insuficiente" for st in g.values())
        if has_info:
            sets.append(s)
    n = len(sets)
    if n == 0:
        return []
    freq = Counter(x for s in sets for x in s)
    top = {k for k, _ in freq.most_common(top_mechanics)}
    combos = Counter()
    for s in sets:
        items = sorted(s & top)
        for size in (2, 3):
            for c in combinations(items, size):
                combos[c] += 1
    label = (lambda k: GROUP_LABELS[k]) if level == "group" else (lambda k: TAX_BY_KEY[k]["label"])
    out = []
    for c, cnt in combos.most_common():
        if cnt < min_support:
            break
        out.append({"items": list(c), "labels": [label(k) for k in c], "size": len(c), "count": cnt,
                    "percent": round(100 * cnt / n, 1), "base": n})
    # Prioriza variedad: primero las más frecuentes de tamaño 3 y 2 intercaladas
    out.sort(key=lambda r: (-r["count"], -r["size"]))
    return out[:limit]


def latest_stats(universe_ids: list[int]) -> dict[int, dict]:
    if not universe_ids:
        return {}
    out = {}
    for i in range(0, len(universe_ids), 900):
        chunk = universe_ids[i:i + 900]
        for r in db.rows(LATEST_SNAPSHOT_SQL + f" WHERE s.universe_id IN ({_in_clause(chunk)})", chunk):
            out[r["universe_id"]] = r
    return out


def associations(by_game: dict, include_probable=False, metric="playing") -> list[dict]:
    """Mediana de una métrica en juegos con vs. sin la mecánica. Solo descriptivo."""
    positive = {"detectada", "probable"} if include_probable else {"detectada"}
    stats = latest_stats(list(by_game.keys()))
    out = []
    for m in TAXONOMY:
        if m.get("derived"):
            continue
        k = m["key"]
        with_v, without_v = [], []
        for uid, g in by_game.items():
            st = g.get(k)
            val = (stats.get(uid) or {}).get(metric)
            if st is None or st == "insuficiente" or val is None:
                continue
            (with_v if st in positive else without_v).append(val)
        if len(with_v) >= 3 and len(without_v) >= 3:
            mw, mo = statistics.median(with_v), statistics.median(without_v)
            out.append({"key": k, "label": m["label"], "group_label": GROUP_LABELS[m["group"]],
                        "n_with": len(with_v), "n_without": len(without_v),
                        "median_with": mw, "median_without": mo,
                        "ratio": round(mw / mo, 2) if mo else None})
    out.sort(key=lambda r: -(r["ratio"] or 0))
    return out


def overview(universe_ids: list[int]) -> dict:
    stats = latest_stats(universe_ids)
    vals = list(stats.values())

    def avg(key):
        xs = [v[key] for v in vals if v.get(key) is not None]
        return round(sum(xs) / len(xs), 1) if xs else None

    def total(key):
        xs = [v[key] for v in vals if v.get(key) is not None]
        return sum(xs) if xs else None

    return {"n_games": len(universe_ids), "with_stats": len(vals),
            "total_playing": total("playing"), "avg_playing": avg("playing"),
            "avg_visits": avg("visits"), "avg_favorites": avg("favorites"),
            "avg_up_votes": avg("up_votes"), "avg_like_ratio": avg("like_ratio")}


def full_patterns(job_id=None, category=None, ids=None, include_probable=False) -> dict:
    uids = select_games(job_id, category, ids)
    ms = mechanic_stats(uids, include_probable)
    by_game = ms.pop("by_game", {})
    combos = combinations_stats(by_game, include_probable)
    group_combos = combinations_stats(by_game, include_probable, level="group", limit=15)
    assoc = associations(by_game, include_probable)
    top = sorted([m for m in ms["mechanics"] if m["percent"] is not None and not m["derived"]],
                 key=lambda m: -m["percent"])
    highlights = [f"{m['percent']}% ({m['count']}/{m['games_with_info']}) presentan '{m['label']}'"
                  for m in top[:10] if m["count"] > 0]
    return {**ms, "combinations": combos, "group_combinations": group_combos, "associations": assoc,
            "highlights": highlights, "overview": overview(uids), "status_labels": STATUS_LABELS,
            "filter": {"job_id": job_id, "category": category, "include_probable": include_probable}}
