"""Servidor web Flask: API JSON + frontend estático."""
from __future__ import annotations

import logging
import traceback

from flask import Flask, Response, jsonify, request, send_from_directory

from . import db, exporter, mechanics, patterns
from .ai_analyzer import SECTIONS, AIError, ai_status, analyze_with_ai
from .config import STATIC_DIR, settings
from .discovery import CATEGORIES, KNOWN_SORTS, SORT_CRITERIA
from .jobs import JOB_TYPES, manager
from .mechanics import GROUP_LABELS, STATUS_LABELS, TAXONOMY

log = logging.getLogger(__name__)

LATEST_JOIN = """
LEFT JOIN (
  SELECT s.* FROM game_snapshots s
  JOIN (SELECT universe_id, MAX(captured_at) mx FROM game_snapshots GROUP BY universe_id) t
    ON s.universe_id=t.universe_id AND s.captured_at=t.mx
) s ON s.universe_id = g.universe_id
"""

GAME_SORTS = {
    "name": "g.name COLLATE NOCASE", "playing": "s.playing", "visits": "s.visits", "favorites": "s.favorites",
    "likes": "s.up_votes", "like_ratio": "s.like_ratio", "updated": "g.updated", "created": "g.created",
    "category": "categories", "last_fetched": "g.last_fetched",
}


def _int_arg(name, default=None):
    v = request.args.get(name)
    if v is None or v == "":
        return default
    try:
        return int(float(v))
    except ValueError:
        return default


def create_app() -> Flask:
    app = Flask(__name__, static_folder=str(STATIC_DIR), static_url_path="/static")
    app.json.ensure_ascii = False
    app.json.sort_keys = False

    @app.errorhandler(Exception)
    def handle_error(e):
        code = getattr(e, "code", 500)
        if isinstance(code, int) and 400 <= code < 500:
            return jsonify({"error": str(e)}), code
        log.error("Error en %s: %s\n%s", request.path, e, traceback.format_exc())
        db.log_error(f"web:{request.path}", f"{type(e).__name__}: {e}")
        return jsonify({"error": f"{type(e).__name__}: {e}"}), 500

    @app.get("/")
    def index():
        return send_from_directory(STATIC_DIR, "index.html")

    # ------------------------------------------------------------ meta
    @app.get("/api/meta")
    def meta():
        return jsonify({
            "categories": list(CATEGORIES.keys()),
            "category_specs": CATEGORIES,
            "sort_criteria": SORT_CRITERIA,
            "known_sorts": KNOWN_SORTS,
            "modes": {"category": "Categoría / género", "popular": "Juegos populares", "trending": "En tendencia",
                      "related": "Relacionados / recomendados", "keyword": "Palabra clave libre",
                      "ids": "Lista de IDs", "urls": "Lista de URLs de Roblox", "sort": "Lista oficial (sort) de Roblox"},
            "taxonomy": [{"key": m["key"], "group": m["group"], "label": m["label"], "derived": bool(m.get("derived"))} for m in TAXONOMY],
            "groups": GROUP_LABELS, "status_labels": STATUS_LABELS, "ai": ai_status(),
            "ai_sections": SECTIONS, "job_types": JOB_TYPES, "disclaimer": patterns.DISCLAIMER,
            "settings": {"MAX_RESULTS": settings.get("MAX_RESULTS"), "BATCH_SIZE": settings.get("BATCH_SIZE"),
                         "HARD_MAX_RESULTS": settings.get("HARD_MAX_RESULTS"), "UI_PAGE_SIZE": settings.get("UI_PAGE_SIZE"),
                         "MIN_SNAPSHOT_MINUTES": settings.get("MIN_SNAPSHOT_MINUTES")},
        })

    # ------------------------------------------------------------ dashboard
    @app.get("/api/dashboard")
    def dashboard():
        found = db.one("SELECT COUNT(*) n FROM games WHERE status='ok'")["n"]
        total_seen = db.one("SELECT COUNT(*) n FROM games")["n"]
        analyzed = db.one("SELECT COUNT(DISTINCT gm.universe_id) n FROM game_mechanics gm JOIN games g ON g.universe_id=gm.universe_id "
                          "WHERE gm.method='rules' AND g.status='ok'")["n"]
        agg = db.one(f"SELECT SUM(s.playing) tp, AVG(s.playing) ap, AVG(s.up_votes) al, AVG(s.visits) av, AVG(s.favorites) af, "
                     f"AVG(s.like_ratio) ar FROM games g {LATEST_JOIN} WHERE g.status='ok'")
        cats = db.rows("SELECT category, source, COUNT(*) n FROM game_categories c JOIN games g ON g.universe_id=c.universe_id "
                       "WHERE g.status='ok' GROUP BY category, source ORDER BY n DESC")
        last = db.one("SELECT MAX(last_fetched) lf FROM games")["lf"]
        top = db.rows(f"SELECT g.universe_id, g.name, g.icon_url, s.playing FROM games g {LATEST_JOIN} WHERE g.status='ok' "
                      f"ORDER BY s.playing DESC LIMIT 8")
        jobs = db.rows("SELECT id, type, status, progress, total, message, created_at, finished_at FROM jobs ORDER BY id DESC LIMIT 6")
        snaps = db.one("SELECT COUNT(*) n FROM game_snapshots")["n"]
        grp = patterns.mechanic_stats(patterns.select_games())
        return jsonify({
            "games_found": found, "games_total_seen": total_seen, "games_analyzed": analyzed,
            "total_playing": agg["tp"], "avg_playing": agg["ap"], "avg_likes": agg["al"], "avg_visits": agg["av"],
            "avg_favorites": agg["af"], "avg_like_ratio": agg["ar"],
            "categories": cats, "categories_count": len({c["category"] for c in cats}),
            "last_update": last, "top_games": top, "recent_jobs": jobs, "snapshots": snaps,
            "groups": grp["groups"], "ai": ai_status(),
        })

    # ------------------------------------------------------------ games
    @app.get("/api/games")
    def games():
        q = (request.args.get("q") or "").strip()
        category = request.args.get("category") or None
        job_id = _int_arg("job_id")
        minp, maxp = _int_arg("min_players"), _int_arg("max_players")
        status = request.args.get("status") or "ok"
        sort = GAME_SORTS.get(request.args.get("sort") or "playing", "s.playing")
        direction = "ASC" if (request.args.get("dir") or "desc").lower() == "asc" else "DESC"
        page = max(1, _int_arg("page", 1))
        size = max(1, min(500, _int_arg("page_size", settings.get("UI_PAGE_SIZE", 50))))
        where, params = [], []
        if status != "all":
            where.append("g.status=?")
            params.append(status)
        if q:
            where.append("(g.name LIKE ? OR g.creator_name LIKE ? OR CAST(g.universe_id AS TEXT)=? OR CAST(g.place_id AS TEXT)=?)")
            params += [f"%{q}%", f"%{q}%", q, q]
        if category:
            where.append("EXISTS (SELECT 1 FROM game_categories c WHERE c.universe_id=g.universe_id AND c.category=?)")
            params.append(category)
        if job_id:
            where.append("EXISTS (SELECT 1 FROM job_games jg WHERE jg.universe_id=g.universe_id AND jg.job_id=?)")
            params.append(job_id)
        if minp is not None:
            where.append("s.playing >= ?")
            params.append(minp)
        if maxp is not None:
            where.append("s.playing <= ?")
            params.append(maxp)
        wsql = ("WHERE " + " AND ".join(where)) if where else ""
        base = f"FROM games g {LATEST_JOIN} {wsql}"
        total = db.one(f"SELECT COUNT(*) n {base}", params)["n"]
        rows = db.rows(
            f"SELECT g.universe_id, g.place_id, g.name, g.creator_name, g.icon_url, g.url, g.updated, g.created, g.genre_l1, "
            f"g.status, g.last_fetched, s.playing, s.visits, s.favorites, s.up_votes, s.down_votes, s.like_ratio, s.captured_at, "
            f"(SELECT GROUP_CONCAT(DISTINCT category) FROM game_categories c WHERE c.universe_id=g.universe_id) categories, "
            f"(SELECT COUNT(*) FROM game_mechanics gm WHERE gm.universe_id=g.universe_id AND gm.method='rules') analyzed "
            f"{base} ORDER BY {sort} IS NULL, {sort} {direction}, g.universe_id LIMIT ? OFFSET ?",
            params + [size, (page - 1) * size])
        return jsonify({"total": total, "page": page, "page_size": size, "rows": rows})

    @app.get("/api/categories")
    def categories():
        return jsonify(db.rows("SELECT category, GROUP_CONCAT(DISTINCT source) sources, COUNT(DISTINCT universe_id) n "
                               "FROM game_categories GROUP BY category ORDER BY n DESC"))

    @app.get("/api/games/<int:uid>")
    def game_detail(uid):
        g = db.one("SELECT * FROM games WHERE universe_id=?", (uid,))
        if not g:
            return jsonify({"error": "Juego no encontrado en la base de datos"}), 404
        g["field_sources"] = db.jload(g.get("field_sources"), {})
        g["extra"] = db.jload(g.get("extra"), {})
        snaps = db.rows("SELECT * FROM game_snapshots WHERE universe_id=? ORDER BY captured_at", (uid,))
        cats = db.rows("SELECT category, source FROM game_categories WHERE universe_id=?", (uid,))
        items = db.rows("SELECT kind, item_id, name, description, price, extra FROM game_items WHERE universe_id=? ORDER BY kind, price", (uid,))
        for it in items:
            it["extra"] = db.jload(it["extra"], {})
        mech_rows = db.rows("SELECT mechanic_key, status, score, evidence, method, analyzed_at FROM game_mechanics WHERE universe_id=?", (uid,))
        mech = {}
        for r in mech_rows:
            mech.setdefault(r["method"], {})[r["mechanic_key"]] = {
                "status": r["status"], "score": r["score"], "evidence": db.jload(r["evidence"], []), "analyzed_at": r["analyzed_at"]}
        summary = db.one("SELECT content, model, created_at FROM analysis_results WHERE universe_id=? AND kind='rules_summary' "
                         "ORDER BY id DESC LIMIT 1", (uid,))
        ai = db.one("SELECT content, model, created_at FROM analysis_results WHERE universe_id=? AND kind='ai' ORDER BY id DESC LIMIT 1", (uid,))
        notes = db.rows("SELECT id, source, text, created_at FROM manual_notes WHERE universe_id=? ORDER BY id DESC", (uid,))
        for x in (summary, ai):
            if x:
                x["content"] = db.jload(x["content"], {})
        return jsonify({"game": g, "snapshots": snaps, "categories": cats, "items": items, "mechanics": mech,
                        "summary": summary, "ai": ai, "notes": notes, "ai_status": ai_status()})

    @app.post("/api/games/<int:uid>/notes")
    def add_note(uid):
        data = request.get_json(force=True, silent=True) or {}
        text = (data.get("text") or "").strip()
        if not text:
            return jsonify({"error": "El texto está vacío"}), 400
        if not db.one("SELECT 1 x FROM games WHERE universe_id=?", (uid,)):
            return jsonify({"error": "Juego no encontrado"}), 404
        db.execute("INSERT INTO manual_notes (universe_id, source, text, created_at) VALUES (?,?,?,?)",
                   (uid, (data.get("source") or "notas")[:60], text[:50000], db.now_iso()))
        mechanics.analyze_game(uid)
        return jsonify({"ok": True})

    @app.delete("/api/notes/<int:nid>")
    def delete_note(nid):
        n = db.one("SELECT universe_id FROM manual_notes WHERE id=?", (nid,))
        if not n:
            return jsonify({"error": "Nota no encontrada"}), 404
        db.execute("DELETE FROM manual_notes WHERE id=?", (nid,))
        mechanics.analyze_game(n["universe_id"])
        return jsonify({"ok": True})

    @app.post("/api/games/<int:uid>/analyze")
    def analyze_one(uid):
        res = mechanics.analyze_game(uid)
        if not res:
            return jsonify({"error": "Juego no encontrado"}), 404
        return jsonify({"ok": True})

    @app.post("/api/games/<int:uid>/ai")
    def ai_one(uid):
        try:
            return jsonify({"ok": True, "result": analyze_with_ai(uid)})
        except AIError as e:
            return jsonify({"error": str(e)}), 400

    @app.post("/api/games/<int:uid>/refresh")
    def refresh_one(uid):
        jid = manager.submit("refresh", {"universe_ids": [uid], "extras": True})
        return jsonify({"job_id": jid})

    # ------------------------------------------------------------ jobs
    @app.post("/api/jobs")
    def create_job():
        data = request.get_json(force=True, silent=True) or {}
        jtype = data.get("type") or "discover"
        params = data.get("params") or {}
        if jtype in ("discover", "batch"):
            mode = params.get("mode") or "category"
            if mode == "category" and not params.get("category"):
                return jsonify({"error": "Selecciona una categoría"}), 400
            if mode == "keyword" and not (params.get("keyword") or "").strip():
                return jsonify({"error": "Escribe una palabra clave"}), 400
            if mode == "ids" and not (params.get("ids_text") or "").strip():
                return jsonify({"error": "Introduce al menos un ID"}), 400
            if mode == "urls" and not (params.get("urls_text") or "").strip():
                return jsonify({"error": "Introduce al menos una URL"}), 400
            if mode == "related" and not ((params.get("ids_text") or "").strip() or (params.get("urls_text") or "").strip()
                                          or params.get("seed_ids")):
                return jsonify({"error": "Indica al menos un juego semilla (ID o URL)"}), 400
        try:
            jid = manager.submit(jtype, params)
        except ValueError as e:
            return jsonify({"error": str(e)}), 400
        return jsonify({"job_id": jid})

    @app.get("/api/jobs")
    def list_jobs():
        rows = db.rows("SELECT id, type, params, status, progress, total, message, created_at, started_at, finished_at "
                       "FROM jobs ORDER BY id DESC LIMIT ?", (_int_arg("limit", 50),))
        for r in rows:
            r["params"] = db.jload(r["params"], {})
            r["n_games"] = db.one("SELECT COUNT(*) n FROM job_games WHERE job_id=?", (r["id"],))["n"]
        return jsonify(rows)

    @app.get("/api/jobs/<int:jid>")
    def get_job(jid):
        r = db.one("SELECT * FROM jobs WHERE id=?", (jid,))
        if not r:
            return jsonify({"error": "Trabajo no encontrado"}), 404
        r["params"] = db.jload(r["params"], {})
        r["result"] = db.jload(r["result"], {})
        r["n_games"] = db.one("SELECT COUNT(*) n FROM job_games WHERE job_id=?", (jid,))["n"]
        return jsonify(r)

    @app.post("/api/jobs/<int:jid>/cancel")
    def cancel_job(jid):
        return jsonify({"ok": manager.cancel(jid)})

    # ------------------------------------------------------------ analysis
    @app.get("/api/patterns")
    def get_patterns():
        return jsonify(patterns.full_patterns(job_id=_int_arg("job_id"), category=request.args.get("category") or None,
                                              include_probable=request.args.get("include_probable") in ("1", "true")))

    @app.get("/api/mechanics")
    def mech_overview():
        ids = patterns.select_games(_int_arg("job_id"), request.args.get("category") or None)
        st = patterns.mechanic_stats(ids, request.args.get("include_probable") in ("1", "true"))
        st.pop("by_game", None)
        return jsonify(st)

    @app.get("/api/mechanics/<key>/games")
    def mech_games(key):
        if key not in mechanics.TAX_BY_KEY:
            return jsonify({"error": "Mecánica desconocida"}), 404
        statuses = (request.args.get("status") or "detectada,probable").split(",")
        rows = db.rows(
            f"SELECT g.universe_id, g.name, g.icon_url, gm.status, gm.score, gm.evidence, s.playing FROM game_mechanics gm "
            f"JOIN games g ON g.universe_id=gm.universe_id {LATEST_JOIN} "
            f"WHERE gm.method='rules' AND gm.mechanic_key=? AND g.status='ok' AND gm.status IN ({','.join('?' * len(statuses))}) "
            f"ORDER BY s.playing DESC LIMIT 300", [key] + statuses)
        for r in rows:
            ev = db.jload(r.pop("evidence"), [])
            r["evidence"] = ev[:2]
        return jsonify({"mechanic": mechanics.TAX_BY_KEY[key]["label"], "rows": rows})

    @app.get("/api/compare")
    def compare():
        ids = [int(x) for x in (request.args.get("ids") or "").split(",") if x.strip().isdigit()][:10]
        out = []
        for uid in ids:
            g = db.one(f"SELECT g.*, s.playing, s.visits, s.favorites, s.up_votes, s.down_votes, s.like_ratio, s.server_count, "
                       f"s.captured_at FROM games g {LATEST_JOIN} WHERE g.universe_id=?", (uid,))
            if not g:
                continue
            g.pop("description", None)
            g["extra"] = db.jload(g.get("extra"), {})
            g["field_sources"] = db.jload(g.get("field_sources"), {})
            g["mechanics"] = {r["mechanic_key"]: r["status"] for r in db.rows(
                "SELECT mechanic_key, status FROM game_mechanics WHERE universe_id=? AND method='rules'", (uid,))}
            g["categories"] = [r["category"] for r in db.rows("SELECT DISTINCT category FROM game_categories WHERE universe_id=?", (uid,))]
            pr = db.one("SELECT MIN(price) mn, MAX(price) mx, COUNT(*) n FROM game_items WHERE universe_id=? AND kind='gamepass'", (uid,))
            g["gamepass_prices"] = pr
            out.append(g)
        return jsonify(out)

    @app.get("/api/history")
    def history():
        days = _int_arg("limit", 50)
        rows = db.rows("""
            WITH ranked AS (
              SELECT s.*, ROW_NUMBER() OVER (PARTITION BY universe_id ORDER BY captured_at DESC) rn
              FROM game_snapshots s)
            SELECT g.universe_id, g.name, a.captured_at last_at, b.captured_at prev_at,
                   a.playing last_playing, b.playing prev_playing, a.visits last_visits, b.visits prev_visits,
                   a.favorites last_fav, b.favorites prev_fav, a.like_ratio last_ratio, b.like_ratio prev_ratio,
                   (SELECT COUNT(*) FROM game_snapshots x WHERE x.universe_id=g.universe_id) n_snapshots
            FROM games g JOIN ranked a ON a.universe_id=g.universe_id AND a.rn=1
            JOIN ranked b ON b.universe_id=g.universe_id AND b.rn=2
            WHERE g.status='ok'""")
        for r in rows:
            r["delta_playing"] = (r["last_playing"] - r["prev_playing"]) if None not in (r["last_playing"], r["prev_playing"]) else None
            r["delta_visits"] = (r["last_visits"] - r["prev_visits"]) if None not in (r["last_visits"], r["prev_visits"]) else None
            r["delta_playing_pct"] = round(100 * r["delta_playing"] / r["prev_playing"], 1) if r["delta_playing"] is not None and r["prev_playing"] else None
        rows.sort(key=lambda r: -(abs(r["delta_playing"] or 0)))
        totals = db.one("SELECT COUNT(*) n, COUNT(DISTINCT universe_id) g, MIN(captured_at) first, MAX(captured_at) last FROM game_snapshots")
        by_day = db.rows("SELECT substr(captured_at,1,10) day, COUNT(*) n, SUM(playing) playing FROM game_snapshots GROUP BY day ORDER BY day DESC LIMIT 60")
        return jsonify({"changes": rows[:days], "totals": totals, "by_day": by_day})

    @app.get("/api/errors")
    def errors():
        return jsonify(db.rows("SELECT * FROM error_log ORDER BY id DESC LIMIT ?", (_int_arg("limit", 100),)))

    # ------------------------------------------------------------ export
    @app.get("/api/export/<fmt>")
    def export(fmt):
        if fmt not in ("csv", "json", "xlsx", "html"):
            return jsonify({"error": "Formato no soportado"}), 400
        data, mime, fname = exporter.export(fmt, job_id=_int_arg("job_id"), category=request.args.get("category") or None,
                                            include_probable=request.args.get("include_probable") in ("1", "true"),
                                            what=request.args.get("what") or "games")
        disp = "inline" if (fmt == "html" and request.args.get("view")) else "attachment"
        return Response(data, content_type=mime, headers={"Content-Disposition": f'{disp}; filename="{fname}"'})

    # ------------------------------------------------------------ settings
    @app.get("/api/settings")
    def get_settings():
        return jsonify({"settings": settings.public_dict(), "ai": ai_status()})

    @app.post("/api/settings")
    def post_settings():
        data = request.get_json(force=True, silent=True) or {}
        old_db = str(settings.db_path)
        new = settings.update(data)
        if str(settings.db_path) != old_db:
            db.init_db()
            mechanics.seed_mechanics()
        return jsonify({"settings": new, "ai": ai_status(),
                        "note": "Guardado. Si cambiaste la ubicación de la base de datos, se usará a partir de ahora."})

    @app.post("/api/cache/clear")
    def clear_cache():
        db.execute("DELETE FROM http_cache")
        return jsonify({"ok": True})

    @app.get("/api/health")
    def health():
        return jsonify({"ok": True, "db": str(settings.db_path)})

    return app
