"""Detección de mecánicas a partir de información PÚBLICA.

Método "rules" (sin IA): busca palabras clave (inglés y español) en
  - descripción del juego
  - nombres/descripciones de gamepasses públicos
  - nombres/descripciones de insignias (badges) públicas
  - notas/textos introducidos manualmente por el usuario (changelogs, wikis...)
y usa datos estructurados de la API cuando existen (p. ej. número de gamepasses).

Estados posibles (NO son hechos sobre el juego, sino sobre lo que dicen las fuentes públicas):
  detectada     -> mención explícita fuerte o dato estructurado de la API
  probable      -> alguna mención débil / indirecta
  no_detectada  -> hay texto suficiente pero no aparece ninguna señal
  insuficiente  -> no hay información pública suficiente para decidir
"""
from __future__ import annotations

import logging
import re

from . import db

log = logging.getLogger(__name__)

STATUS_LABELS = {
    "detectada": "Detectada",
    "probable": "Probable",
    "no_detectada": "No detectada",
    "insuficiente": "No hay información suficiente",
}

GROUP_LABELS = {
    "core_loop": "Core loop",
    "progression": "Progresión",
    "rewards": "Recompensas",
    "retention": "Retención",
    "social": "Social",
    "gameplay": "Gameplay",
    "monetization": "Monetización",
}

# Cada keyword: (regex, peso). Peso 2 = señal fuerte, 1 = señal débil.
# Las regex se evalúan con límites de palabra y sin distinguir mayúsculas.
def K(*items):
    out = []
    for it in items:
        if isinstance(it, tuple):
            out.append(it)
        else:
            out.append((it, 1))
    return out


TAXONOMY: list[dict] = [
    # ---------------- CORE LOOP
    {"key": "core_explore", "group": "core_loop", "label": "Explorar",
     "kw": K(("explor\\w*", 2), "discover\\w*", "secrets?", "hidden", "islands?", "adventure", "descubr\\w*", "secretos?", "sail\\w*", "naveg\\w*")},
    {"key": "core_combat", "group": "core_loop", "label": "Combatir",
     "kw": K(("fight\\w*", 2), ("combat", 2), ("battle(?!\\s?pass)\\w*", 2), "boss(es)?", "enem(y|ies)", "defeat", "kill\\w*",
             ("pelea\\w*", 2), ("combat[ei]\\w*", 2), "jefes?", "enemigos?", ("batallas?", 2), ("luchar?", 2))},
    {"key": "core_collect", "group": "core_loop", "label": "Recolectar",
     "kw": K(("collect\\w*", 2), "gather\\w*", "farm(ing)?", "harvest\\w*", "mine|mining", "catch\\w*", "loot",
             ("recolect\\w*", 2), ("colecciona\\w*", 2), "recoge\\w*")},
    {"key": "core_build", "group": "core_loop", "label": "Construir",
     "kw": K(("build(ing)?", 2), "construct\\w*", ("craft\\w*", 2), "place blocks", ("constru\\w*", 2), "fabrica\\w*")},
    {"key": "core_upgrade", "group": "core_loop", "label": "Mejorar",
     "kw": K(("upgrade\\w*", 2), "improve\\w*", "enhance\\w*", "evolv\\w*", "train(ing)?", "rebirth\\w*", ("mejora\\w*", 2), "entrena\\w*")},
    {"key": "core_quests", "group": "core_loop", "label": "Completar misiones",
     "kw": K(("quests?", 2), ("missions?", 2), "tasks?", "objectives?", ("misi[oó]n(es)?", 2), "tareas?")},
    {"key": "core_survive", "group": "core_loop", "label": "Sobrevivir",
     "kw": K(("surviv\\w*", 2), "hunger", "stay alive", "last until", ("sobreviv\\w*", 2))},
    {"key": "core_compete", "group": "core_loop", "label": "Competir",
     "kw": K(("compet\\w*", 2), ("leaderboards?", 2), "ranked", "tournaments?", "top players", "race against", ("clasificaci[oó]n", 1), "torneos?")},
    {"key": "core_escape", "group": "core_loop", "label": "Escapar / huir",
     "kw": K(("escape", 2), "run away", "get out", ("escapa\\w*", 2), "huir")},
    {"key": "core_earn", "group": "core_loop", "label": "Generar ingresos (tycoon/idle)",
     "kw": K(("tycoon", 2), "earn (cash|money|coins)", "income", "idle", "profit", "ganar dinero")},
    {"key": "core_roleplay", "group": "core_loop", "label": "Roleplay",
     "kw": K(("role ?play\\w*", 2), ("\\brp\\b", 1), "jobs?", "live your life", ("juego de rol", 2))},

    # ---------------- PROGRESIÓN
    {"key": "prog_levels", "group": "progression", "label": "Niveles",
     "kw": K(("level ?up", 2), ("levels?", 1), ("max level", 2), "lvl", ("nivel(es)?", 1), ("level cap", 2), ("l[ií]mite de nivel", 2), ("subir de nivel", 2))},
    {"key": "prog_xp", "group": "progression", "label": "Experiencia (XP)",
     "kw": K(("xp", 2), ("exp\\b", 1), ("experience points?", 2), ("experiencia", 1))},
    {"key": "prog_skills", "group": "progression", "label": "Habilidades",
     "kw": K(("skills?", 2), ("abilit(y|ies)", 2), "talents?", "powers?", "moves?", "skill tree", ("habilidad(es)?", 2), "poder(es)?")},
    {"key": "prog_unlocks", "group": "progression", "label": "Desbloqueos",
     "kw": K(("unlock\\w*", 2), ("desbloque\\w*", 2))},
    {"key": "prog_weapons", "group": "progression", "label": "Armas",
     "kw": K(("weapons?", 2), "swords?", "guns?", "blades?", "bows?", "katanas?", ("armas?", 2), "espadas?")},
    {"key": "prog_characters", "group": "progression", "label": "Personajes / clases",
     "kw": K(("characters?", 2), ("class(es)?", 1), "heroes|hero", ("units?", 1), "morphs?", ("personajes?", 2))},
    {"key": "prog_zones", "group": "progression", "label": "Zonas / mundos",
     "kw": K(("zones?", 2), ("worlds?", 1), ("areas?", 1), "realms?", "seas?", "floors?", "stages?", "chapters?",
             ("zonas?", 2), "mundos?", "cap[ií]tulos?")},
    {"key": "prog_upgrades", "group": "progression", "label": "Mejoras permanentes",
     "kw": K(("upgrades?", 2), ("rebirths?", 2), ("prestige", 2), "ascen\\w*", ("mejoras?", 2), "renac\\w*")},

    # ---------------- RECOMPENSAS
    {"key": "rew_currency", "group": "rewards", "label": "Monedas",
     "kw": K(("coins?", 2), ("cash", 1), ("money", 1), ("gold", 1), ("currency", 2), "tokens?", ("monedas?", 2), "dinero")},
    {"key": "rew_chests", "group": "rewards", "label": "Cofres / cajas",
     "kw": K(("chests?", 2), ("crates?", 2), "cases?", ("eggs?", 1), "loot ?box\\w*", ("cofres?", 2), "cajas?", "huevos?")},
    {"key": "rew_drops", "group": "rewards", "label": "Drops",
     "kw": K(("drops?", 2), ("loot", 1), "drop rate", ("bot[ií]n", 1))},
    {"key": "rew_daily", "group": "rewards", "label": "Recompensas diarias",
     "kw": K(("daily rewards?", 2), ("daily login", 2), ("daily gifts?", 2), ("daily spin", 2), ("recompensas? diarias?", 2), "daily")},
    {"key": "rew_achievements", "group": "rewards", "label": "Logros",
     "kw": K(("achievements?", 2), ("logros?", 2))},
    {"key": "rew_quest", "group": "rewards", "label": "Recompensas por misión",
     "kw": K(("quest rewards?", 2), ("mission rewards?", 2), ("complete (quests|missions|tasks) (to|for)", 2), ("recompensas? por misi[oó]n", 2))},
    {"key": "rew_playtime", "group": "rewards", "label": "Recompensas por tiempo jugado",
     "kw": K(("playtime rewards?", 2), ("time rewards?", 2), ("free gifts?", 2), ("online rewards?", 2), ("gifts? every", 2), ("tiempo jugado", 2))},
    {"key": "rew_codes", "group": "rewards", "label": "Códigos promocionales",
     "kw": K(("codes?", 1), ("redeem", 2), ("c[oó]digos?", 1), ("canjea\\w*", 2))},

    # ---------------- RETENCIÓN
    {"key": "ret_daily_quests", "group": "retention", "label": "Misiones diarias",
     "kw": K(("daily (quests?|missions?|challenges?|tasks?)", 2), ("weekly (quests?|missions?|challenges?)", 2), ("misiones diarias", 2), ("desaf[ií]os diarios", 2))},
    {"key": "ret_streaks", "group": "retention", "label": "Rachas",
     "kw": K(("streaks?", 2), ("login streak", 2), ("rachas?", 2))},
    {"key": "ret_periodic", "group": "retention", "label": "Recompensas periódicas",
     "kw": K(("every \\d+ (minutes|hours|min)", 2), ("weekly rewards?", 2), ("hourly", 2), ("spin the wheel|daily spin|free spins?", 2), ("cada \\d+ (minutos|horas)", 2))},
    {"key": "ret_events", "group": "retention", "label": "Eventos",
     "kw": K(("events?", 2), ("limited[- ]time", 2), ("seasonal", 2), "halloween", "christmas", "easter", "summer", ("eventos?", 2), ("tiempo limitado", 2))},
    {"key": "ret_progression", "group": "retention", "label": "Progresión (derivada)", "derived": "progression", "kw": []},
    {"key": "ret_collectibles", "group": "retention", "label": "Coleccionables",
     "kw": K(("collectibles?", 2), ("collect them all|collect all", 2), ("index", 1), ("pets?", 2), ("cards?", 1), ("legendary", 1),
             ("mythic(al)?", 1), ("secret", 1), ("rare", 1), ("coleccionables?", 2), ("mascotas?", 2), ("legendari[oa]s?", 1))},
    {"key": "ret_unlocks", "group": "retention", "label": "Desbloqueos (derivado)", "derived": "prog_unlocks", "kw": []},
    {"key": "ret_season_pass", "group": "retention", "label": "Pase de temporada",
     "kw": K(("battle ?pass", 2), ("season ?pass", 2), ("seasons?", 1), ("pase de (batalla|temporada)", 2))},
    {"key": "ret_updates", "group": "retention", "label": "Actualizaciones frecuentes",
     "kw": K(("updates?", 1), ("new update", 2), ("weekly updates?", 2), ("update log|changelog|patch notes", 2), ("actualizaci[oó]n(es)?", 1))},

    # ---------------- SOCIAL
    {"key": "soc_coop", "group": "social", "label": "Cooperación",
     "kw": K(("co-?op", 2), ("with (your )?friends", 2), ("team up", 2), ("together", 1), ("cooperat\\w*", 2), ("con (tus )?amigos", 2), ("coopera\\w*", 2))},
    {"key": "soc_teams", "group": "social", "label": "Equipos",
     "kw": K(("teams?", 2), ("squads?", 2), ("party", 1), ("equipos?", 2))},
    {"key": "soc_pvp", "group": "social", "label": "PvP",
     "kw": K(("pvp", 2), ("player vs\\.? player", 2), ("duels?", 2), ("arena", 1), ("fight other players", 2), ("battlegrounds?", 2), ("jugador contra jugador", 2))},
    {"key": "soc_trading", "group": "social", "label": "Comercio (trading)",
     "kw": K(("trad(e|es|ing)", 2), ("comerci\\w*", 2), ("intercambi\\w*", 2))},
    {"key": "soc_chat", "group": "social", "label": "Chat / voz",
     "kw": K(("chat", 1), ("voice chat", 2), ("chat de voz", 2))},
    {"key": "soc_clans", "group": "social", "label": "Clanes / grupos",
     "kw": K(("clans?", 2), ("guilds?", 2), ("crews?", 2), ("factions?", 2), ("join (the|our) group", 1), ("clan(es)?", 2), ("gremios?", 2))},
    {"key": "soc_matchmaking", "group": "social", "label": "Matchmaking",
     "kw": K(("matchmaking", 2), ("queue", 1), ("lobby", 1), ("ranked", 2), ("matches?", 1), ("partidas?", 1))},

    # ---------------- GAMEPLAY
    {"key": "gp_combat", "group": "gameplay", "label": "Combate",
     "kw": K(("combat", 2), ("fight\\w*", 2), ("shoot\\w*", 2), ("sword", 1), ("guns?", 1), ("pelea\\w*", 2), ("dispar\\w*", 2))},
    {"key": "gp_exploration", "group": "gameplay", "label": "Exploración",
     "kw": K(("explor\\w*", 2), ("open world", 2), ("mundo abierto", 2), ("adventure", 1))},
    {"key": "gp_puzzles", "group": "gameplay", "label": "Puzzles",
     "kw": K(("puzzles?", 2), ("riddles?", 2), ("solve", 2), ("rompecabezas", 2), ("acertijos?", 2), ("resolver", 1))},
    {"key": "gp_parkour", "group": "gameplay", "label": "Parkour / plataformas",
     "kw": K(("parkour", 2), ("obby", 2), ("obstacles?", 2), ("jump\\w*", 1), ("platform\\w*", 1), ("obst[aá]culos?", 2), ("saltar", 1))},
    {"key": "gp_stealth", "group": "gameplay", "label": "Sigilo",
     "kw": K(("stealth", 2), ("hide", 1), ("sneak\\w*", 2), ("hiding", 1), ("don'?t make (a )?(sound|noise)", 2), ("sigilo", 2), ("esconde\\w*", 1))},
    {"key": "gp_survival", "group": "gameplay", "label": "Supervivencia",
     "kw": K(("surviv\\w*", 2), ("hunger", 2), ("thirst", 2), ("sobreviv\\w*", 2))},
    {"key": "gp_building", "group": "gameplay", "label": "Construcción",
     "kw": K(("build(ing)?", 2), ("sandbox", 2), ("craft\\w*", 1), ("constru\\w*", 2))},
    {"key": "gp_driving", "group": "gameplay", "label": "Conducción",
     "kw": K(("driv(e|ing)", 2), ("cars?", 1), ("vehicles?", 2), ("racing|races?", 2), ("boats?", 1), ("conduc\\w*", 2), ("veh[ií]culos?", 2))},
    {"key": "gp_simulation", "group": "gameplay", "label": "Simulación",
     "kw": K(("simulator", 2), ("simulation", 2), ("tycoon", 2), ("manage\\w*", 1), ("simulador", 2))},
    {"key": "gp_horror", "group": "gameplay", "label": "Terror / horror",
     "kw": K(("horror", 2), ("scary", 2), ("jump ?scares?", 2), ("monsters?", 1), ("terror", 2), ("miedo", 2))},

    # ---------------- MONETIZACIÓN
    {"key": "mon_gamepasses", "group": "monetization", "label": "Gamepasses", "structured": "gamepass_count", "kw": K(("game ?pass(es)?", 2))},
    {"key": "mon_products", "group": "monetization", "label": "Productos / tienda",
     "kw": K(("shop", 1), ("store", 1), ("purchase", 1), ("buy", 1), ("robux", 2), ("developer products?", 2), ("tienda", 1), ("comprar?", 1))},
    {"key": "mon_premium_currency", "group": "monetization", "label": "Moneda premium",
     "kw": K(("gems?", 2), ("diamonds?", 2), ("crystals?", 1), ("premium currency", 2), ("gemas?", 2), ("diamantes?", 2))},
    {"key": "mon_cosmetics", "group": "monetization", "label": "Cosméticos",
     "kw": K(("skins?", 2), ("trails?", 2), ("auras?", 2), ("emotes?", 2), ("cosmetics?", 2), ("titles?", 1), ("chat tags?", 2), ("cosm[eé]ticos?", 2))},
    {"key": "mon_boosts", "group": "monetization", "label": "Boosts",
     "kw": K(("2x|x2|3x|x3", 2), ("double", 2), ("boosts?", 2), ("luck", 1), ("multiplier", 2), ("doble", 2), ("potenciador\\w*", 2))},
    {"key": "mon_advantages", "group": "monetization", "label": "Ventajas (pay-for-advantage)",
     "kw": K(("vip", 2), ("extra (slots?|storage|inventory|health|damage)", 2), ("faster", 1), ("speed", 1), ("auto[- ]?\\w+", 1),
             ("instant", 1), ("skip", 1), ("more (storage|space|slots)", 2), ("ventaja\\w*", 2))},
    {"key": "mon_private_servers", "group": "monetization", "label": "Servidores privados", "structured": "private_servers",
     "kw": K(("private servers?", 2), ("vip servers?", 2), ("servidor(es)? privados?", 2))},
    {"key": "mon_paid_access", "group": "monetization", "label": "Acceso de pago", "structured": "paid_access", "kw": []},
]

TAX_BY_KEY = {m["key"]: m for m in TAXONOMY}
_COMPILED: dict[str, list[tuple[re.Pattern, int, str]]] = {}


def _compile():
    if _COMPILED:
        return
    for m in TAXONOMY:
        pats = []
        for rx, w in m.get("kw", []):
            try:
                pats.append((re.compile(r"(?<![\w])(?:" + rx + r")(?![\w])", re.I | re.U), w, rx))
            except re.error as e:
                log.error("Regex inválida en %s: %s (%s)", m["key"], rx, e)
        _COMPILED[m["key"]] = pats


def seed_mechanics():
    with db.get_conn() as conn:
        for m in TAXONOMY:
            conn.execute(
                "INSERT INTO mechanics (key, group_name, label, keywords) VALUES (?,?,?,?) "
                "ON CONFLICT(key) DO UPDATE SET group_name=excluded.group_name, label=excluded.label, keywords=excluded.keywords",
                (m["key"], m["group"], m["label"], db.jdump([k for k, _ in m.get("kw", [])])))


MIN_TEXT_CHARS = 60  # por debajo de esto no hay texto suficiente para inferir


def gather_texts(universe_id: int) -> tuple[dict, list[dict]]:
    """Devuelve (game_row, lista de textos con su fuente)."""
    g = db.one("SELECT * FROM games WHERE universe_id=?", (universe_id,))
    if not g:
        return {}, []
    texts = []
    if g.get("name"):
        texts.append({"source": "nombre", "text": g["name"], "weight": 1.0})
    if g.get("description"):
        texts.append({"source": "descripción", "text": g["description"], "weight": 1.0})
    for it in db.rows("SELECT kind, name, description FROM game_items WHERE universe_id=?", (universe_id,)):
        t = f"{it['name'] or ''}. {it['description'] or ''}".strip()
        if t:
            texts.append({"source": "gamepass" if it["kind"] == "gamepass" else "insignia", "text": t, "weight": 1.0})
    for n in db.rows("SELECT source, text FROM manual_notes WHERE universe_id=?", (universe_id,)):
        texts.append({"source": f"manual:{n['source'] or 'nota'}", "text": n["text"], "weight": 1.0})
    return g, texts


def _snippet(text: str, start: int, end: int, pad=45) -> str:
    a, b = max(0, start - pad), min(len(text), end + pad)
    return ("…" if a > 0 else "") + text[a:b].replace("\n", " ") + ("…" if b < len(text) else "")


def analyze_game(universe_id: int) -> dict:
    """Clasifica todas las mecánicas del juego y guarda el resultado (método 'rules')."""
    _compile()
    g, texts = gather_texts(universe_id)
    if not g:
        return {}
    extra = db.jload(g.get("extra"), {}) or {}
    extras_status = extra.get("extras_status", {})
    total_chars = sum(len(t["text"]) for t in texts if t["source"] != "nombre")
    has_items = any(t["source"] in ("gamepass", "insignia") for t in texts)
    enough_text = total_chars >= MIN_TEXT_CHARS or has_items

    results: dict[str, dict] = {}
    for m in TAXONOMY:
        if m.get("derived"):
            continue
        score, evidence, matched, strong = 0.0, [], set(), False
        for t in texts:
            for pat, w, rx in _COMPILED[m["key"]]:
                mt = pat.search(t["text"])
                if not mt:
                    continue
                bonus = 1.5 if (m["group"] == "monetization" and t["source"] == "gamepass") else 1.0
                if w >= 2:
                    strong = True
                if rx not in matched:
                    score += w * bonus
                    matched.add(rx)
                else:
                    score += 0.5  # misma palabra en otra fuente
                if len(evidence) < 6:
                    evidence.append({"source": t["source"], "match": mt.group(0),
                                     "snippet": _snippet(t["text"], mt.start(), mt.end())})
        status = None
        # Datos estructurados (hechos de la API)
        st = m.get("structured")
        if st == "gamepass_count":
            if g.get("gamepass_count") is not None:
                if g["gamepass_count"] > 0:
                    status = "detectada"
                    evidence.insert(0, {"source": "API gamepasses", "match": f"{g['gamepass_count']} gamepasses públicos",
                                        "snippet": "Dato estructurado de apis.roblox.com/game-passes"})
                    score = max(score, 5)
                elif score == 0:
                    status = "no_detectada"
            elif score == 0:
                status = "insuficiente"
        elif st == "private_servers":
            if extra.get("createVipServersAllowed") is True:
                status = "detectada"
                evidence.insert(0, {"source": "API games", "match": "createVipServersAllowed = true",
                                    "snippet": "El juego permite crear servidores privados (de pago o gratuitos)"})
                score = max(score, 5)
            elif extra.get("createVipServersAllowed") is False and score == 0:
                status = "no_detectada"
        elif st == "paid_access":
            if g.get("price"):
                status = "detectada"
                evidence.append({"source": "API games", "match": f"price = {g['price']} Robux", "snippet": "Acceso de pago"})
                score = 5
            else:
                status = "no_detectada"  # price null = acceso gratuito según la API
        if m["key"] == "rew_achievements" and g.get("badge_count"):
            status = "detectada"
            evidence.insert(0, {"source": "API badges", "match": f"{g['badge_count']} insignias públicas",
                                "snippet": "Las insignias de Roblox funcionan como logros"})
            score = max(score, 5)

        if status is None:
            if score >= 3 or strong:
                status = "detectada"
            elif score >= 1:
                status = "probable"
            elif not enough_text:
                status = "insuficiente"
            else:
                status = "no_detectada"
        # Monetización: si no se pudieron leer los gamepasses y no hay texto, no afirmar "no detectada"
        if m["group"] == "monetization" and status == "no_detectada" and st is None:
            if not str(extras_status.get("gamepasses", "ok")).startswith("ok") and total_chars < MIN_TEXT_CHARS:
                status = "insuficiente"
        results[m["key"]] = {"status": status, "score": round(score, 2), "evidence": evidence}

    # Derivadas
    rank = {"detectada": 3, "probable": 2, "no_detectada": 1, "insuficiente": 0}
    for m in TAXONOMY:
        if not m.get("derived"):
            continue
        src = m["derived"]
        if src in TAX_BY_KEY:
            base = results.get(src, {"status": "insuficiente", "score": 0, "evidence": []})
            results[m["key"]] = {"status": base["status"], "score": base["score"],
                                 "evidence": [{"source": "derivado", "match": TAX_BY_KEY[src]["label"],
                                               "snippet": f"Derivado de la mecánica '{TAX_BY_KEY[src]['label']}'"}]}
        else:  # grupo
            members = [results[x["key"]] for x in TAXONOMY if x["group"] == src and x["key"] in results]
            best = max(members, key=lambda r: (rank[r["status"]], r["score"])) if members else None
            status = best["status"] if best else "insuficiente"
            names = [x["label"] for x in TAXONOMY if x["group"] == src and results.get(x["key"], {}).get("status") in ("detectada", "probable")]
            results[m["key"]] = {"status": status, "score": best["score"] if best else 0,
                                 "evidence": [{"source": "derivado", "match": ", ".join(names[:6]) or "-",
                                               "snippet": "Derivado del grupo Progresión"}]}

    now = db.now_iso()
    with db.get_conn() as conn:
        conn.execute("DELETE FROM game_mechanics WHERE universe_id=? AND method='rules'", (universe_id,))
        for k, r in results.items():
            conn.execute("INSERT INTO game_mechanics VALUES (?,?,?,?,?,?,?)",
                         (universe_id, k, r["status"], r["score"], db.jdump(r["evidence"]), "rules", now))
    summary = build_rules_summary(g, results, has_text=enough_text)
    with db.get_conn() as conn:
        conn.execute("DELETE FROM analysis_results WHERE universe_id=? AND kind='rules_summary'", (universe_id,))
        conn.execute("INSERT INTO analysis_results (universe_id, kind, content, model, created_at) VALUES (?,?,?,?,?)",
                     (universe_id, "rules_summary", db.jdump(summary), "reglas/palabras clave v1", now))
    return results


def _names(results, group, statuses=("detectada",)):
    return [TAX_BY_KEY[k]["label"] for k, r in sorted(results.items(), key=lambda kv: -kv[1]["score"])
            if TAX_BY_KEY[k]["group"] == group and r["status"] in statuses and not TAX_BY_KEY[k].get("derived")]


def build_rules_summary(g: dict, results: dict, has_text: bool) -> dict:
    """Resumen en 9 apartados SIN IA. Todo expresado como observación o inferencia."""
    det = lambda grp: _names(results, grp, ("detectada",))
    prob = lambda grp: _names(results, grp, ("probable",))

    def fmt(grp):
        d, p = det(grp), prob(grp)
        if not d and not p:
            return "No se detectaron señales en las fuentes públicas disponibles." if has_text else \
                "No hay información pública suficiente."
        parts = []
        if d:
            parts.append("Detectado en fuentes públicas: " + ", ".join(d))
        if p:
            parts.append("Probable (mención débil): " + ", ".join(p))
        return ". ".join(parts) + "."

    core = det("core_loop") + prob("core_loop")
    core_txt = ("Inferencia a partir de textos públicos: el ciclo principal podría girar en torno a "
                + " → ".join(core[:4]) + ".") if core else ("No hay información suficiente para inferir el core loop."
                                                          if not has_text else "No se identificó un core loop claro en los textos públicos.")
    all_det = [TAX_BY_KEY[k]["label"] for k, r in results.items() if r["status"] == "detectada" and not TAX_BY_KEY[k].get("derived")]

    mon = fmt("monetization")
    if g.get("gamepass_count") is not None:
        mon += f" Gamepasses públicos: {g['gamepass_count']}."
    prices = db.one("SELECT MIN(price) mn, MAX(price) mx, COUNT(*) n FROM game_items WHERE universe_id=? AND kind='gamepass' AND price IS NOT NULL",
                    (g["universe_id"],))
    if prices and prices["n"]:
        mon += f" Rango de precios visibles: {prices['mn']}–{prices['mx']} Robux."

    # Diferenciadoras: mecánicas detectadas en este juego que son poco comunes en la base de datos
    diff = []
    try:
        base = {r["mechanic_key"]: r for r in db.rows(
            "SELECT mechanic_key, SUM(status='detectada') d, SUM(status!='insuficiente') n "
            "FROM game_mechanics WHERE method='rules' GROUP BY mechanic_key")}
        for k, r in results.items():
            b = base.get(k)
            if r["status"] == "detectada" and b and b["n"] and b["n"] >= 10 and (b["d"] / b["n"]) < 0.2 \
                    and not TAX_BY_KEY[k].get("derived"):
                diff.append(f"{TAX_BY_KEY[k]['label']} (aparece en el {round(100 * b['d'] / b['n'])}% de los juegos analizados)")
    except Exception:  # noqa: BLE001
        pass

    engagement = []
    if det("retention") or prob("retention"):
        engagement.append("presenta elementos de retención (" + ", ".join((det("retention") + prob("retention"))[:4]) + ")")
    if det("progression"):
        engagement.append("muestra sistemas de progresión visibles")
    if det("social") or prob("social"):
        engagement.append("menciona componentes sociales")
    eng_txt = ("ANÁLISIS/INFERENCIA, no un hecho demostrado: el juego " + "; ".join(engagement) +
               ". Estos elementos aparecen con frecuencia en juegos con alta participación, pero esta observación "
               "no demuestra que sean la causa de su popularidad.") if engagement else \
        "No hay suficientes señales públicas para plantear hipótesis de engagement."

    return {
        "1_core_loop": core_txt,
        "2_mecanicas_detectadas": (", ".join(all_det) + ".") if all_det else "Ninguna mecánica con señal fuerte.",
        "3_progresion": fmt("progression"),
        "4_recompensas": fmt("rewards"),
        "5_retencion": fmt("retention"),
        "6_social": fmt("social"),
        "7_monetizacion_visible": mon,
        "8_diferenciadoras": ("Poco comunes en la muestra: " + "; ".join(diff) + ".") if diff else
        "No se identificaron mecánicas poco comunes respecto a la muestra (o la muestra es pequeña, <10 juegos).",
        "9_posibles_razones_engagement": eng_txt,
        "_metodo": "Reglas y palabras clave sobre descripción, gamepasses, insignias y notas manuales. "
                   "Las clasificaciones indican lo que dicen las fuentes públicas, no lo que ocurre dentro del juego.",
    }
