"""Configuración de la aplicación.

Orden de prioridad (de menor a mayor):
  1. Valores por defecto definidos aquí
  2. Variables del archivo .env
  3. data/settings.json (editado desde la página Configuración)

Las API keys NUNCA se guardan en settings.json: solo en .env.
"""
from __future__ import annotations

import json
import os
import threading
from pathlib import Path

from dotenv import load_dotenv, set_key

BASE_DIR = Path(__file__).resolve().parent.parent
ENV_PATH = BASE_DIR / ".env"
SETTINGS_PATH = Path(os.getenv("RGA_SETTINGS_PATH") or (BASE_DIR / "data" / "settings.json"))
STATIC_DIR = BASE_DIR / "static"
LOG_DIR = BASE_DIR / "logs"
EXPORT_DIR = BASE_DIR / "exports"

load_dotenv(ENV_PATH)

# Claves secretas: se leen de .env y nunca se exponen completas al frontend
SECRET_KEYS = {"AI_API_KEY"}


def _env(name: str, default):
    val = os.getenv(name)
    if val is None or val == "":
        return default
    if isinstance(default, bool):
        return val.strip().lower() in ("1", "true", "yes", "si", "sí", "on")
    if isinstance(default, int):
        try:
            return int(val)
        except ValueError:
            return default
    if isinstance(default, float):
        try:
            return float(val)
        except ValueError:
            return default
    return val


DEFAULTS = {
    # Servidor
    "HOST": "127.0.0.1",
    "PORT": 8000,
    # Base de datos (ruta relativa a la carpeta del proyecto o absoluta)
    "DB_PATH": "data/roblox_analyzer.db",
    # Descubrimiento / recolección
    "MAX_RESULTS": 100,            # máximo de juegos por defecto en un lote
    "HARD_MAX_RESULTS": 1000,      # límite absoluto permitido
    "BATCH_SIZE": 50,              # IDs por solicitud (Roblox acepta máx. 50 en /v1/games)
    "REQUEST_INTERVAL": 0.6,       # segundos mínimos entre solicitudes al mismo host
    "REQUEST_TIMEOUT": 15,         # segundos
    "MAX_RETRIES": 4,
    "BACKOFF_BASE": 1.5,           # segundos; se duplica en cada reintento
    "CACHE_TTL_STATS": 600,        # caché de estadísticas (seg). 0 = sin caché
    "CACHE_TTL_STATIC": 86400,     # caché de gamepasses/insignias/iconos (seg)
    "FETCH_GAMEPASSES": True,
    "FETCH_BADGES": True,
    "FETCH_SERVERS": False,        # contar servidores públicos (costoso)
    "MAX_SERVER_PAGES": 2,         # páginas de 100 servidores como máximo
    "MIN_SNAPSHOT_MINUTES": 30,    # no crear otro snapshot del mismo juego antes de X minutos
    "OVERSAMPLE_FACTOR": 2.0,      # candidatos extra para ordenar antes de recortar
    # IA
    "AI_ENABLED": False,
    "AI_PROVIDER": "anthropic",    # anthropic | openai (compatible)
    "AI_MODEL": "",
    "AI_BASE_URL": "",             # solo para proveedores compatibles con OpenAI
    "AI_MAX_TOKENS": 1800,
    "AI_API_KEY": "",
    # Interfaz
    "UI_PAGE_SIZE": 50,
    "OPEN_BROWSER": True,
}

# Claves editables desde la interfaz (se guardan en settings.json)
EDITABLE_KEYS = [
    "MAX_RESULTS", "BATCH_SIZE", "REQUEST_INTERVAL", "REQUEST_TIMEOUT", "MAX_RETRIES",
    "CACHE_TTL_STATS", "CACHE_TTL_STATIC", "FETCH_GAMEPASSES", "FETCH_BADGES",
    "FETCH_SERVERS", "MAX_SERVER_PAGES", "MIN_SNAPSHOT_MINUTES", "OVERSAMPLE_FACTOR",
    "AI_ENABLED", "AI_PROVIDER", "AI_MODEL", "AI_BASE_URL", "AI_MAX_TOKENS",
    "DB_PATH", "UI_PAGE_SIZE",
]


class Settings:
    def __init__(self):
        self._lock = threading.RLock()
        self._values: dict = {}
        self.reload()

    def reload(self):
        with self._lock:
            load_dotenv(ENV_PATH, override=False)
            vals = {k: _env(k, v) for k, v in DEFAULTS.items()}
            if SETTINGS_PATH.exists():
                try:
                    stored = json.loads(SETTINGS_PATH.read_text(encoding="utf-8"))
                    for k, v in stored.items():
                        if k in DEFAULTS and k not in SECRET_KEYS:
                            vals[k] = _coerce(v, DEFAULTS[k])
                except (OSError, json.JSONDecodeError):
                    pass
            self._values = vals

    def get(self, key, default=None):
        with self._lock:
            return self._values.get(key, default)

    def __getitem__(self, key):
        return self.get(key)

    @property
    def db_path(self) -> Path:
        p = Path(self.get("DB_PATH"))
        if not p.is_absolute():
            p = BASE_DIR / p
        return p

    def public_dict(self) -> dict:
        with self._lock:
            d = {k: self._values.get(k) for k in EDITABLE_KEYS}
            key = self._values.get("AI_API_KEY") or ""
            d["AI_API_KEY_SET"] = bool(key)
            d["AI_API_KEY_HINT"] = ("…" + key[-4:]) if len(key) > 8 else ""
            d["DB_PATH_RESOLVED"] = str(self.db_path)
            d["HARD_MAX_RESULTS"] = self._values.get("HARD_MAX_RESULTS")
            return d

    def update(self, data: dict) -> dict:
        """Guarda valores editables en settings.json y la API key en .env."""
        with self._lock:
            stored = {}
            if SETTINGS_PATH.exists():
                try:
                    stored = json.loads(SETTINGS_PATH.read_text(encoding="utf-8"))
                except (OSError, json.JSONDecodeError):
                    stored = {}
            for k, v in data.items():
                if k in EDITABLE_KEYS:
                    stored[k] = _coerce(v, DEFAULTS[k])
            # Límites de seguridad
            if "BATCH_SIZE" in stored:
                stored["BATCH_SIZE"] = max(1, min(50, int(stored["BATCH_SIZE"])))
            if "REQUEST_INTERVAL" in stored:
                stored["REQUEST_INTERVAL"] = max(0.2, float(stored["REQUEST_INTERVAL"]))
            if "MAX_RESULTS" in stored:
                stored["MAX_RESULTS"] = max(1, min(int(DEFAULTS["HARD_MAX_RESULTS"]), int(stored["MAX_RESULTS"])))
            SETTINGS_PATH.parent.mkdir(parents=True, exist_ok=True)
            SETTINGS_PATH.write_text(json.dumps(stored, indent=2, ensure_ascii=False), encoding="utf-8")

            api_key = data.get("AI_API_KEY")
            if api_key is not None and str(api_key).strip() != "":
                if not ENV_PATH.exists():
                    ENV_PATH.write_text("", encoding="utf-8")
                set_key(str(ENV_PATH), "AI_API_KEY", str(api_key).strip())
                os.environ["AI_API_KEY"] = str(api_key).strip()
            if data.get("AI_API_KEY_CLEAR"):
                if ENV_PATH.exists():
                    set_key(str(ENV_PATH), "AI_API_KEY", "")
                os.environ["AI_API_KEY"] = ""
            self.reload()
            return self.public_dict()


def _coerce(value, default):
    try:
        if isinstance(default, bool):
            if isinstance(value, str):
                return value.strip().lower() in ("1", "true", "yes", "si", "sí", "on")
            return bool(value)
        if isinstance(default, int):
            return int(float(value))
        if isinstance(default, float):
            return float(value)
        return "" if value is None else str(value)
    except (TypeError, ValueError):
        return default


settings = Settings()
