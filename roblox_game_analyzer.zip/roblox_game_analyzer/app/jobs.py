"""Trabajos en segundo plano (descubrir, análisis masivo, refrescar, re-analizar).

Un único hilo trabajador procesa la cola: así se respetan los límites de las APIs
y se evita escritura concurrente en SQLite. Cada error de un juego se registra y
el trabajo continúa con los demás.
"""
from __future__ import annotations

import logging
import queue
import threading
import traceback
from datetime import datetime

from . import collector, db, mechanics, patterns
from .ai_analyzer import AIError, ai_status, analyze_with_ai
from .config import settings
from .discovery import discover
from .roblox_client import RobloxClient

log = logging.getLogger(__name__)

JOB_TYPES = {"discover": "Descubrir", "batch": "Análisis masivo", "refresh": "Actualizar estadísticas",
             "reanalyze": "Re-analizar mecánicas", "ai_batch": "Análisis IA en lote"}


class JobCancelled(Exception):
    pass


class JobContext:
    def __init__(self, job_id: int, cancel_event: threading.Event):
        self.job_id = job_id
        self.cancel = cancel_event
        self.warnings: list[str] = []

    def progress(self, done: int, total: int, message: str = ""):
        db.execute("UPDATE jobs SET progress=?, total=?, message=? WHERE id=?", (int(done), int(total), message, self.job_id))
        if self.cancel.is_set():
            raise JobCancelled()


class JobManager:
    def __init__(self):
        self.q: queue.Queue[int] = queue.Queue()
        self.cancel_events: dict[int, threading.Event] = {}
        self._thread = threading.Thread(target=self._worker, name="job-worker", daemon=True)
        self._started = False

    def start(self):
        if not self._started:
            self._thread.start()
            self._started = True

    def submit(self, job_type: str, params: dict) -> int:
        if job_type not in JOB_TYPES:
            raise ValueError(f"Tipo de trabajo desconocido: {job_type}")
        job_id = db.execute("INSERT INTO jobs (type, params, status, created_at, message) VALUES (?,?,?,?,?)",
                            (job_type, db.jdump(params), "queued", db.now_iso(), "En cola"))
        self.cancel_events[job_id] = threading.Event()
        self.q.put(job_id)
        return job_id

    def cancel(self, job_id: int) -> bool:
        ev = self.cancel_events.get(job_id)
        if ev:
            ev.set()
            db.execute("UPDATE jobs SET message='Cancelando…' WHERE id=? AND status IN ('queued','running')", (job_id,))
            return True
        return False

    def _worker(self):
        while True:
            job_id = self.q.get()
            try:
                self._run(job_id)
            except Exception:  # noqa: BLE001 — nunca matar el hilo
                log.exception("Error inesperado en trabajo %s", job_id)
            finally:
                self.cancel_events.pop(job_id, None)

    def _run(self, job_id: int):
        job = db.one("SELECT * FROM jobs WHERE id=?", (job_id,))
        if not job:
            return
        ev = self.cancel_events.get(job_id) or threading.Event()
        if ev.is_set():
            db.execute("UPDATE jobs SET status='cancelled', message='Cancelado antes de iniciar', finished_at=? WHERE id=?",
                       (db.now_iso(), job_id))
            return
        db.execute("UPDATE jobs SET status='running', started_at=?, message='Iniciando' WHERE id=?", (db.now_iso(), job_id))
        ctx = JobContext(job_id, ev)
        params = db.jload(job["params"], {})
        try:
            if job["type"] in ("discover", "batch"):
                result = run_pipeline(ctx, params, full_analysis=(job["type"] == "batch" or params.get("analyze", True)))
            elif job["type"] == "refresh":
                result = run_refresh(ctx, params)
            elif job["type"] == "reanalyze":
                result = run_reanalyze(ctx, params)
            elif job["type"] == "ai_batch":
                result = run_ai_batch(ctx, params)
            else:
                result = {}
            result["warnings"] = (result.get("warnings") or []) + ctx.warnings
            db.execute("UPDATE jobs SET status='done', result=?, finished_at=?, message=? WHERE id=?",
                       (db.jdump(result), db.now_iso(), result.get("summary", "Completado"), job_id))
        except JobCancelled:
            db.execute("UPDATE jobs SET status='cancelled', finished_at=?, message='Cancelado por el usuario', result=? WHERE id=?",
                       (db.now_iso(), db.jdump({"warnings": ctx.warnings}), job_id))
        except Exception as e:  # noqa: BLE001
            log.error("Trabajo %s falló: %s\n%s", job_id, e, traceback.format_exc())
            db.log_error(f"job:{job_id}", f"{type(e).__name__}: {e}")
            db.execute("UPDATE jobs SET status='error', finished_at=?, message=?, result=? WHERE id=?",
                       (db.now_iso(), f"Error: {e}", db.jdump({"warnings": ctx.warnings}), job_id))


def _sort_key(criterion: str):
    def ts(v):
        try:
            return datetime.fromisoformat(str(v).replace("Z", "+00:00")).timestamp()
        except (TypeError, ValueError):
            return 0
    table = {
        "playing": lambda r: r.get("playing") or 0,
        "visits": lambda r: r.get("visits") or 0,
        "favorites": lambda r: r.get("favorites") or 0,
        "likes": lambda r: r.get("up_votes") or 0,
        "like_ratio": lambda r: r.get("like_ratio") or 0,
        "updated": lambda r: ts(r.get("updated")),
        "created": lambda r: ts(r.get("created")),
    }
    return table.get(criterion)


def run_pipeline(ctx: JobContext, p: dict, full_analysis: bool = True) -> dict:
    """DESCUBRIR → RECOPILAR → GUARDAR → ANALIZAR → ESTADÍSTICAS"""
    hard_max = int(settings.get("HARD_MAX_RESULTS", 1000))
    limit = max(1, min(hard_max, int(p.get("limit") or settings.get("MAX_RESULTS", 100))))
    sort_by = p.get("sort_by") or "relevance"
    strict = bool(p.get("strict_genre"))
    oversample = float(settings.get("OVERSAMPLE_FACTOR", 2.0))
    pool = limit if (sort_by == "relevance" and not strict) else min(hard_max * 2, int(limit * max(1.0, oversample)) + 10)
    client = RobloxClient(ctx.cancel)
    category = p.get("category") or None
    mode = p.get("mode") or "category"
    disc_label = category if mode == "category" else (p.get("keyword") if mode == "keyword" else None)

    # 1. Descubrir
    ctx.progress(0, limit, "Descubriendo juegos")
    dres = discover(client, mode, pool, category=category, keyword=p.get("keyword"), ids_text=p.get("ids_text"),
                    id_type=p.get("id_type", "auto"), urls_text=p.get("urls_text"),
                    seed_ids=p.get("seed_ids"), sort_ids=p.get("sort_ids"))
    ctx.warnings += dres.warnings
    cands = dres.candidates
    found = len(cands)
    via = {c.universe_id: c.via for c in cands}
    ctx.progress(0, max(found, 1), f"{found} juegos descubiertos. Recopilando datos…")
    if not cands:
        return {"summary": "No se encontraron juegos", "found": 0, "saved": 0, "sources": dres.sources_used}

    # 2. Datos básicos en lote
    records, not_found, w = collector.fetch_basic(client, [c.universe_id for c in cands],
                                                  progress=lambda d, t, m: ctx.progress(d, t, m),
                                                  batch_size=p.get("batch_size"))
    ctx.warnings += w
    if not_found:
        collector.mark_not_found(not_found)
        ctx.warnings.append(f"{len(not_found)} juegos no disponibles (eliminados/privados).")
    ok = [r for r in records.values() if r.get("status") == "ok"]
    errored = [r for r in records.values() if r.get("status") == "error"]

    # Filtro estricto por género de Roblox
    if strict and category:
        from .discovery import CATEGORIES
        genres = {g.lower() for g in CATEGORIES.get(category, {}).get("genres", [])}
        if genres:
            before = len(ok)
            ok = [r for r in ok if (r.get("genre_l1") or "").lower() in genres or (r.get("genre_l2") or "").lower() in genres]
            ctx.warnings.append(f"Filtro estricto de género: {before} → {len(ok)} juegos.")
        else:
            ctx.warnings.append(f"La categoría '{category}' no tiene un género oficial equivalente; filtro estricto ignorado.")

    # 3. Ordenar y recortar
    key = _sort_key(sort_by)
    if key:
        ok.sort(key=key, reverse=True)
    else:
        order = {c.universe_id: i for i, c in enumerate(cands)}
        ok.sort(key=lambda r: order.get(r["universe_id"], 1e9))
    selected = ok[:limit]
    for i, r in enumerate(selected, 1):
        r["_rank"] = i

    # 4. Iconos + extras + guardar
    collector.fetch_icons(client, {r["universe_id"]: r for r in selected})
    saved = 0
    total = len(selected)
    for i, rec in enumerate(selected, 1):
        ctx.progress(i - 1, total, f"Datos adicionales y guardado ({i}/{total}): {rec.get('name')}")
        try:
            collector.fetch_extras(client, rec)
        except JobCancelled:
            raise
        except Exception as e:  # noqa: BLE001
            ctx.warnings.append(f"Extras de {rec['universe_id']} fallaron: {e}")
            db.log_error("fetch_extras", str(e))
        try:
            if collector.save_game(rec, ctx.job_id, disc_label, via.get(rec["universe_id"])):
                saved += 1
        except Exception as e:  # noqa: BLE001
            ctx.warnings.append(f"No se pudo guardar {rec['universe_id']}: {e}")
            db.log_error("save_game", str(e))

    # 5. Analizar mecánicas
    analyzed, ai_done = 0, 0
    use_ai = bool(p.get("use_ai")) and ai_status()["ready"]
    if p.get("use_ai") and not use_ai:
        ctx.warnings.append("Análisis IA solicitado pero no disponible: " + (ai_status()["reason"] or ""))
    if full_analysis:
        for i, rec in enumerate(selected, 1):
            ctx.progress(i - 1, total, f"Analizando mecánicas ({i}/{total})")
            try:
                mechanics.analyze_game(rec["universe_id"])
                analyzed += 1
            except Exception as e:  # noqa: BLE001
                ctx.warnings.append(f"Análisis de {rec['universe_id']} falló: {e}")
                db.log_error("analyze_game", str(e))
            if use_ai:
                try:
                    analyze_with_ai(rec["universe_id"])
                    ai_done += 1
                except AIError as e:
                    ctx.warnings.append(f"IA {rec['universe_id']}: {e}")

    # 6. Estadísticas agregadas del lote
    stats = patterns.full_patterns(job_id=ctx.job_id) if full_analysis else None
    if stats:
        db.execute("INSERT INTO analysis_results (job_id, kind, content, model, created_at) VALUES (?,?,?,?,?)",
                   (ctx.job_id, "batch_stats", db.jdump(stats), "reglas v1", db.now_iso()))
    ctx.progress(total, total, "Completado")
    return {
        "summary": f"{found} descubiertos · {saved} guardados · {analyzed} analizados"
                   + (f" · {ai_done} con IA" if ai_done else ""),
        "found": found, "fetched": len(records), "not_found": len(not_found), "errors": len(errored),
        "saved": saved, "analyzed": analyzed, "ai_analyzed": ai_done, "sources": dres.sources_used,
        "api_stats": client.stats, "category": disc_label, "sort_by": sort_by,
    }


def run_refresh(ctx: JobContext, p: dict) -> dict:
    ids = p.get("universe_ids") or [r["universe_id"] for r in db.rows("SELECT universe_id FROM games WHERE status!='not_found'")]
    client = RobloxClient(ctx.cancel)
    records, not_found, w = collector.fetch_basic(client, ids, progress=lambda d, t, m: ctx.progress(d, t, "Actualizando estadísticas"),
                                                  fresh=True)
    ctx.warnings += w
    collector.mark_not_found(not_found)
    saved = 0
    extras = bool(p.get("extras"))
    items = [r for r in records.values() if r.get("status") == "ok"]
    if extras:
        collector.fetch_icons(client, {r["universe_id"]: r for r in items})
    for i, rec in enumerate(items, 1):
        if extras:
            collector.fetch_extras(client, rec)
        if collector.save_game(rec, None):
            saved += 1
        if i % 20 == 0:
            ctx.progress(i, len(items), "Guardando snapshots")
    if extras:
        for rec in items:
            mechanics.analyze_game(rec["universe_id"])
    return {"summary": f"{saved} juegos actualizados · {len(not_found)} no disponibles", "saved": saved,
            "not_found": len(not_found), "api_stats": client.stats}


def run_reanalyze(ctx: JobContext, p: dict) -> dict:
    ids = p.get("universe_ids") or [r["universe_id"] for r in db.rows("SELECT universe_id FROM games WHERE status='ok'")]
    for i, uid in enumerate(ids, 1):
        try:
            mechanics.analyze_game(uid)
        except Exception as e:  # noqa: BLE001
            ctx.warnings.append(f"{uid}: {e}")
        if i % 10 == 0 or i == len(ids):
            ctx.progress(i, len(ids), "Re-analizando mecánicas")
    return {"summary": f"{len(ids)} juegos re-analizados", "analyzed": len(ids)}


def run_ai_batch(ctx: JobContext, p: dict) -> dict:
    st = ai_status()
    if not st["ready"]:
        raise AIError(st["reason"])
    ids = p.get("universe_ids") or []
    done = 0
    for i, uid in enumerate(ids, 1):
        ctx.progress(i - 1, len(ids), f"IA ({i}/{len(ids)})")
        try:
            analyze_with_ai(uid)
            done += 1
        except AIError as e:
            ctx.warnings.append(f"{uid}: {e}")
    return {"summary": f"{done}/{len(ids)} juegos analizados con IA", "ai_analyzed": done}


manager = JobManager()
